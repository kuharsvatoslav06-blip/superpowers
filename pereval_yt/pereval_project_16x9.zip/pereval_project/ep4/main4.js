// YouTube cut: after the cliffhanger the frame drops to black while the impact rings out;
// the next episode's title card is a separate clip (see yt/)
function endCard(t) { ctx.fillStyle = '#04050a'; ctx.fillRect(0, 0, W, H); }

const SCENES = { return: sceneReturn, hug: sceneHug, mittens: sceneMittens, cold: sceneCold4, rule3: sceneRule3, countkid: sceneCountKid, window2: sceneWindow2, smile: sceneSmile };
const END_CARD = 1.2;
const DURATION = TL.voice_end + END_CARD;
function render(t) {
  ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  if (t >= TL.voice_end) { endCard(t); post(t, 0); return; }
  const s = TL.scenes.find(x => t < x.e) || TL.scenes[TL.scenes.length - 1];
  ctx.save();
  const hud = SCENES[s.id](t);
  ctx.restore();
  post(t, s.id === 'mittens' ? 0.8 : 1);
  drawHUD(hud.a, hud.b, hud.clock, hud.note);
  drawCaptions(t);
  const cut = 1 - prog(t, s.s, s.id === 'return' ? 0.6 : 0.12);
  if (cut > 0) { ctx.fillStyle = `rgba(3,4,9,${cut})`; ctx.fillRect(0, 0, W, H); }
}
