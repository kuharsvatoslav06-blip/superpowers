// =====================================================================
// Episode 4 — «Вернувшийся». Builds on helpers from episodes 1–3.
// =====================================================================
const IGOR4 = PEOPLE.find(p => p.id === 'ИГОРЬ');

// a child seen from the front/side; o.mitL/o.mitR: red mittens; o.knock: 0..1 right arm raised to the glass
function kid2(x, y, s, o = {}) {
  ctx.save(); ctx.globalAlpha *= (o.a ?? 1); ctx.translate(x, y); ctx.scale(s, s);
  ctx.fillStyle = '#1c2236'; rr(-12, 30, 10, 36, 4); ctx.fill(); rr(2, 30, 10, 36, 4); ctx.fill();
  ctx.fillStyle = '#3d6fb5'; rr(-20, -24, 40, 60, 12); ctx.fill();
  // left arm down
  rr(-27, -16, 10, 36, 5); ctx.fill();
  ctx.fillStyle = o.mitL ? '#b8322a' : '#e0b48c'; circle(-22, 22, 6); ctx.fill();
  // right arm: down, or raised and tapping
  const k = o.knock || 0;
  ctx.save(); ctx.translate(20, -14); ctx.rotate(lerp(0, -2.5, k)); ctx.fillStyle = '#3d6fb5'; rr(-5, 0, 10, 36, 5); ctx.fill();
  ctx.fillStyle = o.mitR ? '#b8322a' : '#e0b48c'; circle(0, 38, 6); ctx.fill(); ctx.restore();
  ctx.fillStyle = '#e0b48c'; circle(0, -36, 13); ctx.fill();
  ctx.fillStyle = '#20232c'; circle(-4.5, -37, 1.6); ctx.fill(); circle(4.5, -37, 1.6); ctx.fill();
  ctx.fillStyle = '#f2c230'; ctx.beginPath(); ctx.ellipse(0, -42, 15, 11, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = '#fff3c4'; circle(0, -56, 5); ctx.fill();
  ctx.restore();
}
function redFlash(t, c, a = 0.45) {
  const la = prog(t, c, 0.3); if (la <= 0) return;
  ctx.save(); ctx.globalAlpha = a * la * (0.6 + 0.4 * Math.sin((t - c) * 6));
  const g = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820); g.addColorStop(0, 'rgba(255,40,30,0)'); g.addColorStop(1, 'rgba(255,40,30,0.5)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
}

// ---------------------------------------------------------------------
// 1. return — the fog parts, the figures vanish, Gosha stands at the door
// ---------------------------------------------------------------------
function sceneReturn(t) {
  const id = 'return', s = SC[id];
  const cPart = cue(id, 'РАССТУПИЛСЯ'), cGone = cue(id, 'ИСЧЕЗЛИ'), cG = cue(id, 'ГОША'), cAlive = cue(id, 'ЖИВОЙ');
  const part = ease(prog(t, cPart - 0.2, 1.4));
  const z = 1 + 0.25 * ease(prog(t, cG - 0.2, s.e - cG));
  cam(360, 700, z, () => {
    fogField(t, { seed: 31 });
    const pos = [[250, 590, 1.25], [470, 596, 1.2], [180, 610, 1.1], [540, 606, 1.15], [310, 576, 1.0], [420, 572, 1.05]];
    pos.forEach(([x, y, k], i) => shadowMan(x, y, k, 0.85 * (1 - prog(t, cGone - 0.2 + i * 0.08, 0.5))));
    // the fog thins: the far trees sharpen
    ctx.save(); ctx.globalAlpha = 0.6 * part; const r = rng(77);
    for (let x = -520; x < 1250; x += 50) spruce(x + r() * 26, 600, 160 + r() * 160, '#2c3150');
    ctx.restore();
    fog(t, 480, 720, 0.22 * (1 - part * 0.7), 33, '220,224,240', 6);
    kid2(360, 740, 2.1, { mitL: true, mitR: true, a: prog(t, cG - 0.3, 0.8) });
  });
  // Marina's boot still at the bottom of frame
  ctx.save(); ctx.translate(150, 770); ctx.scale(0.75, 0.75); ctx.fillStyle = '#1a1214'; rr(-60, -360, 120, 380, 30); ctx.fill(); ctx.fillStyle = '#2a1c1a'; rr(-80, -10, 180, 60, 24); ctx.fill(); ctx.restore();
  const ly = FY - 93 * z;
  lock(FX - 70 * z, ly, 140 * z, 282 * z, prog(t, cG, 0.4), '#ffe9a8');
  tag('ГОША · 2 ШАГА ОТ ДВЕРИ', FX, ly - 16, { align: 'center', col: '#ffe9a8', a: prog(t, cG + 0.2, 0.3), size: 14 });
  tag('В ТУМАНЕ', 1060, 322, { align: 'center', a: 1 - prog(t, cGone + 0.4, 0.3), col: '#cdd6e8' });
  bigNum(String(Math.max(0, 7 - Math.floor(prog(t, cGone - 0.2, 0.9) * 6.99))), 1060, 290, 96, '#f1f4fb', 1 - prog(t, cG - 0.3, 0.3));
  const fl = 1 - prog(t, s.s, 0.5); if (fl > 0) { ctx.fillStyle = `rgba(3,4,9,${fl})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'УТРО 2', b: 'ТУМАН', clock: fmtClock(6 * 3600 + 14 * 60 + 31 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 2. hug — back inside; Lena checks him: not a scratch after a night at −40
// ---------------------------------------------------------------------
function sceneHug(t) {
  const id = 'hug', s = SC[id];
  const cL = cue(id, 'ЛЕНА'), cF = cue(id, 'ОБМОРОЖЕНИЯ'), cS = cue(id, 'ЦАРАПИНЫ'), c40 = cue(id, '−40°');
  const lin = ease(prog(t, cL - 0.2, 0.8));
  const fx = 440, fy = lerp(760, 790, lin), sc = lerp(1.6, 2.4, ease(prog(t, s.s, cL - s.s + 0.5)));
  rcam(fx, fy, sc, () => {
    cabinView(t, { dawn: true, hide: ['ГОША', 'ЛЕНА'] });
    person(Object.assign({}, LENA, { x: lerp(LENA.x, 392, lin), y: lerp(LENA.y, 770, lin) }), t);
    person(GOSHA, t);
    ctx.fillStyle = '#b8322a'; circle(GOSHA.x - 14, GOSHA.y + 6, 4); ctx.fill(); circle(GOSHA.x + 14, GOSHA.y + 6, 4); ctx.fill();
    lock(GOSHA.x - 24, GOSHA.y - 24, 48, 46, prog(t, cL, 0.4), '#ffe9a8');
  });
  const rows = [['ОБМОРОЖЕНИЕ', 'НЕТ', cF], ['ЦАРАПИНЫ', 'НЕТ', cS], ['НОЧЬ ПРИ −40°', '?', c40]];
  tag('ОСМОТР · ЛЕНА', LM, TY, { a: prog(t, cL, 0.3), col: '#ffe9a8' });
  rows.forEach(([l, v, c], i) => { const a = prog(t, c, 0.25); tag(l, LM, TY + 40 + i * 36, { a, col: '#cdd6e8', size: 15 }); tag(v, LM + 400, TY + 40 + i * 36, { a, col: v === '?' ? ORANGE : '#7fe08a', align: 'right', size: 15 }); });
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 15 * 60 + 2 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 3. mittens — two on his hands, a third still lying on the seat
// ---------------------------------------------------------------------
function sceneMittens(t) {
  const id = 'mittens', s = SC[id];
  const cHands = cue(id, 'РУКИ'), cBoth = cue(id, 'ОБЕ'), cSeat = cue(id, 'СИДЕНЬЕ'), cRed = cue(id, 'КРАСНАЯ');
  const pan = ease(prog(t, cRed - 0.2, 1.0));
  cam(lerp(340, 420, pan), 520, lerp(1.1, 1.05, pan) * (1 + 0.04 * prog(t, s.s, s.e - s.s)), () => {
    ctx.fillStyle = '#0d1018'; ctx.fillRect(-800, -400, 2600, 2200);
    glow(300, 520, 500, 'rgba(120,150,210,0.18)');
    // sleeves and mittens on his lap
    ctx.fillStyle = '#3d6fb5'; rr(70, 380, 150, 70, 30); ctx.fill(); rr(70, 520, 150, 70, 30); ctx.fill();
    redMitten(250, 418, 3.4); redMitten(250, 558, 3.4);
    ctx.fillStyle = '#1c2236'; rr(40, 640, 330, 140, 30); ctx.fill();
    // the seat with the third mitten
    rr(470, 380, 240, 280, 26); ctx.fillStyle = '#4a3a2c'; ctx.fill(); rr(470, 620, 240, 40, [0, 0, 26, 26]); ctx.fillStyle = '#34281e'; ctx.fill();
    redMitten(590, 500, 3.2);
    const b = prog(t, cBoth, 0.4);
    lock(200, 360, 110, 120, b, '#ffe9a8'); lock(200, 500, 110, 120, b, '#ffe9a8');
    text('1', 320, 380, `800 26px ${MONO}`, '#ffe9a8', 'left', b); text('2', 320, 520, `800 26px ${MONO}`, '#ffe9a8', 'left', b);
    const c = prog(t, cSeat - 0.1, 0.4);
    lock(530, 440, 120, 130, c, '#ff3b30'); text('3', 660, 460, `800 30px ${MONO}`, '#ff6a4a', 'left', c);
  });
  tag('ВАРЕЖЕК У ГОШИ БЫЛО: 2', 1100, 250, { align: 'center', col: '#cdd6e8', a: prog(t, cSeat + 0.3, 0.3), size: 16 });
  tag('СЕЙЧАС: 3', 1100, 292, { align: 'center', col: '#ff6a4a', a: prog(t, cSeat + 0.7, 0.3), size: 18 });
  return { a: 'УТРО 2', b: 'ВАРЕЖКИ', clock: fmtClock(6 * 3600 + 15 * 60 + 30 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 4. cold — thermal: five warm spots; Gosha is colder than snow, −47°
// ---------------------------------------------------------------------
function sceneCold4(t) {
  const id = 'cold', s = SC[id];
  const cFive = cue(id, 'ПЯТЬ'), cSnow = cue(id, 'СНЕГА'), c47 = cue(id, '−47°');
  const on = ease(prog(t, s.s + 0.2, 0.5));
  const zi = ease(prog(t, cSnow - 0.4, 0.9));
  const S4 = lerp(1.08, 2.2, zi);
  rcam(lerp(360, GOSHA.x - 20, zi), lerp(540, GOSHA.y - 10, zi), S4, () => {
    ctx.fillStyle = '#120a33'; ctx.fillRect(-600, -400, 1600, 2400);
    cabinShell(true);
    ctx.fillStyle = '#35268a';
    for (const y of ROWS) for (const x of [230, 292, 428, 490]) { rr(x - 28, y - 34, 56, 70, 10); ctx.fill(); }
    rr(204, 904, 312, 62, 12); ctx.fill();
    PEOPLE.forEach((p, i) => {
      if (p.id === 'ГОША') return;
      heat(p.x, p.y, p.k, on);
      const a = prog(t, cFive + i * 0.12, 0.3) * (1 - zi), r = 36 * p.k;
      if (a > 0) { lock(p.x - r, p.y - r, r * 2, r * 2, a, '#ffe9a8'); const q = rlabel(p, r, S4); tag('+36°', q.x, q.y, { a, size: 12, col: '#ffe9a8', align: q.align }); }
    });
    // Gosha: a hole in the heat map
    glow(GOSHA.x, GOSHA.y, 60, 'rgba(40,120,255,0.3)');
    ctx.fillStyle = '#020108'; circle(GOSHA.x, GOSHA.y, 15); ctx.fill();
    ctx.strokeStyle = `rgba(110,225,255,${0.55 + 0.35 * Math.sin(t * 5)})`; ctx.lineWidth = 1.4; circle(GOSHA.x, GOSHA.y, 19); ctx.stroke();
    lock(GOSHA.x - 28, GOSHA.y - 28, 56, 56, prog(t, cSnow - 0.2, 0.4), '#6ee1ff');
  });
  const n = Math.min(5, Math.floor(prog(t, cFive, 0.8) * 5.99));
  tag('ТЁПЛЫХ ОБЪЕКТОВ', LM, TY, { col: '#ffe9a8', a: on * (1 - zi) }); text(n + ' / 6', LM + 200, TY + 2, `700 22px ${MONO}`, '#ffe9a8', 'left', on * (1 - zi));
  const a47 = prog(t, c47 - 0.1, 0.2);
  if (a47 > 0) { bigNum('−' + Math.round(lerp(30, 47, easeOut(prog(t, c47, 0.7)))) + '°', 1040, 250, 96, '#bfefff', a47); tag('ГОША', 1040, 284, { align: 'center', col: '#6ee1ff', a: a47, size: 16 }); }
  imagerUI(t, on);
  return { a: 'УТРО 2', b: 'ТЕПЛОВИЗОР', clock: fmtClock(6 * 3600 + 15 * 60 + 52 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 5. rule3 — "whoever came back from the fog did not come back"
// ---------------------------------------------------------------------
function sceneRule3(t) {
  const id = 'rule3', s = SC[id];
  const cRule = cue(id, 'ТРЕТЬЕ'), cBack = cue(id, '«КТО'), cNot = cue(id, 'НЕ');
  const z = ease(prog(t, s.s, s.e - s.s));
  cam(455, 500, lerp(1.3, 1.12, z), () => {
    drawWorld(t, { steps: 0, fogA: 0.3, lights: 0, door: 1 });
    for (let i = 0; i < 20; i++) kidPrint(KSTEPS[i], 0.8);
    // the way back: from the end of the trail to the door
    const p = ease(prog(t, cBack - 0.2, 1.4));
    if (p > 0) {
      const red = t > cNot;
      ctx.save(); ctx.strokeStyle = red ? '#ff3b30' : '#ffe9a8'; ctx.lineWidth = 4; ctx.setLineDash([12, 10]); ctx.lineDashOffset = -t * 40;
      ctx.beginPath(); ctx.moveTo(END.x, END.y);
      for (let k = 1; k <= 30; k++) { const q = pathAt(1 - (k / 30) * p); ctx.lineTo(q.x - 30, q.y + 10); }
      ctx.stroke(); ctx.restore();
      const q = pathAt(1 - p); ctx.fillStyle = red ? '#ff3b30' : '#ffe9a8'; circle(q.x - 30, q.y + 10, 8); ctx.fill();
    }
    const x = ease(prog(t, cNot + 0.1, 0.35));
    if (x > 0) { const c = pathAt(0.5); ctx.save(); ctx.strokeStyle = '#ff3b30'; ctx.lineWidth = 10; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(c.x - 70, c.y - 70); ctx.lineTo(c.x - 70 + 140 * x, c.y - 70 + 140 * x); ctx.moveTo(c.x + 70, c.y - 70); ctx.lineTo(c.x + 70 - 140 * x, c.y - 70 + 140 * x); ctx.stroke(); ctx.restore(); }
  });
  ctx.fillStyle = 'rgba(3,5,14,0.35)'; ctx.fillRect(0, 0, W, H);
  tag('ПРАВИЛО ТАЙГИ · № 3', LM, TY, { a: prog(t, cRule - 0.1, 0.3), size: 18 });
  tag('ОБРАТНЫЙ ПУТЬ', LM, TY + 42, { a: prog(t, cBack, 0.3) * (1 - prog(t, cNot, 0.2)), col: '#ffe9a8' });
  tag('НЕ ТОТ, КТО УШЁЛ', LM, TY + 42, { a: prog(t, cNot + 0.2, 0.3), col: '#ff6a4a' });
  redFlash(t, cNot + 0.2, 0.35);
  return { a: 'УТРО 2', b: 'ТАЙГА', clock: fmtClock(6 * 3600 + 16 * 60 + 14 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 6. countkid — Gosha counts them out loud: one to five. "Sixth is me."
// ---------------------------------------------------------------------
function sceneCountKid(t) {
  const id = 'countkid', s = SC[id];
  const order = [['РАЗ', 'ЛЕНА'], ['ДВА', 'ФОМИЧ'], ['ТРИ', 'ИГОРЬ'], ['ЧЕТЫРЕ', 'МАРИНА'], ['ПЯТЬ', 'ТИМУР']];
  const cLoud = cue(id, 'ВСЛУХ'), cMe = cue(id, 'Я»');
  const zi = ease(prog(t, cMe - 0.4, 0.9));
  rcam(lerp(360, GOSHA.x - 30, zi), lerp(540, GOSHA.y - 20, zi), lerp(1.08, 2.4, zi), () => {
    cabinView(t, { dawn: true });
    lock(GOSHA.x - 26, GOSHA.y - 26, 52, 50, prog(t, s.s + 0.3, 0.4), '#6ee1ff');
    order.forEach(([w, n], i) => {
      const c = cue(id, w), p = PEOPLE.find(q => q.id === n), a = prog(t, c - 0.05, 0.15);
      if (a <= 0) return;
      const k = 1 + 0.3 * pulse(t, c, 0.3);
      ctx.save(); ctx.globalAlpha = a; circle(p.x, p.y - 44, 18 * k); ctx.fillStyle = '#f1f4fb'; ctx.fill(); ctx.restore();
      text(String(i + 1), p.x, p.y - 36, `800 22px ${MONO}`, '#10131f', 'center', a);
      // a thin line from Gosha's finger to each person counted
      ctx.save(); ctx.globalAlpha = 0.5 * a * (1 - prog(t, c + 0.4, 0.4)); ctx.strokeStyle = '#6ee1ff'; ctx.lineWidth = 1.5; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(GOSHA.x, GOSHA.y); ctx.lineTo(p.x, p.y); ctx.stroke(); ctx.restore();
    });
    const a6 = prog(t, cMe - 0.05, 0.2);
    if (a6 > 0) {
      const pr = ((t - cMe) * 0.9) % 1;
      ctx.strokeStyle = `rgba(255,59,48,${1 - pr})`; ctx.lineWidth = 3; circle(GOSHA.x, GOSHA.y - 40, 18 + pr * 40); ctx.stroke();
      ctx.save(); ctx.globalAlpha = a6; circle(GOSHA.x, GOSHA.y - 40, 18); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore();
      text('6', GOSHA.x, GOSHA.y - 32, `800 22px ${MONO}`, '#fff', 'center', a6);
    }
  });
  tag('ПРАВИЛО № 1 · ЛЮДЕЙ ВСЛУХ НЕ СЧИТАЮТ', FX, 118, { align: 'center', col: '#ff6a4a', a: prog(t, cLoud, 0.3) * (1 - zi), size: 14 });
  redFlash(t, cMe, 0.4);
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 16 * 60 + 40 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 7. window2 — a warm spot in the snow: +36. Behind the glass, Gosha, one mitten, knocking
// ---------------------------------------------------------------------
const WIN2 = { x: 250, y: 92, w: 780, h: 440 };
function window2Frame(th) {
  const { x, y, w, h } = WIN2;
  ctx.fillStyle = th ? '#140a36' : '#0b0f18'; ctx.fillRect(-800, -400, 2800, 2200);
  ctx.lineWidth = 16; ctx.strokeStyle = th ? '#2c1a72' : '#1b2230'; rr(x, y, w, h, 34); ctx.stroke();
}
function sceneWindow2(t) {
  const id = 'window2', s = SC[id];
  const cWarm = cue(id, 'ТЁПЛОЕ'), c36 = cue(id, '+36°'), cG = cue(id, 'ГОША'), cOne = cue(id, 'ОДНОЙ'), cKn = cue(id, 'СТУЧИТ');
  const sw = prog(t, cG - 0.25, 0.25);            // thermal -> plain view
  const th = sw < 1;
  const zi = ease(prog(t, cOne - 0.3, 0.8));
  const knock = t > cKn - 0.1 ? 0.5 + 0.5 * Math.abs(Math.sin((t - cKn) * 5.5)) : 0;
  cam(lerp(640, 716, zi), lerp(312, 380, zi), lerp(1, 1.7, zi), () => {
    const { x, y, w, h } = WIN2;
    if (th) {
      window2Frame(true);
      ctx.save(); rr(x, y, w, h, 34); ctx.clip();
      ctx.fillStyle = '#07031a'; ctx.fillRect(x, y, w, h);
      ctx.fillStyle = '#0d0630'; ctx.fillRect(x, y + h * 0.7, w, h * 0.3);
      for (let i = 0; i < 13; i++) crown(x + 30 + i * 60, y + h * 0.55, 30, 70 + i, '#0b0626', '#120a34', 'rgba(40,26,96,0.9)');
      const wa = prog(t, cWarm - 0.1, 0.4);
      if (wa > 0) heat(726, y + h * 0.78, 0.55, wa);
      ctx.restore();
      const la = prog(t, c36 - 0.1, 0.3);
      lock(686, y + h * 0.78 - 60, 80, 110, la, '#ffe9a8');
      tag('+36°', 726, y + h * 0.78 - 72, { align: 'center', col: '#ffe9a8', a: la, size: 16 });
    } else {
      window2Frame(false);
      ctx.save(); rr(x, y, w, h, 34); ctx.clip();
      ctx.fillStyle = vgrad(y, y + h, [[0, '#4a5274'], [0.6, '#9aa2c2'], [1, '#d4d8ea']]); ctx.fillRect(x, y, w, h);
      const r = rng(19); for (let k = 0; k < 14; k++) spruce(x + 20 + k * 58 + r() * 20, y + h * 0.66, 100 + r() * 100, '#3a4060');
      ctx.fillStyle = '#d8dcec'; ctx.fillRect(x, y + h * 0.66, w, h * 0.34);
      kid2(726, y + h * 0.72, 2.0, { mitL: true, mitR: false, knock });
      // frost on the glass, cleared in a small patch
      const g = ctx.createRadialGradient(726, y + h * 0.6, 160, 726, y + h * 0.6, 520); g.addColorStop(0, 'rgba(200,215,245,0)'); g.addColorStop(1, 'rgba(200,215,245,0.85)');
      ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
      ctx.restore();
      if (t > cKn) for (let k = 0; k < 3; k++) { const p = ((t - cKn) * 0.9 + k / 3) % 1; ctx.strokeStyle = `rgba(255,233,168,${0.6 * (1 - p)})`; ctx.lineWidth = 2; circle(768, y + h * 0.5, 14 + p * 60); ctx.stroke(); }
      lock(666, y + h * 0.42, 120, 250, prog(t, cG, 0.4), '#7fe08a');
      if (t > cOne) { lock(662, y + h * 0.72 + 26, 40, 40, prog(t, cOne, 0.3), '#ff3b30'); lock(752, y + h * 0.72 + 26, 40, 40, prog(t, cOne + 0.2, 0.3), '#cdd6e8'); }
    }
  });
  if (th) imagerUI(t, ease(prog(t, s.s + 0.2, 0.5)));
  else { tag('ЗА СТЕКЛОМ · +36°', 1080, 200, { align: 'center', col: '#7fe08a', a: prog(t, cG, 0.3), size: 16 }); tag('ВАРЕЖКА: 1', 1080, 238, { align: 'center', col: '#ff6a4a', a: prog(t, cOne + 0.3, 0.3), size: 15 }); }
  if (sw > 0 && sw < 1) { ctx.fillStyle = `rgba(230,236,250,${0.7 * (1 - Math.abs(sw * 2 - 1))})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'УТРО 2', b: th ? 'ТЕПЛОВИЗОР' : 'ОКНО', clock: fmtClock(6 * 3600 + 17 * 60 + 5 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 8. smile — and the Gosha inside the bus smiles
// ---------------------------------------------------------------------
function sceneSmile(t) {
  const id = 'smile', s = SC[id];
  const cS = cue(id, 'УЛЫБАЕТСЯ');
  const tf = Math.min(t, cS + 0.7);
  const z = 1 + 0.18 * ease(prog(tf, s.s, cS + 0.7 - s.s));
  cam(360, 520, z * 0.92, () => {
    ctx.fillStyle = '#05070d'; ctx.fillRect(-1000, -400, 2800, 2200);
    glow(520, 360, 360, 'rgba(110,200,255,0.22)');
    ctx.save(); ctx.translate(360, 560);
    ctx.fillStyle = '#3d6fb5'; ctx.beginPath(); ctx.ellipse(0, 330, 260, 200, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#d9b49a'; circle(0, 0, 190); ctx.fill();
    // cold rim light on the right cheek
    ctx.save(); ctx.beginPath(); ctx.arc(0, 0, 190, -1.1, 1.1); ctx.lineWidth = 14; ctx.strokeStyle = 'rgba(150,225,255,0.7)'; ctx.stroke(); ctx.restore();
    ctx.fillStyle = 'rgba(190,225,255,0.35)'; circle(110, 60, 46); ctx.fill(); circle(-110, 60, 40); ctx.fill();
    // eyes: they stay still, they do not blink
    ctx.fillStyle = '#0b0d14'; ctx.beginPath(); ctx.ellipse(-68, -16, 15, 19, 0, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(68, -16, 15, 19, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = 'rgba(220,240,255,0.9)'; circle(-63, -22, 4); ctx.fill(); circle(73, -22, 4); ctx.fill();
    // the smile grows too wide
    const sm = ease(prog(tf, cS - 0.1, 0.7));
    ctx.strokeStyle = '#3a1c1c'; ctx.lineWidth = 7; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(0, 40, lerp(40, 112, sm), lerp(0.35, 0.18, sm) * Math.PI, lerp(0.65, 0.82, sm) * Math.PI); ctx.stroke();
    // hat
    ctx.fillStyle = '#f2c230'; ctx.beginPath(); ctx.ellipse(0, -80, 205, 150, 0, Math.PI, 0); ctx.fill();
    ctx.fillStyle = '#d9a916'; ctx.fillRect(-205, -96, 410, 26);
    ctx.fillStyle = '#fff3c4'; circle(0, -236, 40); ctx.fill();
    ctx.restore();
  });
  if (t > cS + 0.7) { const f = prog(t, cS + 0.7, 0.25); ctx.fillStyle = `rgba(120,10,10,${0.2 * f})`; ctx.fillRect(0, 0, W, H); bracket(60, 100, 1160, 470, '#ff3b30', f, 40, 3); }
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 17 * 60 + 30 + (tf - s.s)) };
}
