#!/usr/bin/env bash
# Build one episode.
#   ./build.sh ep4 final                 -> voice from epN/voice_aleksandr.mp3 (ElevenLabs, voiced by hand); captions aligned by pauses
#   ./build.sh ep7 draft                 -> temporary local voice (piper, female) generated from epN/script.json
#   ./build.sh ep4 final --stills 3 10   -> same audio/timeline, but only test frames at those seconds -> epN/stills/
set -euo pipefail
cd "$(dirname "$0")"
EP=$1; MODE=${2:-final}; N=${EP#ep}; shift 2 || true
cp tools/* "$EP"/
cd "$EP"; mkdir -p parts stills
if [ "$MODE" = "draft" ]; then
  python3 build_audio.py ../tts/ru-irinia-medium.onnx
  python3 -c "d=open('timeline.json').read();open('timeline.js','w').write('const TL = '+d+';')"
  OUT=pereval_seria${N}_draft.mp4
else
  ffmpeg -v error -y -i voice_aleksandr.mp3 -ac 1 -ar 44100 al_voice.wav
  python3 align.py al_voice.wav al > align_report.txt; head -1 align_report.txt
  cp al_voice.wav el_voice.wav; cp al_words.json el_words.json
  python3 build_audio_el.py
  OUT=pereval_seria${N}.mp4
fi
if [ "${1:-}" = "--stills" ]; then shift; node render.js stills "$@"; echo "stills in $EP/stills/"; exit 0; fi
python3 sound.py
for i in 0 1 2 3; do node render.js video $i 4 parts/p$i.mp4 > parts/log$i.txt 2>&1 & done; wait
ffmpeg -v error -y -f concat -safe 0 -i concat.txt -i mix.wav -c:v libx264 -preset slow -crf 22 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -movflags +faststart -shortest "$OUT"
echo "done: $EP/$OUT"
