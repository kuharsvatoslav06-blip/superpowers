"""Synthesize narration line by line, build timeline.json + voice.wav."""
import json, re, sys, wave
from pathlib import Path
import numpy as np
from piper import PiperVoice
from piper.config import SynthesisConfig

HERE = Path(__file__).parent
MODEL = sys.argv[1]
SR_OUT = 44100
VOWELS = set("аеёиоуыэюяАЕЁИОУЫЭЮЯ")

voice = PiperVoice.load(MODEL)
cfg = SynthesisConfig(length_scale=0.97, noise_scale=0.5, noise_w_scale=0.7)
sr_in = voice.config.sample_rate


def synth(text):
    parts = [c.audio_float_array for c in voice.synthesize(text, syn_config=cfg)]
    a = np.concatenate(parts).astype(np.float32)
    # trim silence
    thr = 0.012
    idx = np.where(np.abs(a) > thr)[0]
    if len(idx):
        a = a[max(0, idx[0] - int(0.02 * sr_in)): idx[-1] + int(0.06 * sr_in)]
    # resample (linear) to SR_OUT, slight pitch-down for a darker tone
    pitch = 0.94
    n_out = int(len(a) * SR_OUT / sr_in / pitch)
    x = np.linspace(0, len(a) - 1, n_out)
    return np.interp(x, np.arange(len(a)), a).astype(np.float32)


def weight(say):
    w = sum(1 for ch in say if ch in VOWELS) + 0.35
    if re.search(r"[,:.—]$", say):
        w += 0.9
    return w


def parse_cap(cap):
    cards, card, line = [], [], []
    for tok in cap.split():
        if tok == "|":
            card.append(line); cards.append(card); card, line = [], []
        elif tok == "/":
            card.append(line); line = []
        else:
            hl = tok.startswith("*")
            tok = tok.lstrip("*")
            text, _, say = tok.partition("=")
            line.append({"t": text, "hl": hl, "say": (say or text).replace("_", " ")})
    card.append(line); cards.append(card)
    return cards


script = json.loads((HERE / "script.json").read_text())
t = 0.0
audio = []
out_scenes = []
for sc in script["scenes"]:
    t_scene = t
    t += sc.get("lead", 0.3)
    audio.append(np.zeros(int(sc.get("lead", 0.3) * SR_OUT), np.float32))
    cards_out = []
    for ln in sc["lines"]:
        a = synth(ln["tts"])
        dur = len(a) / SR_OUT
        cards = parse_cap(ln["cap"])
        words = [w for c in cards for l in c for w in l]
        tot = sum(weight(w["say"]) for w in words)
        cur = t
        for w in words:
            d = dur * weight(w["say"]) / tot
            w["s"] = round(cur, 3); w["e"] = round(cur + d, 3)
            cur += d
        for c in cards:
            ws = [w for l in c for w in l]
            cards_out.append({"s": ws[0]["s"], "e": ws[-1]["e"],
                              "lines": [[{"t": w["t"], "hl": w["hl"], "s": w["s"]} for w in l] for l in c]})
        ln_out_end = t + dur
        audio.append(a)
        gap = ln.get("gap", 0.3) * 0.85
        audio.append(np.zeros(int(gap * SR_OUT), np.float32))
        t = ln_out_end + gap
    # hold each card until the next one starts (or a little after its end)
    for i, c in enumerate(cards_out):
        nxt = cards_out[i + 1]["s"] if i + 1 < len(cards_out) else t
        c["hold"] = round(min(nxt, c["e"] + 0.9), 3)
    out_scenes.append({"id": sc["id"], "s": round(t_scene, 3), "e": round(t, 3), "cards": cards_out})

full = np.concatenate(audio)
t = len(full) / SR_OUT
out_scenes[-1]["e"] = round(t, 3)
full = full / max(1e-6, np.abs(full).max()) * 0.89
with wave.open(str(HERE / "voice.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR_OUT)
    w.writeframes((full * 32767).astype(np.int16).tobytes())
(HERE / "timeline.json").write_text(json.dumps({"voice_end": round(t, 3), "scenes": out_scenes}, ensure_ascii=False, indent=1))
for s in out_scenes:
    print(f'{s["id"]:8s} {s["s"]:7.2f} – {s["e"]:7.2f}  ({s["e"]-s["s"]:.1f}s, {len(s["cards"])} cards)')
print("total", round(t, 2))
