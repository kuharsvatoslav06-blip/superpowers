// =====================================================================
// Scene 5 — Gosha draws tally marks on the frosted window: seven
// =====================================================================
const WIN = { x: 250, y: 92, w: 780, h: 440 };
const STICKS = [];
(() => { const r = rng(5); for (let i = 0; i < 7; i++) STICKS.push({ x: 499 + i * 47 + r() * 8 - 4, y0: 238 + r() * 14, y1: 366 + r() * 16, tilt: r() * 12 - 6 }); })();
const CRYSTALS = [];
(() => {
  const r = rng(77);
  for (let i = 0; i < 150; i++) {
    // crystals grow from the window edges inwards
    const side = Math.floor(r() * 4), u = r();
    const x = side === 0 ? WIN.x + r() * 70 : side === 1 ? WIN.x + WIN.w - r() * 70 : WIN.x + u * WIN.w;
    const y = side === 2 ? WIN.y + r() * 70 : side === 3 ? WIN.y + WIN.h - r() * 80 : WIN.y + u * WIN.h;
    CRYSTALS.push({ x, y, len: 18 + r() * 46, rot: r() * 6.28, n: 5 + Math.floor(r() * 3) });
  }
})();
let frostCanvas = null;
function mitten(x, y, a) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(x, y); ctx.rotate(-0.25);
  ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(-16, 6, 44, 150, 18); ctx.fill();
  ctx.fillStyle = '#3d6fb5'; rr(-20, 58, 46, 220, 14); ctx.fill();           // sleeve
  ctx.fillStyle = '#b8322a'; rr(-22, -4, 44, 70, [20, 20, 12, 12]); ctx.fill();   // mitten
  ctx.beginPath(); ctx.ellipse(-25, 30, 9, 16, 0.5, 0, 6.28); ctx.fill();
  ctx.fillStyle = '#e9e2d4'; rr(-22, 52, 44, 14, 4); ctx.fill();
  ctx.restore();
}
function sceneWindow(t) {
  const id = 'window', s = SC[id];
  const cBreath = cue(id, 'ДЫШИТ'), cDraw = cue(id, 'РИСУЕТ'), cEach = cue(id, 'КАЖДОГО'), cCount = cue(id, 'МАРИНА');
  const c7 = cue(id, 'СЕМЬ'), cHe = cue(id, '«ОН'), cLook = cue(id, 'СМОТРИТ»');
  // stick i is drawn during [st[i], st[i]+0.42]
  const st = STICKS.map((_, i) => i < 6 ? lerp(cDraw + 0.1, cEach + 0.15, i / 5) : cEach + 0.75);
  const sp = st.map(x => prog(t, x, 0.42));
  const breath = ease(prog(t, cBreath, 1.1));
  const rub = ease(prog(t, cHe - 0.1, 1.0));                   // patch cleared around the 7th stick
  const push = ease(prog(t, cHe - 0.2, 2.2));
  const fx = lerp(640, 762, push), fy = lerp(312, 392, push), sc = lerp(1.0, 1.9, push) * (1 + 0.06 * prog(t, s.s, s.e - s.s));
  const C = c => cam(fx, fy, sc, c, FX, 320);

  C(() => {
    ctx.fillStyle = '#0b0f18'; ctx.fillRect(-600, -400, 2400, 1800);
    // outside, seen through the glass
    ctx.save(); rr(WIN.x, WIN.y, WIN.w, WIN.h, 34); ctx.clip();
    ctx.fillStyle = vgrad(WIN.y, WIN.y + WIN.h, [[0, '#070c1e'], [0.7, '#16234a'], [1, '#2a3b68']]); ctx.fillRect(WIN.x, WIN.y, WIN.w, WIN.h);
    const r = rng(19);
    for (let x = 230; x < 1060; x += 44) spruce(x + r() * 24, 492, 150 + r() * 170, '#070c1c');
    ctx.fillStyle = '#1d2b52'; ctx.fillRect(WIN.x, 484, WIN.w, 60);
    glow(640, 450, 420, 'rgba(170,190,235,0.22)');
    glow(781, 410, 160, `rgba(176,196,240,${0.55 * ease(prog(t, cHe, 1.2))})`);
    // the seventh: a figure standing in the fog
    const fa = ease(prog(t, cHe + 0.1, 1.3)) * 0.92;
    if (fa > 0) {
      ctx.save(); ctx.globalAlpha = fa; ctx.fillStyle = '#04060d';
      const X = 781, Y = 466;
      circle(X, Y - 96, 11); ctx.fill();
      rr(X - 17, Y - 86, 34, 52, 9); ctx.fill();
      ctx.fillRect(X - 12, Y - 40, 10, 42); ctx.fillRect(X + 2, Y - 40, 10, 42);
      ctx.restore();
      
    }
    fog(t, 380, 540, 0.18, 61, '170,188,230', 6);
    ctx.restore();
  });

  // frost layer on its own canvas so the finger strokes can cut through it
  if (!frostCanvas) { frostCanvas = document.createElement('canvas'); frostCanvas.width = W * SCALE; frostCanvas.height = H * SCALE; }
  const main = ctx, fc = frostCanvas.getContext('2d');
  fc.setTransform(1, 0, 0, 1, 0, 0); fc.clearRect(0, 0, frostCanvas.width, frostCanvas.height); fc.setTransform(SCALE, 0, 0, SCALE, 0, 0);
  ctx = fc;
  C(() => {
    ctx.save(); rr(WIN.x, WIN.y, WIN.w, WIN.h, 34); ctx.clip();
    ctx.fillStyle = 'rgba(150,178,226,0.80)'; ctx.fillRect(WIN.x, WIN.y, WIN.w, WIN.h);
    const eg = ctx.createRadialGradient(640, 312, 190, 640, 312, 500);
    eg.addColorStop(0, 'rgba(225,238,255,0)'); eg.addColorStop(1, 'rgba(225,238,255,0.75)');
    ctx.fillStyle = eg; ctx.fillRect(WIN.x, WIN.y, WIN.w, WIN.h);
    ctx.strokeStyle = 'rgba(240,247,255,0.6)'; ctx.lineWidth = 1.3;
    for (const c of CRYSTALS) for (let k = 0; k < c.n; k++) {
      const a = c.rot + k * 6.28 / c.n; ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.lineTo(c.x + Math.cos(a) * c.len, c.y + Math.sin(a) * c.len); ctx.stroke();
    }
    // breath fogs the middle of the glass
    if (breath > 0) { ctx.save(); ctx.translate(640, 308); ctx.scale(1.7, 0.8); glow(0, 0, 215 * (0.5 + 0.5 * breath), `rgba(236,243,255,${0.8 * breath})`); ctx.restore(); }
    // finger strokes cut the frost away
    ctx.globalCompositeOperation = 'destination-out'; ctx.lineCap = 'round';
    STICKS.forEach((k, i) => {
      if (sp[i] <= 0) return;
      ctx.lineWidth = 15; ctx.strokeStyle = 'rgba(0,0,0,0.93)'; ctx.beginPath();
      ctx.moveTo(k.x, k.y0); ctx.lineTo(k.x + k.tilt * sp[i], lerp(k.y0, k.y1, sp[i])); ctx.stroke();
    });
    if (rub > 0) { const g = ctx.createRadialGradient(781, 420, 0, 781, 420, 165 * rub); g.addColorStop(0, 'rgba(0,0,0,0.95)'); g.addColorStop(0.6, 'rgba(0,0,0,0.8)'); g.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = g; ctx.fillRect(561, 200, 440, 440); }
    ctx.restore();
  });
  ctx = main;
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(frostCanvas, 0, 0); ctx.restore();

  C(() => {
    // window frame, rubber seal, wall
    ctx.lineWidth = 16; ctx.strokeStyle = '#1b2230'; rr(WIN.x, WIN.y, WIN.w, WIN.h, 34); ctx.stroke();
    ctx.lineWidth = 3; ctx.strokeStyle = '#39465c'; rr(WIN.x - 8, WIN.y - 8, WIN.w + 16, WIN.h + 16, 40); ctx.stroke();
    glow(260, 140, 320, 'rgba(255,180,96,0.12)');
    // counting: numbers under the sticks
    STICKS.forEach((k, i) => {
      const tc = i < 6 ? lerp(cCount + 0.05, c7 - 0.45, i / 5) : c7;
      const a = prog(t, tc, 0.12) * (1 - rub);
      if (a <= 0) return;
      text(String(i + 1), k.x + k.tilt / 2, 418, `800 ${i === 6 ? 30 : 22}px ${MONO}`, i === 6 ? ORANGE : '#f1f4fb', 'center', a);
      if (i === 6) {
        lock(k.x - 20, k.y0 - 14, 40 + k.tilt, k.y1 - k.y0 + 28, prog(t, c7, 0.4), ORANGE);
        glow(k.x, 301, 80, `rgba(255,120,20,${0.28 * prog(t, c7, 0.3)})`);
      }
    });
    // the mitten follows the stroke being drawn
    let mi = -1; sp.forEach((p, i) => { if (p > 0) mi = i; });
    const mOut = ease(prog(t, st[6] + 0.55, 0.6));
    if (mi < 0) mitten(lerp(330, STICKS[0].x - 4, ease(prog(t, cDraw - 0.5, 0.6))), lerp(780, STICKS[0].y0 + 6, ease(prog(t, cDraw - 0.5, 0.6))), prog(t, cDraw - 0.5, 0.2));
    else {
      const k = STICKS[mi], nx = STICKS[Math.min(6, mi + 1)], mv = mi < 6 ? ease(prog(t, st[mi] + 0.42, st[mi + 1] - st[mi] - 0.42)) : 0;
      const x = lerp(k.x + k.tilt * sp[mi], nx.x, mv), y = lerp(lerp(k.y0, k.y1, sp[mi]), nx.y0, mv);
      mitten(x - 4 - 60 * mOut, y + 6 + 520 * mOut, 1);
    }
    // Gosha from behind
    ctx.save(); ctx.translate(-10, -322);
    ctx.fillStyle = '#3d6fb5'; ctx.beginPath(); ctx.ellipse(170, 1130, 190, 150, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#f2c230'; circle(170, 940, 112); ctx.fill();
    ctx.strokeStyle = '#d9a916'; ctx.lineWidth = 5; for (let i = -4; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(170 + i * 24, 840 + Math.abs(i) * 9); ctx.lineTo(170 + i * 26, 1040); ctx.stroke(); }
    ctx.fillStyle = '#fff3c4'; circle(170, 826, 30); ctx.fill();
    ctx.restore();
  });
  if (t > cHe + 0.6) tag('ЗА ОКНОМ · 20 ШАГОВ', 1190, 200, { align: 'right', col: '#ff6a4a', a: prog(t, cLook, 0.3) });
  tag('ПАЛОЧЕК: ' + sp.filter(p => p >= 1).length, LM, TY, { a: prog(t, cDraw, 0.2) * (1 - push), col: sp[6] >= 1 ? ORANGE : AMBER });
  return { a: 'ВЕЧЕР 1', b: 'ОКНО', clock: fmtClock(19 * 3600 + 30 * 60 + Math.max(0, t - cue(id, '19:30'))) };
}

// =====================================================================
// Scene 6 — the rule of the taiga: never count people out loud
// =====================================================================
function sceneForest(t) {
  const id = 'forest', s = SC[id];
  const cRule = cue(id, 'ПРАВИЛО:'), cNot = cue(id, 'НЕ'), cWood = cue(id, 'ЛЕС'), cMay = cue(id, 'МОЖЕТ'), cFin = cue(id, 'ДОСЧИТАТЬ');
  const z = ease(prog(t, s.s, s.e - s.s));
  cam(lerp(330, 360, z), lerp(760, 655, z), lerp(1.25, 0.6, z), () => {
    drawWorld(t, { steps: 20, fogA: 0.2, lights: 0.6 });
    // the forest "wakes up": a dark pulse over the trees
    const dk = 0.35 * ease(prog(t, cWood, 1.2));
    ctx.fillStyle = `rgba(4,6,16,${dk})`; ctx.fillRect(-900, -1100, 2600, 3600);
    glow(BUS.x, BUS.y, 300, `rgba(255,180,100,${0.25 * dk * 2})`);
    // the bus counts six...
    const spots = [[232, 700], [268, 740], [234, 800], [270, 850], [236, 900], [270, 930]];
    spots.forEach(([x, y], i) => {
      const a = prog(t, cMay + i * 0.09, 0.1);
      if (a <= 0) return;
      circle(x, y, 15); ctx.fillStyle = `rgba(241,244,251,${a})`; ctx.fill();
      text(String(i + 1), x, y + 7, `800 18px ${MONO}`, '#10131f', 'center', a);
    });
    // ...and the forest adds the seventh
    const a7 = prog(t, cFin + 0.3, 0.2);
    if (a7 > 0) {
      const pr = ((t - cFin) * 0.9) % 1;
      ctx.strokeStyle = `rgba(255,138,31,${1 - pr})`; ctx.lineWidth = 4; circle(END.x, END.y, 26 + pr * 90); ctx.stroke();
      circle(END.x, END.y, 26); ctx.fillStyle = ORANGE; ctx.globalAlpha = a7; ctx.fill(); ctx.globalAlpha = 1;
      text('7', END.x, END.y + 11, `800 30px ${MONO}`, '#10131f', 'center', a7);
    }
  });
  snowfall(t, 60, 51, { vy: 26, vx: -16, size: 1.8, a: 0.45 });
  // the rule card
  const aR = prog(t, cRule - 0.1, 0.25);
  if (aR > 0) {
    tag('ПРАВИЛО ТАЙГИ', 250, 160, { align: 'center', a: aR, size: 17 });
    for (let i = 0; i < 6; i++) bigNum(String(i + 1), 100 + i * 60, 240, 50, '#f1f4fb', aR * prog(t, cRule + 0.15 + i * 0.1, 0.1) * (1 - 0.55 * prog(t, cNot + 0.2, 0.3)));
    const st = ease(prog(t, cNot, 0.35));
    if (st > 0) { ctx.strokeStyle = '#ff5038'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(70, 222); ctx.lineTo(70 + 360 * st, 222); ctx.stroke(); }
  }
  return { a: 'ВЕЧЕР 1', b: 'ТАЙГА', clock: fmtClock(19 * 3600 + 31 * 60 + 12 + (t - s.s)) };
}

// =====================================================================
// Scene 7 — the thermal imager: six warm shapes and a seventh, colder than snow
// =====================================================================
function heat(x, y, k, a = 1) {
  glow(x, y, 74 * k, `rgba(190,40,170,${0.6 * a})`);
  glow(x, y, 46 * k, `rgba(255,112,20,${0.95 * a})`);
  glow(x, y - 2, 24 * k, `rgba(255,236,170,${a})`);
}
let THS = 1.15;                         // current camera scale of the thermal cabin (for label offsets)
function thermalCabin(t, n, on) {
  ctx.fillStyle = '#120a33'; ctx.fillRect(-600, -400, 1600, 2400);
  cabinShell(true);
  ctx.fillStyle = '#35268a';
  for (const y of ROWS) for (const x of [230, 292, 428, 490]) { rr(x - 28, y - 34, 56, 70, 10); ctx.fill(); }
  rr(204, 904, 312, 62, 12); ctx.fill();
  glow(300, 126, 90, 'rgba(170,40,170,0.5)');                   // the heater is fading
  PEOPLE.forEach((p, i) => {
    heat(p.x, p.y, p.k, on);
    const a = prog(n, i + 0.2, 0.6);
    if (a > 0) {
      const r = 36 * p.k; lock(p.x - r, p.y - r, r * 2, r * 2, a, '#ffe9a8');
      const q = rlabel(p, r, THS);
      tag('+36°', q.x, q.y, { a, size: 12, col: '#ffe9a8', align: q.align });
    }
  });
}
function thermalWorld(t, o) {
  ctx.fillStyle = '#150c38'; ctx.fillRect(-900, -1100, 2600, 3600);
  for (const p of PATCH) glow(p.x, p.y, p.rad, p.l ? 'rgba(52,34,120,0.35)' : 'rgba(8,4,26,0.4)');
  ctx.fillStyle = 'rgba(10,6,30,0.5)'; ctx.fillRect(150, -1100, 200, 3600);
  for (const c of CROWNS) crown(c.x, c.y, c.rad, c.seed, '#0b0626', '#120a34', 'rgba(40,26,96,0.9)');
  // the bus leaks heat through its windows; the engine is still warm
  glow(BUS.x - 80, BUS.y, 120, 'rgba(190,40,170,0.35)'); glow(BUS.x + 80, BUS.y, 120, 'rgba(190,40,170,0.35)');
  busTop(true, 0, 0);
  glow(BUS.x, BUS.y - 170, 70, 'rgba(255,110,30,0.75)');
  PEOPLE.forEach((p, i) => heat(BUS.x - 40 + (i % 2) * 80, BUS.y - 110 + i * 46, 0.42, 0.9));
  // driver's footprints, highlighted one by one
  for (let i = 0; i < 20; i++) {
    const a = prog(o.trail, i, 1);
    if (a > 0) { footprint(STEPS[i], a, ORANGE); }
  }
  // object 7: darker than everything around it
  ctx.save(); ctx.translate(END.x, END.y);
  glow(0, 0, 70, 'rgba(40,120,255,0.28)');
  ctx.fillStyle = '#020108'; ctx.beginPath(); ctx.ellipse(0, 0, 19, 12, STEP_DIR + Math.PI / 2, 0, 6.28); ctx.fill();
  circle(0, 0, 8); ctx.fill();
  ctx.strokeStyle = `rgba(110,225,255,${0.55 + 0.35 * Math.sin(t * 5)})`; ctx.lineWidth = 1.4;
  ctx.beginPath(); ctx.ellipse(0, 0, 22, 15, STEP_DIR + Math.PI / 2, 0, 6.28); ctx.stroke();
  ctx.restore();
}
function sceneThermal(t) {
  const id = 'thermal', s = SC[id];
  const cSix = cue(id, 'ШЕСТЬ'), cAim = cue(id, 'НАВОДИТ'), cThere = cue(id, 'ТАМ'), c20 = cue(id, '20'), c7 = cue(id, 'СЕДЬМОЕ');
  const cBut = cue(id, 'НО'), cCold = cue(id, 'ХОЛОДНЕЕ'), cMinus = cue(id, 'МИНУС'), cAnd = cue(id, 'И'), cWhere = cue(id, 'ГДЕ'), cDrv = cue(id, 'ВОДИТЕЛЯ');
  const on = ease(prog(t, s.s + 0.25, 0.5));
  const pan = ease(prog(t, cAim + 0.1, 0.9));                    // cabin view slides away, the outside slides in
  const n = 6.6 * prog(t, cSix - 0.1, 1.3);
  if (pan < 1) {
    ctx.save(); ctx.translate(-W * pan, 0);
    THS = 1.06 + 0.05 * prog(t, s.s, cAim - s.s);
    rcam(360, 540, THS, () => thermalCabin(t, n, on), FX, 352);
    ctx.restore();
  }
  if (pan > 0) {
    const a = ease(prog(t, cThere - 0.1, c7 - cThere + 0.2));   // move from the bus to the object
    const back = ease(prog(t, cAnd - 0.2, 1.1));               // pull back to show the whole trail
    let fx = lerp(390, END.x, a), fy = lerp(690, END.y, a), sc = lerp(1.25, 2.5, a);
    fx = lerp(fx, 455, back); fy = lerp(fy, 515, back); sc = lerp(sc, 0.92, back);
    sc *= 1 + 0.05 * prog(t, c7, cAnd - c7) * (1 - back);
    ctx.save(); ctx.translate(W * (1 - pan), 0);
    ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip();
    cam(fx, fy, sc, () => {
      thermalWorld(t, { trail: 21 * prog(t, cWhere - 0.2, cDrv + 0.5 - cWhere + 0.2) });
      lock(END.x - 32, END.y - 28, 64, 56, prog(t, c7, 0.45), '#6ee1ff');
      // distance chevrons from the bus to the object
      const ch = prog(t, c20 - 0.1, 0.6) * (1 - back);
      if (ch > 0) for (let i = 2; i < 19; i += 2) {
        const q = pathAt(i / 20), a2 = clamp(ch * 10 - i / 2);
        ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(STEP_DIR); ctx.strokeStyle = `rgba(241,244,251,${0.8 * a2})`; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.moveTo(-4, -5); ctx.lineTo(2, 0); ctx.lineTo(-4, 5); ctx.stroke(); ctx.restore();
      }
    });
    ctx.restore();
    // readouts
    tag('ОБЪЕКТ 7', FX, FY - 104, { align: 'center', col: '#6ee1ff', a: prog(t, c7 + 0.1, 0.25) * (1 - back), size: 16 });
    tag('20 ШАГОВ ОТ ДВЕРИ', LM, TY, { a: prog(t, c20, 0.25), col: '#f1f4fb' });
    const aB = prog(t, cBut, 0.25) * (1 - back);
    tag('ТЕПЛО: НЕТ', FX, FY + 120, { align: 'center', a: aB * (1 - prog(t, cCold - 0.1, 0.2)), col: '#ff6a4a', size: 17 });
    const aC = prog(t, cCold - 0.05, 0.25) * (1 - back);
    if (aC > 0) {
      // comparison bars: snow vs object
      const bars = [['СНЕГ', 43, '#8a6cf0', cCold], ['ОБЪЕКТ 7', lerp(43, 60, easeOut(prog(t, cMinus, 0.7))), '#6ee1ff', cCold + 0.25]];
      bars.forEach(([lab, v, col, c], i) => {
        const a = aC * prog(t, c, 0.2), y = 262 + i * 40;
        tag(lab, 840, y + 14, { a, col: '#cdd6e8', size: 14 });
        ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = 'rgba(8,10,20,0.7)'; rr(950, y - 3, 190, 20, 4); ctx.fill();
        ctx.fillStyle = col; rr(950, y - 3, 190 * v / 62, 20, 4); ctx.fill(); ctx.restore();
        text('−' + Math.round(v) + '°', 1150, y + 14, `700 17px ${MONO}`, col, 'left', a);
      });
    }
    const aM = prog(t, cMinus - 0.05, 0.15) * (1 - back);
    if (aM > 0) bigNum('−' + Math.round(lerp(43, 60, easeOut(prog(t, cMinus, 0.7)))) + '°', 1010, 226, 96, '#bfefff', aM);
    if (back > 0) {
      tag('СЛЕДЫ ВОДИТЕЛЯ', LM, TY + 36, { a: prog(t, cWhere, 0.25), col: ORANGE });
      tag('СЛЕД № 20 = ОБЪЕКТ 7', 800, 182, { a: prog(t, cDrv + 0.4, 0.3), col: ORANGE, size: 17 });
    }
  }
  if (pan < 1) {
    tag('ТЁПЛЫХ ОБЪЕКТОВ', LM - W * pan, TY, { col: '#ffe9a8' });
    text(Math.min(6, Math.floor(n)) + ' / 6', LM + 200 - W * pan, TY + 2, `700 22px ${MONO}`, '#ffe9a8');
  }
  // imager UI: header, colour scale, scan lines, switch-on sweep
  ctx.fillStyle = Math.sin(t * 5) > 0 ? '#ff3b30' : '#7a1a15'; circle(FX - 62, 61, 5); ctx.fill();
  text('ТЕПЛОВИЗОР', FX - 48, 67, `600 16px ${MONO}`, '#cdd6e8');
  const g = ctx.createLinearGradient(0, 150, 0, 490);
  [[0, '#fff3c0'], [0.25, '#ff8a1f'], [0.5, '#be28aa'], [0.75, '#3b2a86'], [1, '#02010a']].forEach(([p, c]) => g.addColorStop(p, c));
  ctx.fillStyle = g; rr(1240, 150, 8, 340, 4); ctx.fill();
  text('+37°', 1234, 162, `600 11px ${MONO}`, '#cdd6e8', 'right'); text('−60°', 1234, 490, `600 11px ${MONO}`, '#cdd6e8', 'right');
  ctx.fillStyle = 'rgba(10,6,30,0.16)'; for (let y = 0; y < H; y += 4) ctx.fillRect(0, y, W, 1);
  if (on < 1) { ctx.fillStyle = `rgba(3,2,10,${1 - on})`; ctx.fillRect(0, 0, W, H); ctx.fillStyle = `rgba(190,160,255,${0.6 * (1 - on)})`; ctx.fillRect(0, H * on * 0.7, W, 3); }
  return { a: 'ВЕЧЕР 1', b: pan < 0.5 ? 'САЛОН' : 'ЗА ОКНОМ', clock: fmtClock(19 * 3600 + 32 * 60 + 40 + (t - s.s)) };
}

// =====================================================================
// Scene 8 — zoom: the seventh wears Timur's jacket and holds his camera
// =====================================================================
function figure(colorK, t, rec) {
  // drawn in a 500px-tall box centred on (0,0); colorK blends silhouette -> colour as the zoom cuts through the fog
  const mix = (c, d = '#070a14') => {
    const h = x => [parseInt(x.slice(1, 3), 16), parseInt(x.slice(3, 5), 16), parseInt(x.slice(5, 7), 16)];
    const a = h(d), b = h(c); return `rgb(${a.map((v, i) => Math.round(lerp(v, b[i], colorK))).join(',')})`;
  };
  const coat = mix('#e8731a'), coatD = mix('#a94f10'), black = mix('#14161c'), snow = mix('#c9d6f2');
  ctx.fillStyle = 'rgba(4,6,14,0.5)'; ctx.beginPath(); ctx.ellipse(0, 252, 120, 16, 0, 0, 6.28); ctx.fill();
  // legs + boots
  ctx.fillStyle = mix('#1a1e29'); rr(-52, 92, 44, 150, 10); ctx.fill(); rr(8, 92, 44, 150, 10); ctx.fill();
  ctx.fillStyle = black; rr(-60, 222, 56, 30, 10); ctx.fill(); rr(4, 222, 56, 30, 10); ctx.fill();
  // puffer jacket
  rr(-86, -130, 172, 240, [50, 50, 26, 26]); ctx.fillStyle = coat; ctx.fill();
  ctx.fillStyle = coatD; for (let i = 0; i < 5; i++) ctx.fillRect(-86, -78 + i * 40, 172, 5);
  ctx.fillRect(-3, -130, 6, 240);
  // arms bent, holding the camera at the chest
  ctx.fillStyle = coat; rr(-118, -108, 46, 150, 22); ctx.fill(); rr(72, -108, 46, 150, 22); ctx.fill();
  ctx.save(); ctx.translate(-96, 30); ctx.rotate(-0.95); rr(-22, -16, 100, 40, 20); ctx.fill(); ctx.restore();
  ctx.save(); ctx.translate(96, 30); ctx.rotate(0.95); rr(-78, -16, 100, 40, 20); ctx.fill(); ctx.restore();
  // camera
  rr(-52, -44, 104, 68, 9); ctx.fillStyle = black; ctx.fill();
  rr(-30, -58, 40, 18, 5); ctx.fill();
  circle(0, -8, 26); ctx.fillStyle = mix('#232a3a'); ctx.fill();
  circle(0, -8, 17); ctx.fillStyle = mix('#0b1022', '#03040a'); ctx.fill();
  ctx.fillStyle = `rgba(190,215,255,${0.75 * colorK})`; circle(-6, -14, 4.5); ctx.fill();
  ctx.fillStyle = black; circle(-50, 4, 15); ctx.fill(); circle(50, 4, 15); ctx.fill();      // gloves
  if (rec > 0) { glow(38, -34, 30 + 20 * rec, `rgba(255,40,30,${0.9 * rec})`); ctx.fillStyle = `rgba(255,70,50,${rec})`; circle(38, -34, 5); ctx.fill(); }
  // hood, hat and no face at all
  circle(0, -176, 54); ctx.fillStyle = coat; ctx.fill();
  ctx.beginPath(); ctx.ellipse(0, -170, 36, 42, 0, 0, 6.28); ctx.fillStyle = '#020308'; ctx.fill();
  ctx.fillStyle = black; ctx.beginPath(); ctx.ellipse(0, -200, 37, 20, 0, Math.PI, 0); ctx.fill();
  // it has been standing long enough for the snow to settle on it
  ctx.fillStyle = snow; ctx.beginPath(); ctx.ellipse(0, -224, 40, 10, 0, Math.PI, 0); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-92, -112, 26, 8, -0.3, Math.PI, 0); ctx.fill(); ctx.beginPath(); ctx.ellipse(92, -112, 26, 8, 0.3, Math.PI, 0); ctx.fill();
}
function sceneFigure(t) {
  const id = 'figure', s = SC[id];
  const cZoom = cue(id, 'ПРИБЛИЖАЕТ'), cCoat = cue(id, 'КУРТКА'), cCam = cue(id, 'КАМЕРА'), cRec = cue(id, 'СНИМАЕТ');
  // stepped zoom ×1 → ×2 → ×4 → ×8
  const zt = [cZoom + 0.15, cZoom + 0.7, cZoom + 1.25];
  let lz = 0; zt.forEach(x => lz += easeOut(prog(t, x, 0.22)));
  const z = Math.pow(2, lz) * (1 + 0.035 * prog(t, cCoat, s.e - cCoat));
  const zn = Math.round(Math.pow(2, Math.round(lz)));
  const colorK = clamp((lz - 1) / 2) * 0.7;
  const rec = prog(t, cRec - 0.1, 0.3) * (0.55 + 0.45 * (Math.sin(t * 7) > 0 ? 1 : 0.2));
  const shake = t > cRec ? Math.sin(t * 40) * 1.2 * (1 - prog(t, cRec, 0.5)) : 0;
  cam(640, 470, z, () => {
    ctx.fillStyle = vgrad(-200, 640, [[0, '#050814'], [0.7, '#141e3d'], [1, '#27365f']]); ctx.fillRect(-800, -500, 2900, 1160);
    ctx.fillStyle = vgrad(600, 1500, [[0, '#2c3d6a'], [1, '#0d1326']]); ctx.fillRect(-800, 600, 2900, 1200);
    const r = rng(23);
    ctx.save(); ctx.globalAlpha = 1 - clamp(lz - 0.6);
    for (let x = -60; x < 1360; x += 46) spruce(x + r() * 26, 612, 150 + r() * 170, '#090e1f');
    ctx.restore();
    glow(640, 520, 380, 'rgba(180,198,240,0.25)');
    // the figure is 62px tall in the wide shot
    ctx.save(); ctx.translate(640 + shake / z, 470); ctx.scale(0.125, 0.125); figure(colorK, t, rec); ctx.restore();
  }, FX, 300);
  fog(t, 150, 560, 0.12, 71);
  ctx.fillStyle = 'rgba(40,60,120,0.16)'; ctx.fillRect(0, 0, W, H);
  snowfall(t, 90, 81, { vy: 44, vx: -26, a: 0.55 });
  // viewfinder
  bracket(150, 104, 980, 450, 'rgba(230,236,248,0.75)', 1, 34, 2.5);
  ctx.strokeStyle = 'rgba(230,236,248,0.5)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(626, 300); ctx.lineTo(654, 300); ctx.moveTo(640, 286); ctx.lineTo(640, 314); ctx.stroke();
  tag('ZOOM ×' + zn, 172, 140, { col: '#f1f4fb', size: 17 });
  // zoom flash on every step
  zt.forEach(x => { const f = pulse(t, x, 0.2); if (f > 0) { ctx.fillStyle = `rgba(210,225,255,${0.2 * f})`; ctx.fillRect(0, 0, W, H); } });
  // match 1: the jacket
  const p1 = prog(t, cCoat - 0.2, 0.4);
  if (p1 > 0) {
    lock(518, 158, 244, 250, p1, ORANGE);
    const a = prog(t, cCoat, 0.25);
    const ox = 330, oy = -60;
    ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = 'rgba(8,10,20,0.85)'; rr(470 + ox, 222 + oy, 172, 96, 6); ctx.fill(); ctx.strokeStyle = ORANGE; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = '#f07a1a'; ctx.beginPath(); ctx.ellipse(512 + ox, 270 + oy, 26, 16, 0, 0, 6.28); ctx.fill(); ctx.fillStyle = '#15171c'; circle(512 + ox, 267 + oy, 12); ctx.fill();
    ctx.restore();
    text('ТИМУР', 548 + ox, 262 + oy, `700 15px ${MONO}`, '#f1f4fb', 'left', a);
    text('КУРТКА', 548 + ox, 284 + oy, `600 12px ${MONO}`, '#9aa6bf', 'left', a);
    text('= 100%', 548 + ox, 304 + oy, `700 13px ${MONO}`, ORANGE, 'left', a);
  }
  // match 2: the camera
  const p2 = prog(t, cCam - 0.2, 0.4);
  if (p2 > 0) {
    lock(576, 222, 128, 100, p2, '#ffe9a8');
    tag('КАМЕРА · ТА ЖЕ', 800, 300, { a: prog(t, cCam, 0.25), col: '#ffe9a8' });
  }
  if (t > cRec - 0.1) {
    tag('● REC', 172, 174, { col: '#ff3b30', a: Math.sin(t * 7) > 0 ? 1 : 0.35, size: 17 });
    tag('В КАДРЕ: АВТОБУС', 800, 400, { col: '#ff6a4a', a: prog(t, cRec + 0.5, 0.3), size: 17 });
    ctx.fillStyle = `rgba(255,30,20,${0.07 * Math.abs(Math.sin((t - cRec) * 3.6))})`; ctx.fillRect(0, 0, W, H);
  }
  return { a: 'ВЕЧЕР 1', b: 'ZOOM ×' + zn, clock: fmtClock(19 * 3600 + 34 * 60 + 2 + (t - s.s)) };
}

// =====================================================================
// Scene 9 — a new file on Timur's camera, dated tomorrow
// =====================================================================
function sceneFile(t) {
  const id = 'file', s = SC[id];
  const cNew = cue(id, 'НОВЫЙ'), cRec = cue(id, 'ЗАПИСЬ'), cTom = cue(id, 'ЗАВТРАШНИМ');
  const z = 1 + 0.05 * prog(t, s.s, s.e - s.s) + 0.22 * ease(prog(t, cTom - 0.2, 0.8));
  const fx = lerp(640, 620, ease(prog(t, cTom - 0.2, 0.8))), fy = lerp(300, 236, ease(prog(t, cTom - 0.2, 0.8)));
  const ins = easeOut(prog(t, cNew - 0.05, 0.35));
  cam(fx, fy, z, () => {
    ctx.fillStyle = '#06080e'; ctx.fillRect(-600, -300, 2400, 1400);
    glow(640, 300, 640, 'rgba(70,110,200,0.22)');
    // camera body with the screen, held in gloves
    rr(230, 66, 820, 474, 34); ctx.fillStyle = '#161a22'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#2b3240'; ctx.stroke();
    rr(264, 102, 752, 404, 10); ctx.fillStyle = '#080d1c'; ctx.fill();
    ctx.save(); rr(264, 102, 752, 404, 10); ctx.clip();
    glow(640, 300, 480, 'rgba(60,96,190,0.25)');
    text('ФАЙЛЫ', 300, 148, `700 19px ${MONO}`, '#cdd6e8');
    text('СЕГОДНЯ: 14.01', 984, 148, `700 19px ${MONO}`, t > cTom ? '#f1f4fb' : '#8a96b0', 'right');
    ctx.fillStyle = 'rgba(140,160,210,0.25)'; ctx.fillRect(300, 164, 684, 2);
    const rows = [['REC_0043', '14.01', '19:33', 'rec'], ['REC_0042', '14.01', '18:03', '00:48'], ['REC_0041', '14.01', '17:52', '02:14']];
    rows.forEach((r, i) => {
      const y = 220 + i * 64 + 64 * ins;
      text(r[0], 300, y, `600 22px ${MONO}`, '#aeb9d0'); text(r[1], 560, y, `600 22px ${MONO}`, '#aeb9d0'); text(r[2], 700, y, `600 22px ${MONO}`, '#aeb9d0');
      if (r[3] === 'rec') { ctx.fillStyle = Math.sin(t * 6) > 0 ? '#ff3b30' : '#6a1a16'; circle(916, y - 8, 6); ctx.fill(); text('REC', 930, y, `700 18px ${MONO}`, '#ff6a4a'); }
      else text(r[3], 984, y, `600 22px ${MONO}`, '#7f8ca6', 'right');
    });
    if (ins > 0) {
      const y = 220, fl = 1 - prog(t, cNew, 0.5);
      ctx.fillStyle = `rgba(255,255,255,${0.1 + 0.5 * fl})`; rr(286, y - 34, 712, 50, 6); ctx.fill();
      ctx.globalAlpha = ins;
      text('REC_0044', 300, y, `800 22px ${MONO}`, '#ffffff');
      text('15.01', 560, y, `800 22px ${MONO}`, t > cTom ? ORANGE : '#ffffff');
      text('06:12', 700, y, `800 22px ${MONO}`, '#ffffff'); text('01:37', 984, y, `800 22px ${MONO}`, '#ffffff', 'right');
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = 'rgba(0,0,0,0.14)'; for (let y = 102; y < 506; y += 3) ctx.fillRect(264, y, 752, 1);
    ctx.restore();
    // gloves
    ctx.fillStyle = '#0c0e14'; ctx.beginPath(); ctx.ellipse(196, 470, 70, 130, 0.25, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(1084, 470, 70, 130, -0.25, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#b85a12'; ctx.beginPath(); ctx.ellipse(166, 670, 80, 110, 0.3, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(1114, 670, 80, 110, -0.3, 0, 6.28); ctx.fill();
    const pT = prog(t, cTom, 0.4);
    if (pT > 0) {
      lock(550, 190, 92, 42, pT, ORANGE);
      tag('ЗАВТРА', 596, 184, { align: 'center', col: ORANGE, a: pT, size: 16 });
      lock(778, 124, 210, 34, prog(t, cTom + 0.5, 0.4), '#f1f4fb');
    }
    tag('НОВЫЙ ФАЙЛ', 300, 178, { a: prog(t, cNew, 0.2) * (1 - prog(t, cRec, 0.3)), col: '#ffe9a8', size: 12 });
  });
  // glitch right before the cut
  const gl = prog(t, s.e - 0.75, 0.75);
  if (gl > 0) {
    const r = rng(Math.floor(t * 24));
    for (let i = 0; i < 9; i++) {
      const y = r() * 620 * SCALE, h = (8 + r() * 46) * SCALE, dx = (r() - 0.5) * 120 * gl * SCALE;
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(ctx.canvas, 0, y, W * SCALE, h, dx, y, W * SCALE, h); ctx.restore();
    }
    ctx.fillStyle = `rgba(255,255,255,${0.06 * gl * (r() > 0.5 ? 1 : 0)})`; ctx.fillRect(0, 0, W, H);
  }
  return { a: 'ВЕЧЕР 1', b: 'КАМЕРА ТИМУРА', clock: fmtClock(19 * 3600 + 35 * 60 + 20 + (t - s.s)) };
}

