// =====================================================================
// Scene 1 — side view: the bus stalls on the winter road
// =====================================================================
function busSide(x, y, lights) {
  ctx.save();
  // shadow
  ctx.fillStyle = 'rgba(5,8,18,0.55)'; ctx.beginPath(); ctx.ellipse(x, y + 4, 215, 13, 0, 0, 6.28); ctx.fill();
  // headlight cone (front is on the right)
  const g = ctx.createLinearGradient(x + 190, 0, x + 560, 0);
  g.addColorStop(0, `rgba(255,226,160,${0.5 * lights})`); g.addColorStop(1, 'rgba(255,226,160,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x + 188, y - 62); ctx.lineTo(x + 600, y - 150); ctx.lineTo(x + 600, y + 30); ctx.lineTo(x + 188, y - 44); ctx.fill();
  // body
  rr(x - 190, y - 158, 380, 138, [34, 30, 12, 12]); ctx.fillStyle = '#2d4639'; ctx.fill();
  rr(x - 190, y - 74, 380, 54, [0, 0, 12, 12]); ctx.fillStyle = '#22352c'; ctx.fill();
  ctx.fillStyle = '#8d8a76'; ctx.fillRect(x - 190, y - 78, 380, 6);
  // snow on the roof
  rr(x - 184, y - 166, 366, 16, 8); ctx.fillStyle = '#aebde0'; ctx.fill();
  // windows
  const wx = [-172, -112, -52, 8, 68];
  wx.forEach((dx, i) => {
    rr(x + dx, y - 142, 52, 54, 7);
    const wg = ctx.createLinearGradient(0, y - 142, 0, y - 88);
    wg.addColorStop(0, `rgba(255,214,140,${0.25 + 0.7 * lights})`); wg.addColorStop(1, `rgba(214,128,40,${0.25 + 0.7 * lights})`);
    ctx.fillStyle = '#141a22'; ctx.fill(); ctx.fillStyle = wg; ctx.fill();
    // frost in the corners
    ctx.fillStyle = 'rgba(210,228,255,0.35)';
    ctx.beginPath(); ctx.moveTo(x + dx, y - 88); ctx.lineTo(x + dx + 20, y - 88); ctx.lineTo(x + dx, y - 112); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x + dx + 52, y - 142); ctx.lineTo(x + dx + 34, y - 142); ctx.lineTo(x + dx + 52, y - 124); ctx.fill();
  });
  // heads in the windows
  ctx.fillStyle = 'rgba(20,16,14,0.85)';
  [[-150, 0], [-84, 3], [-30, -2], [34, 2], [88, 0], [98, 12]].forEach(([dx, dy], i) => {
    const r = i === 5 ? 7 : 10;
    circle(x + dx, y - 104 + dy, r); ctx.fill(); ctx.fillRect(x + dx - r - 3, y - 96 + dy, r * 2 + 6, 10);
  });
  // windshield + door
  ctx.beginPath(); ctx.moveTo(x + 132, y - 142); ctx.lineTo(x + 172, y - 142); ctx.lineTo(x + 184, y - 88); ctx.lineTo(x + 132, y - 88); ctx.closePath();
  ctx.fillStyle = `rgba(190,170,120,${0.25 + 0.35 * lights})`; ctx.fill();
  ctx.strokeStyle = '#17241e'; ctx.lineWidth = 2; ctx.strokeRect(x + 128, y - 146, 1, 122);
  // wheels
  for (const dx of [-118, 112]) {
    circle(x + dx, y - 20, 29); ctx.fillStyle = '#0c0f15'; ctx.fill();
    circle(x + dx, y - 20, 12); ctx.fillStyle = '#39424f'; ctx.fill();
    ctx.fillStyle = '#b7c4e4'; ctx.beginPath(); ctx.ellipse(x + dx, y - 50, 34, 7, 0, Math.PI, 0); ctx.fill();
  }
  // lamps
  glow(x + 188, y - 53, 60, `rgba(255,236,180,${0.9 * lights})`);
  circle(x + 186, y - 53, 7); ctx.fillStyle = `rgba(255,244,210,${0.4 + 0.6 * lights})`; ctx.fill();
  glow(x - 190, y - 60, 26, 'rgba(255,40,30,0.7)');
  ctx.restore();
}

function sceneBus(t) {
  const s = SC.bus, lt = t - s.s, D = s.e - s.s;
  const cTime = cue('bus', '18:04'), cKm = cue('bus', '9'), cTemp = cue('bus', 'МИНУС');
  const roll = easeOut(prog(lt, 0, 1.3));
  const busX = lerp(215, 330, roll) + (lt < 1.5 ? Math.sin(lt * 70) * 1.6 * (1 - prog(lt, 1.0, 0.5)) : 0);
  // engine dies: lights flicker and settle dimmer
  let lights = 1;
  if (lt > 1.1 && lt < 2.3) lights = 0.45 + 0.5 * Math.abs(Math.sin(lt * 31)) * (Math.sin(lt * 9) > -0.2 ? 1 : 0.2);
  else if (lt >= 2.3) lights = 0.72;
  cam(345, 530, 1.22 + 0.1 * ease(lt / D), () => {
    ctx.fillStyle = vgrad(0, 620, [[0, '#070b1a'], [0.6, '#131d3a'], [1, '#2a3962']]); ctx.fillRect(-400, -60, W + 800, 700);
    glow(770, 330, 190, 'rgba(190,205,240,0.22)'); circle(770, 330, 24); ctx.fillStyle = 'rgba(214,224,246,0.75)'; ctx.fill();
    const r = rng(11);
    for (let x = -300; x < 1100; x += 34) spruce(x + r() * 20, 566, 110 + r() * 110, '#17223f');
    fog(t, 430, 560, 0.16, 3);
    for (let x = -300; x < 1100; x += 62) spruce(x + r() * 34, 590, 200 + r() * 150, '#0b1227', 'rgba(110,134,190,0.35)');
    // ground
    ctx.fillStyle = vgrad(575, 1300, [[0, '#3c5083'], [0.25, '#26355d'], [1, '#0d1326']]); ctx.fillRect(-400, 575, W + 800, 760);
    ctx.fillStyle = 'rgba(16,24,48,0.5)'; ctx.fillRect(-400, 648, W + 800, 5); ctx.fillRect(-400, 668, W + 800, 4);
    // light spilled from the windows onto the snow
    glow(busX - 30, 668, 210, `rgba(255,180,90,${0.22 * lights})`);
    busSide(busX, 668, lights);
    fog(t, 560, 700, 0.2, 5);
    // foreground trees frame the shot
    spruce(-290, 1000, 620, '#050812'); spruce(1010, 1040, 680, '#050812');
    fog(t * 1.4, 600, 820, 0.13, 8);
  });
  snowfall(t, 150, 21, { vy: 60, vx: -30 });
  snowfall(t, 40, 22, { vy: 95, vx: -50, size: 3.6, a: 0.5 });

  // overlays
  const aT = prog(t, cTime - 0.1, 0.15) * (1 - prog(t, cKm - 0.3, 0.3));
  if (aT > 0) {
    const fl = t - cTime < 0.35 ? (Math.sin(t * 90) > 0 ? 1 : 0.35) : 1;
    bigNum('18:04:00', FX, 236, 76, '#f1f4fb', aT * fl);
    tag('ДВИГАТЕЛЬ · СТОП', FX, 150, { align: 'center', col: '#ff6a4a', a: aT * fl });
  }
  const aK = prog(t, cKm - 0.15, 0.25) * (1 - prog(t, cTemp - 0.3, 0.3));
  if (aK > 0) {
    const p = easeOut(prog(t, cKm - 0.1, 0.9));
    ctx.save(); ctx.globalAlpha = aK; ctx.strokeStyle = 'rgba(214,221,235,0.8)'; ctx.lineWidth = 2; ctx.setLineDash([9, 8]);
    ctx.beginPath(); ctx.moveTo(300, 214); ctx.lineTo(300 + 680 * p, 214); ctx.stroke(); ctx.setLineDash([]);
    circle(300, 214, 7); ctx.fillStyle = ORANGE; ctx.fill();
    if (p > 0.95) { ctx.fillStyle = '#e6ebf5'; ctx.beginPath(); ctx.moveTo(980, 199); ctx.lineTo(996, 227); ctx.lineTo(964, 227); ctx.fill(); }
    ctx.restore();
    tag('АВТОБУС', 300, 258, { align: 'center', a: aK, col: ORANGE });
    tag('ПЕРЕВАЛ', 980, 258, { align: 'center', a: aK * prog(p, 0.9, 0.1), col: '#e6ebf5' });
    bigNum(Math.round(9 * p) + ' КМ', FX, 180, 60, '#f1f4fb', aK);
  }
  const aC = prog(t, cTemp - 0.1, 0.2);
  if (aC > 0) {
    const v = Math.round(lerp(-20, -43, easeOut(prog(t, cTemp, 0.9))));
    bigNum((v + '°').replace('-', '−'), FX, 262, 128, '#cfe2ff', aC);
    tag('ЗА БОРТОМ', FX, 140, { align: 'center', a: aC, col: '#9fc0ff' });
    // frost creeping in from the edges
    ctx.save(); ctx.globalAlpha = 0.35 * aC;
    const g = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820);
    g.addColorStop(0, 'rgba(170,205,255,0)'); g.addColorStop(1, 'rgba(170,205,255,0.5)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  return { a: 'ВЕЧЕР 1', b: 'ТРАССА', clock: fmtClock(18 * 3600 + 4 * 60 + Math.max(0, t - cTime)) };
}

// =====================================================================
// Top-down world shared by scenes 2, 6 and 7
// =====================================================================
const BUS = { x: 250, y: 820, w: 150, l: 400 };
const DOOR = { x: 345, y: 672 };
const END = { x: 560, y: 330 };
const STEP_DIR = Math.atan2(END.y - DOOR.y, END.x - DOOR.x);
function pathAt(p) {
  return { x: lerp(DOOR.x, END.x, p) + Math.sin(p * Math.PI) * 18, y: lerp(DOOR.y, END.y, p) - Math.sin(p * Math.PI) * 10 };
}
const STEPS = [];
for (let i = 0; i < 20; i++) {
  const q = pathAt((i + 1) / 20), side = i % 2 ? 1 : -1;
  STEPS.push({ x: q.x + Math.cos(STEP_DIR + Math.PI / 2) * 7 * side, y: q.y + Math.sin(STEP_DIR + Math.PI / 2) * 7 * side });
}
const CROWNS = [];
(() => {
  const r = rng(7);
  for (let gy = -1100; gy < 2500; gy += 84) for (let gx = -900; gx < 1700; gx += 84) {
    const x = gx + r() * 56 - 28, y = gy + r() * 56 - 28, rad = 40 + r() * 26, seed = Math.floor(r() * 1e6);
    if (x > 92 && x < 408) continue;
    if (x >= 408 && x < 645 && y > 210 && y < 1160) continue;
    CROWNS.push({ x, y, rad, seed });
  }
})();
const PATCH = [];
(() => { const r = rng(31); for (let i = 0; i < 70; i++) PATCH.push({ x: r() * 2600 - 900, y: r() * 3600 - 1100, rad: 120 + r() * 240, l: r() > 0.5 }); })();

function busTop(th, lights, door) {
  const { x, y, w, l } = BUS, x0 = x - w / 2, y0 = y - l / 2;
  ctx.save();
  if (!th) {
    // headlight cones (front is up) and light from the windows
    for (const dx of [-45, 45]) {
      const g = ctx.createLinearGradient(0, y0, 0, y0 - 420);
      g.addColorStop(0, `rgba(255,228,170,${0.42 * lights})`); g.addColorStop(1, 'rgba(255,228,170,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x + dx - 10, y0 + 6); ctx.lineTo(x + dx - 90, y0 - 420); ctx.lineTo(x + dx + 90, y0 - 420); ctx.lineTo(x + dx + 10, y0 + 6); ctx.fill();
    }
    glow(x0 - 30, y, 150, `rgba(255,176,90,${0.2 * lights})`); glow(x0 + w + 30, y, 150, `rgba(255,176,90,${0.2 * lights})`);
    ctx.fillStyle = 'rgba(6,10,22,0.45)'; rr(x0 + 10, y0 + 14, w, l, 26); ctx.fill();
  }
  rr(x0, y0, w, l, [34, 34, 18, 18]); ctx.fillStyle = th ? '#3b2a86' : '#2d4639'; ctx.fill();
  ctx.lineWidth = 3; ctx.strokeStyle = th ? '#5a44b4' : '#1a2a22'; ctx.stroke();
  if (!th) {
    rr(x0 + 12, y0 + 56, w - 24, l - 80, 14); ctx.fillStyle = '#35523f'; ctx.fill();
    // snow dusting + hatches
    ctx.fillStyle = 'rgba(190,206,240,0.55)';
    rr(x0 + 18, y0 + 70, w - 36, 44, 16); ctx.fill(); rr(x0 + 24, y0 + 250, w - 60, 60, 20); ctx.fill(); rr(x0 + 40, y0 + 340, w - 62, 34, 14); ctx.fill();
    ctx.fillStyle = '#22362b'; rr(x - 26, y0 + 140, 52, 44, 6); ctx.fill(); rr(x - 26, y0 + 215, 52, 26, 6); ctx.fill();
    // windshield
    ctx.fillStyle = `rgba(200,180,130,${0.3 + 0.3 * lights})`; rr(x0 + 14, y0 + 10, w - 28, 34, [18, 18, 4, 4]); ctx.fill();
    if (door > 0) {
      const dg = ctx.createLinearGradient(x0 + w, 0, x0 + w + 95, 0);
      dg.addColorStop(0, `rgba(255,196,120,${0.75 * door})`); dg.addColorStop(1, 'rgba(255,196,120,0)');
      ctx.fillStyle = dg; ctx.beginPath(); ctx.moveTo(x0 + w, DOOR.y - 20); ctx.lineTo(x0 + w + 90, DOOR.y - 46); ctx.lineTo(x0 + w + 90, DOOR.y + 46); ctx.lineTo(x0 + w, DOOR.y + 20); ctx.fill();
      ctx.strokeStyle = '#1a2a22'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(x0 + w, DOOR.y - 20); ctx.lineTo(x0 + w + 22 * door, DOOR.y - 34); ctx.stroke();
    }
  }
  ctx.restore();
}
function footprint(q, a = 1, col = '#18233f') {
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(q.x, q.y); ctx.rotate(STEP_DIR);
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(1, 0, 7.5, 4.2, 0, 0, 6.28); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-8, 0, 3.6, 3.4, 0, 0, 6.28); ctx.fill();
  ctx.fillStyle = 'rgba(205,220,250,0.35)'; ctx.beginPath(); ctx.ellipse(2, -4.6, 7, 1.4, 0, 0, 6.28); ctx.fill();
  ctx.restore();
}
function drawWorld(t, o = {}) {
  const { lights = 0.72, door = 0, steps = 0, fogA = 0.2 } = o;
  ctx.fillStyle = '#31446f'; ctx.fillRect(-900, -1100, 2600, 3600);
  for (const p of PATCH) glow(p.x, p.y, p.rad, p.l ? 'rgba(98,122,178,0.28)' : 'rgba(22,32,62,0.3)');
  // road
  const g = ctx.createLinearGradient(120, 0, 380, 0);
  g.addColorStop(0, 'rgba(26,36,66,0)'); g.addColorStop(0.2, 'rgba(26,36,66,0.6)'); g.addColorStop(0.8, 'rgba(26,36,66,0.6)'); g.addColorStop(1, 'rgba(26,36,66,0)');
  ctx.fillStyle = g; ctx.fillRect(120, -1100, 260, 3600);
  ctx.fillStyle = 'rgba(14,22,46,0.5)'; ctx.fillRect(196, -1100, 9, 3600); ctx.fillRect(296, -1100, 9, 3600);
  for (let i = 0; i < Math.min(20, Math.floor(steps)); i++) footprint(STEPS[i]);
  busTop(false, lights, door);
  for (const c of CROWNS) {
    const sw = Math.sin(t * 0.7 + c.seed) * 1.5;
    ctx.fillStyle = 'rgba(8,12,26,0.35)'; circle(c.x + 14, c.y + 18, c.rad * 0.9); ctx.fill();
    crown(c.x + sw, c.y, c.rad, c.seed, '#0d1a2c', '#16293c', 'rgba(170,190,230,0.75)');
  }
  if (fogA > 0) {
    glow(END.x + 60, END.y - 90, 420, `rgba(190,205,240,${fogA})`);
    glow(END.x - 120 + Math.sin(t * 0.3) * 40, END.y + 60, 300, `rgba(190,205,240,${fogA * 0.6})`);
  }
}
function driverTop(q, a, lantern) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a;
  glow(q.x + 14, q.y - 12, 95, `rgba(255,190,100,${0.5 * lantern})`);
  ctx.translate(q.x, q.y); ctx.rotate(STEP_DIR + Math.PI / 2);
  ctx.fillStyle = '#1b2031'; ctx.beginPath(); ctx.ellipse(0, 0, 17, 10, 0, 0, 6.28); ctx.fill();
  ctx.fillStyle = '#5a4634'; circle(0, -2, 7.5); ctx.fill();
  ctx.fillStyle = `rgba(255,224,150,${lantern})`; circle(19, -10, 3.5); ctx.fill();
  ctx.restore();
}

// =====================================================================
// Scene 2 — the driver's footprints stop after 20 steps
// =====================================================================
function sceneTracks(t) {
  const id = 'tracks', s = SC[id];
  const cDoor = cue(id, '«СХОЖУ'), cWalk = cue(id, 'ВЗЯЛ'), cFog = cue(id, 'ТУМАН'), cHis = cue(id, 'ЕГО');
  const c20 = cue(id, '20'), cEnd = cue(id, 'ОБРЫВАЮТСЯ'), cBlood = cue(id, 'КРОВИ'), cFight = cue(id, 'СЛЕДОВ'), cClean = cue(id, 'ЧИСТЫЙ');
  const door = ease(prog(t, cDoor, 0.5));
  const wp = prog(t, cWalk, cFog + 1.0 - cWalk);                 // walk progress
  const wq = pathAt(ease(wp));
  // camera: door -> follow -> whole path -> last footprint
  let fx = lerp(330, wq.x, ease(prog(t, cWalk, 1))), fy = lerp(690, wq.y, ease(prog(t, cWalk, 1))), sc = 1.55;
  const z1 = ease(prog(t, cHis - 0.3, 0.9));
  fx = lerp(fx, 455, z1); fy = lerp(fy, 500, z1); sc = lerp(sc, 1.05, z1);
  const z2 = ease(prog(t, cEnd - 0.25, 0.7));
  fx = lerp(fx, END.x + 8, z2); fy = lerp(fy, END.y - 14, z2); sc = lerp(sc, 2.7, z2);
  sc *= 1 + 0.04 * prog(t, cEnd, s.e - cEnd);
  const count = Math.round(20 * prog(t, cHis + 0.25, c20 + 0.25 - cHis - 0.25));
  cam(fx, fy, sc, () => {
    drawWorld(t, { door, steps: wp * 20.5, fogA: 0.14 + 0.2 * wp, lights: 0.72 });
    driverTop(wq, (1 - prog(wp, 0.8, 0.2)) * (t > cDoor + 0.3 ? 1 : 0), 1 - prog(wp, 0.86, 0.1));
    // measuring line with step numbers
    if (count > 0 && z2 < 1) {
      ctx.save(); ctx.globalAlpha = 1 - z2;
      const nx = Math.cos(STEP_DIR - Math.PI / 2) * 30, ny = Math.sin(STEP_DIR - Math.PI / 2) * 30;
      ctx.strokeStyle = 'rgba(230,236,248,0.75)'; ctx.lineWidth = 1.5; ctx.beginPath();
      const a0 = pathAt(0.05), a1 = pathAt(count / 20);
      ctx.moveTo(a0.x + nx, a0.y + ny); ctx.lineTo(a1.x + nx, a1.y + ny); ctx.stroke();
      for (let i = 4; i < count; i += 5) {
        const q = pathAt((i + 1) / 20);
        circle(q.x + nx, q.y + ny, 10); ctx.fillStyle = i === 19 ? ORANGE : 'rgba(10,14,28,0.85)'; ctx.fill();
        text(String(i + 1), q.x + nx, q.y + ny + 4, `700 10px ${MONO}`, i === 19 ? '#10131f' : '#e6ebf5', 'center');
      }
      ctx.restore();
    }
    // the last footprint
    const last = STEPS[19];
    lock(last.x - 17, last.y - 13, 34, 26, prog(t, cEnd, 0.4), ORANGE);
    if (t > cEnd) {
      // where the 21st step should have been
      const nq = { x: last.x + Math.cos(STEP_DIR) * 24, y: last.y + Math.sin(STEP_DIR) * 24 - 6 };
      ctx.save(); ctx.setLineDash([3, 3]); ctx.lineWidth = 1; ctx.strokeStyle = `rgba(255,138,31,${0.8 * prog(t, cEnd + 0.3, 0.3)})`;
      ctx.translate(nq.x, nq.y); ctx.rotate(STEP_DIR); ctx.beginPath(); ctx.ellipse(0, 0, 9, 5, 0, 0, 6.28); ctx.stroke(); ctx.restore();
      const pr = prog(t, cClean, 1.4);
      if (pr > 0 && pr < 1) { ctx.strokeStyle = `rgba(210,228,255,${0.7 * (1 - pr)})`; ctx.lineWidth = 1.2; circle(nq.x + 14, nq.y - 10, 8 + pr * 60); ctx.stroke(); }
    }
  });
  snowfall(t, 70, 41, { vy: 30, vx: -22, size: 2, a: 0.5 });
  fog(t, 80, 520, 0.05 + 0.07 * wp, 13);

  // screen-space labels
  if (t < cHis - 0.2) tag('ДВЕРЬ · ОТКРЫТА', LM, TY, { a: door * (1 - prog(t, cHis - 0.6, 0.4)) });
  const aC = prog(t, cHis + 0.2, 0.2) * (1 - z2);
  if (aC > 0) {
    bigNum(String(count), 250, 300, 104, count === 20 ? ORANGE : '#f1f4fb', aC);
    tag('ШАГОВ ОТ ДВЕРИ', 250, 342, { align: 'center', a: aC });
    tag('≈ 14 М', 250, 374, { align: 'center', a: aC * prog(t, c20, 0.3), col: '#cdd6e8' });
  }
  if (t > cEnd) {
    tag('СЛЕД № 20', FX, FY - 168, { align: 'center', col: ORANGE, a: prog(t, cEnd + 0.1, 0.25) });
    tag('СЛЕД № 21 — НЕТ', FX, FY + 150, { align: 'center', col: '#ff6a4a', a: prog(t, cEnd + 0.45, 0.25) * (1 - prog(t, cBlood - 0.2, 0.2)) });
    const rows = [['КРОВЬ', cBlood], ['СЛЕДЫ БОРЬБЫ', cFight], ['ОБРАТНЫЙ СЛЕД', cClean - 0.25]];
    rows.forEach(([lab, c], i) => {
      const a = prog(t, c, 0.2);
      tag(lab, 880, 270 + i * 40, { a, col: '#cdd6e8', size: 16 });
      tag('НЕТ', 1120, 270 + i * 40, { a, col: '#ff6a4a', align: 'right', size: 16 });
    });
  }
  const clock = t < cHis - 0.3 ? 18 * 3600 + 6 * 60 + 10 + wp * 55 : 18 * 3600 + 21 * 60 + 40 + (t - cHis);
  return { a: 'ВЕЧЕР 1', b: t < cHis - 0.3 ? 'ВОДИТЕЛЬ' : 'ЕГО СЛЕДЫ', clock: fmtClock(clock) };
}

// =====================================================================
// Scene 3 — top-down cutaway of the cabin: six people
// =====================================================================
const PEOPLE = [
  { id: 'ЛЕНА', label: 'ЛЕНА · ФЕЛЬДШЕР', x: 428, y: 262, coat: '#c3cede', head: '#6b3a26', k: 1 },
  { id: 'ТИМУР', label: 'ТИМУР · 17 ЛЕТ', x: 230, y: 372, coat: '#f07a1a', head: '#15171c', k: 1 },
  { id: 'ФОМИЧ', label: 'ФОМИЧ · ЕГЕРЬ', x: 490, y: 592, coat: '#59603a', head: '#8e8d88', k: 1.05 },
  { id: 'ИГОРЬ', label: 'ИГОРЬ', x: 292, y: 702, coat: '#20242d', head: '#2b2420', k: 1.05 },
  { id: 'МАРИНА', label: 'МАРИНА', x: 428, y: 812, coat: '#7a2338', head: '#c9a45c', k: 0.98 },
  { id: 'ГОША', label: 'ГОША · 6 ЛЕТ', x: 490, y: 816, coat: '#3d6fb5', head: '#f2c230', k: 0.66 },
];
const ROWS = [262, 372, 482, 592, 702, 812];
function cabinShell(th) {
  rr(180, 70, 360, 940, [80, 80, 34, 34]); ctx.fillStyle = th ? '#2c1f6e' : '#18202d'; ctx.fill();
  ctx.lineWidth = 7; ctx.strokeStyle = th ? '#4a37a0' : '#3a475c'; ctx.stroke();
  if (th) return;
  rr(196, 96, 328, 898, [62, 62, 22, 22]); ctx.fillStyle = '#222935'; ctx.fill();
  // warm ceiling lamps
  for (const y of [300, 560, 820]) glow(360, y, 250, 'rgba(255,186,104,0.16)');
  // aisle runner
  ctx.fillStyle = '#5a1e24'; ctx.fillRect(336, 196, 48, 790);
  ctx.fillStyle = '#7a2c30'; ctx.fillRect(340, 196, 3, 790); ctx.fillRect(377, 196, 3, 790);
  // windshield, dashboard, wheel, empty driver seat, door well
  ctx.fillStyle = 'rgba(150,190,240,0.28)'; rr(214, 82, 292, 22, [40, 40, 4, 4]); ctx.fill();
  ctx.fillStyle = '#131922'; rr(206, 108, 250, 30, 8); ctx.fill();
  ctx.strokeStyle = '#59657a'; ctx.lineWidth = 5; circle(248, 150, 19); ctx.stroke();
  rr(219, 164, 58, 62, 10); ctx.fillStyle = '#3d3026'; ctx.fill();
  ctx.fillStyle = '#10151d'; rr(470, 120, 50, 86, 6); ctx.fill();
  // seats: two doubles per row + back bench
  for (const y of ROWS) for (const x of [230, 292, 428, 490]) {
    rr(x - 28, y - 34, 56, 70, 10); ctx.fillStyle = '#4a3a2c'; ctx.fill();
    rr(x - 28, y + 22, 56, 14, [0, 0, 10, 10]); ctx.fillStyle = '#34281e'; ctx.fill();
  }
  rr(204, 904, 312, 62, 12); ctx.fillStyle = '#4a3a2c'; ctx.fill(); rr(204, 950, 312, 16, [0, 0, 12, 12]); ctx.fillStyle = '#34281e'; ctx.fill();
  // frosted windows
  ctx.fillStyle = 'rgba(170,205,255,0.5)';
  for (const y of ROWS) { ctx.fillRect(181, y - 34, 6, 66); ctx.fillRect(533, y - 34, 6, 66); }
}
function person(p, t) {
  ctx.save(); ctx.translate(p.x, p.y); ctx.scale(p.k, p.k);
  ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(2, 6, 29, 19, 0, 0, 6.28); ctx.fill();
  ctx.fillStyle = p.coat; ctx.beginPath(); ctx.ellipse(0, 2, 28, 17, 0, 0, 6.28); ctx.fill();
  ctx.fillStyle = 'rgba(0,0,0,0.22)'; ctx.beginPath(); ctx.ellipse(0, 9, 26, 10, 0, 0, Math.PI); ctx.fill();
  ctx.fillStyle = p.head; circle(0, -3, 13); ctx.fill();
  ctx.fillStyle = 'rgba(255,255,255,0.14)'; circle(-3, -7, 6); ctx.fill();
  if (p.id === 'ГОША') { ctx.fillStyle = '#fff3c4'; circle(0, -3, 5); ctx.fill(); }
  if (p.id === 'ФОМИЧ') { ctx.fillStyle = '#6f6e6a'; ctx.beginPath(); ctx.ellipse(0, -3, 15, 6, 0, 0, 6.28); ctx.fill(); }
  // breath in the cold
  const b = (t * 0.45 + p.x * 0.013) % 1;
  ctx.fillStyle = `rgba(225,235,255,${0.22 * Math.sin(b * Math.PI)})`; circle(0, -22 - b * 16, 6 + b * 9); ctx.fill();
  ctx.restore();
}
function cabinProps(t) {
  // Lena's medical bag, Timur's camera, Fomich's lantern, Igor's phone
  rr(472, 244, 36, 30, 5); ctx.fillStyle = '#e8ecf2'; ctx.fill(); ctx.fillStyle = '#d0342c'; ctx.fillRect(487, 250, 6, 18); ctx.fillRect(481, 256, 18, 6);
  rr(214, 334, 32, 22, 4); ctx.fillStyle = '#12141a'; ctx.fill(); circle(230, 338, 7); ctx.fillStyle = '#2a3140'; ctx.fill();
  ctx.fillStyle = Math.sin(t * 6) > 0 ? '#ff3b30' : '#5a1512'; circle(241, 351, 2.5); ctx.fill();
  glow(428, 592, 80, `rgba(255,190,100,${0.4 + 0.08 * Math.sin(t * 13)})`); rr(420, 582, 16, 20, 4); ctx.fillStyle = '#ffd98a'; ctx.fill();
  glow(292, 676, 30, 'rgba(120,170,255,0.5)'); rr(286, 668, 12, 18, 2); ctx.fillStyle = '#9dc0ff'; ctx.fill();
}
function sceneCabin(t) {
  const id = 'cabin', s = SC[id];
  const cues = { 'ЛЕНА': cue(id, 'ЛЕНА'), 'ТИМУР': cue(id, 'ТИМУР'), 'ФОМИЧ': cue(id, 'СТАРЫЙ'), 'ИГОРЬ': cue(id, 'ИГОРЬ'), 'МАРИНА': cue(id, 'МАРИНА'), 'ГОША': cue(id, 'ГОША') };
  // camera: overview, then travel down the aisle from person to person
  let fy = 540, sc = 1.1;
  const stops = [[cues['ЛЕНА'], 330], [cues['ТИМУР'], 410], [cues['ФОМИЧ'], 590], [cues['ИГОРЬ'], 690], [cues['МАРИНА'], 770]];
  const zin = ease(prog(t, stops[0][0] - 0.45, 0.6));
  sc = lerp(sc, 1.45, zin); fy = lerp(fy, 330, zin);
  for (let i = 1; i < stops.length; i++) fy = lerp(fy, stops[i][1], ease(prog(t, stops[i][0] - 0.35, 0.55)));
  const S = sc * (1 + 0.02 * Math.sin(t * 0.5));
  const SY = lerp(354, 318, zin);
  rcam(360, fy, S, () => {
    ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
    glow(360, 540, 760, 'rgba(60,84,140,0.25)');
    cabinShell(false);
    cabinProps(t);
    for (const p of PEOPLE) person(p, t);
    // empty driver's seat
    const aD = (1 - zin) * prog(t, s.s + 0.5, 0.3);
    bracket(214, 158, 68, 74, '#ff6a4a', aD);
    tag('ВОДИТЕЛЬ — ПУСТО', 196, 195, { col: '#ff6a4a', a: aD, size: 13, align: 'center' });
    for (const p of PEOPLE) {
      const c = cues[p.id], pp = prog(t, c - 0.05, 0.35);
      if (pp <= 0) continue;
      const r = 34 * p.k;
      lock(p.x - r, p.y - r + 2, r * 2, r * 2 - 6, pp, p.id === 'ТИМУР' ? ORANGE : AMBER);
      const q = rlabel(p, r, S);
      tag(p.label, q.x, q.y, { a: pp, align: q.align, size: 12.5, col: p.id === 'ТИМУР' ? ORANGE : AMBER });
    }
  }, FX, SY);
  // roster counter
  const n = PEOPLE.filter(p => t >= cues[p.id]).length;
  tag('В САЛОНЕ', LM, TY, { a: 1, col: '#9aa6bf' });
  for (let i = 0; i < 6; i++) {
    rr(LM + i * 26, TY + 14, 20, 20, 4); ctx.fillStyle = i < n ? AMBER : 'rgba(120,134,160,0.3)'; ctx.fill();
  }
  text(n + ' / 6', LM + 168, TY + 31, `700 20px ${MONO}`, '#e6ebf5');
  return { a: 'ВЕЧЕР 1', b: 'САЛОН', clock: fmtClock(18 * 3600 + 22 * 60 + 5 + (t - s.s)) };
}

// =====================================================================
// Scene 4 — the heater: 40 minutes of warmth left
// =====================================================================
function blueprint() {
  ctx.fillStyle = '#0a1224'; ctx.fillRect(0, 0, W, H);
  glow(FX, 330, 820, 'rgba(40,70,140,0.35)');
  ctx.strokeStyle = 'rgba(110,140,200,0.09)'; ctx.lineWidth = 1; ctx.beginPath();
  for (let x = 0; x <= W; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
  for (let y = 0; y <= H; y += 40) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
  ctx.stroke();
}
function sceneHeater(t) {
  const id = 'heater', s = SC[id], lt = t - s.s;
  const c40 = cue(id, '40'), cWait = cue(id, 'ЖДАТЬ');
  const cool = ease(prog(lt, 0.3, s.e - s.s));
  blueprint();
  // heater in cross-section
  const hx = 150, hy = 170, hw = 330, hh = 190;
  glow(hx + hw / 2, hy + hh / 2, 330, `rgba(255,120,30,${0.3 * (1 - cool * 0.8)})`);
  rr(hx, hy, hw, hh, 14); ctx.fillStyle = '#121a2e'; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#8496bb'; ctx.stroke();
  for (let i = 0; i < 10; i++) {
    const k = clamp(1 - cool * 1.15 + (i / 10) * 0.25 * cool), x = hx + 24 + i * 29.5;
    rr(x, hy + 22, 17, hh - 44, 6);
    ctx.fillStyle = `rgb(${Math.round(lerp(70, 255, k))},${Math.round(lerp(30, 132, k))},${Math.round(lerp(28, 30, k))})`; ctx.fill();
  }
  // rising heat
  ctx.strokeStyle = `rgba(255,170,90,${0.5 * (1 - cool)})`; ctx.lineWidth = 2.5;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    for (let k = 0; k <= 20; k++) { const y = hy - 8 - k * 4.5, x = hx + 50 + i * 58 + Math.sin(k * 0.55 + t * 4 + i) * 7; k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }
    ctx.stroke();
  }
  tag('ПЕЧКА САЛОНА · РАЗРЕЗ', hx, hy + hh + 30, { col: '#9fb2d6', plate: false, size: 13 });
  // cabin thermometer
  const tx = 590, ty = 136, th = 290, lvl = lerp(0.72, 0.4, cool);
  rr(tx, ty, 22, th, 11); ctx.fillStyle = '#121a2e'; ctx.fill(); ctx.strokeStyle = '#8496bb'; ctx.lineWidth = 2; ctx.stroke();
  rr(tx + 5, ty + th * (1 - lvl), 12, th * lvl - 5, 6); ctx.fillStyle = cool > 0.6 ? '#7fb2ff' : ORANGE; ctx.fill();
  for (let i = 0; i <= 6; i++) { ctx.fillStyle = '#8496bb'; ctx.fillRect(tx - 12, ty + 10 + i * 45, 8, 2); }
  bigNum(('+' + Math.round(lerp(16, 7, cool)) + '°'), tx + 12, ty - 20, 30, '#e6ebf5');
  tag('В САЛОНЕ', tx + 12, ty + th + 30, { align: 'center', col: '#9fb2d6', plate: false, size: 13 });
  // countdown
  const a40 = prog(t, c40 - 0.15, 0.2);
  const left = 40 * 60 - Math.max(0, t - c40) * 75;
  bigNum(`${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, '0')}`, 905, 318, 112, cool > 0.75 ? '#ff6a4a' : '#f1f4fb', a40);
  tag('ДО ОСТЫВАНИЯ', 905, 214, { align: 'center', a: a40 });
  // the decision
  const aW = prog(t, cWait - 0.5, 0.25);
  if (aW > 0) {
    tag('ИДТИ: 9 КМ · −43°', 800, 420, { align: 'center', a: aW * 0.75, col: '#7f8ca6', size: 16 });
    ctx.strokeStyle = `rgba(255,106,74,${aW})`; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(700, 414); ctx.lineTo(700 + 200 * prog(t, cWait - 0.3, 0.3), 414); ctx.stroke();
    const p = prog(t, cWait, 0.25);
    tag('ЖДАТЬ', 1060, 420, { align: 'center', a: p, col: ORANGE, size: 18 });
    lock(1012, 394, 96, 36, p, ORANGE);
  }
  return { a: 'ВЕЧЕР 1', b: 'ПЕЧКА', clock: fmtClock(18 * 3600 + 24 * 60 + lt * 9), note: 'УСКОРЕНО' };
}
