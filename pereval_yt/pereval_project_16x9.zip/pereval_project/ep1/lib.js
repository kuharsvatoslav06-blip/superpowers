// ---------- core helpers ----------
const W = 1280, H = 720, SCALE = 1.5;   // 16:9 canvas, rendered at 1920x1080
const FX = 640, FY = 330;            // screen point the camera focuses on
const LM = 56, TY = 124;             // left margin and first row under the HUD for screen-space tags
let ctx;
const MONO = '"JetBrains Mono", monospace';
const ORANGE = '#ff8a1f', CREAM = '#ffe9a8', AMBER = '#e6a23c';

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = t => { t = clamp(t); return t * t * (3 - 2 * t); };
const easeOut = t => 1 - Math.pow(1 - clamp(t), 3);
const prog = (t, s, d) => clamp((t - s) / d);
const pulse = (t, s, d) => { const p = (t - s) / d; return p < 0 || p > 1 ? 0 : Math.sin(p * Math.PI); };

// ---------- timeline lookups ----------
const SC = {};
for (const s of TL.scenes) {
  SC[s.id] = s;
  s.words = [];
  for (const c of s.cards) for (const l of c.lines) for (const w of l) s.words.push(w);
}
// time when the n-th word containing `text` is spoken in scene `id`
function cue(id, text, n = 0) {
  const norm = x => x.replace(/[«»,.:]/g, '');
  let ws = SC[id].words.filter(w => norm(w.t) === norm(text));
  if (!ws.length) ws = SC[id].words.filter(w => w.t.includes(text));
  if (!ws.length) throw new Error('no cue ' + id + ' ' + text);
  return ws[Math.min(n, ws.length - 1)].s;
}

// ---------- drawing primitives ----------
function rr(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect(x, y, w, h, r); }
function circle(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); }
function glow(x, y, r, col, a = 1) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.save(); ctx.globalAlpha *= a; ctx.fillStyle = g; ctx.fillRect(x - r, y - r, r * 2, r * 2); ctx.restore();
}
function vgrad(y0, y1, stops) {
  const g = ctx.createLinearGradient(0, y0, 0, y1);
  stops.forEach(([p, c]) => g.addColorStop(p, c));
  return g;
}
function cam(fx, fy, s, fn, sx = FX, sy = FY) {
  ctx.save(); ctx.translate(sx, sy); ctx.scale(s, s); ctx.translate(-fx, -fy); fn(); ctx.restore();
}
// same, but the world is turned 90° clockwise: used for the top-down cabin so the bus lies
// along the wide frame (front of the bus on the right, left-hand seats at the top)
function rcam(fx, fy, s, fn, sx = FX, sy = FY) {
  ctx.save(); ctx.translate(sx, sy); ctx.scale(s, s); ctx.rotate(Math.PI / 2); ctx.translate(-fx, -fy); fn(); ctx.restore();
}
// world -> screen for rcam
function rscr(x, y, fx, fy, s, sx = FX, sy = FY) { return { x: sx - (y - fy) * s, y: sy + (x - fx) * s }; }
// anchor for a person's label in the rotated cabin: to the right of the person on screen
// (towards the front of the bus), where the seat in front is empty; use with align 'left'
function rlabel(p, r, s) {
  return { x: p.x + 6 / s, y: p.y - r - 8 / s, align: 'left' };
}
// text helpers stay upright even inside a rotated camera
function upright(x, y) {
  const m = ctx.getTransform(), a = Math.atan2(m.b, m.a);
  if (Math.abs(a) < 1e-4) return [x, y];
  ctx.translate(x, y); ctx.rotate(-a); return [0, 0];
}
function text(str, x, y, font, col, align = 'left', a = 1) {
  ctx.save(); ctx.globalAlpha *= a; ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align;
  [x, y] = upright(x, y);
  ctx.textBaseline = 'alphabetic'; ctx.fillText(str, x, y); ctx.restore();
}
// small technical label with a dark plate, like the reference overlays
function tag(str, x, y, opt = {}) {
  const { col = AMBER, a = 1, size = 15, align = 'left', plate = true } = opt;
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.font = `600 ${size}px ${MONO}`;
  [x, y] = upright(x, y);
  try { ctx.letterSpacing = '1.5px'; } catch (e) {}
  const w = ctx.measureText(str).width + 14;
  const x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x;
  if (plate) { ctx.fillStyle = 'rgba(8,10,20,0.78)'; rr(x0, y - size - 5, w, size + 12, 3); ctx.fill(); }
  ctx.fillStyle = col; ctx.textAlign = 'left'; ctx.fillText(str, x0 + 7, y); ctx.restore();
}
// corner brackets around a box
function bracket(x, y, w, h, col = AMBER, a = 1, len = 12, lw = 2) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath();
  for (const [cx, cy, dx, dy] of [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]]) {
    ctx.moveTo(cx + dx * len, cy); ctx.lineTo(cx, cy); ctx.lineTo(cx, cy + dy * len);
  }
  ctx.stroke(); ctx.restore();
}
// bracket that "locks on": starts bigger and settles
function lock(x, y, w, h, p, col = AMBER) {
  if (p <= 0) return;
  const k = lerp(26, 0, easeOut(p));
  bracket(x - k, y - k, w + 2 * k, h + 2 * k, col, clamp(p * 3));
}
function bigNum(str, x, y, size, col, a = 1, align = 'center') {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.font = `800 ${size}px ${MONO}`; ctx.textAlign = align;
  [x, y] = upright(x, y);
  ctx.shadowColor = 'rgba(0,0,0,0.9)'; ctx.shadowBlur = 18; ctx.fillStyle = col; ctx.fillText(str, x, y);
  ctx.shadowBlur = 0; ctx.restore();
}

// ---------- atmosphere ----------
function snowfall(t, n, seed, o = {}) {
  const { vy = 55, vx = -18, size = 2.2, a = 0.75, y0 = -20, y1 = H + 20, col = '#dfe8ff' } = o;
  const r = rng(seed);
  ctx.save(); ctx.fillStyle = col;
  for (let i = 0; i < n; i++) {
    const bx = r() * W, by = r() * (y1 - y0), sp = 0.5 + r(), sz = size * (0.4 + r() * 0.9), ph = r() * 6.28;
    const x = ((bx + vx * sp * t + Math.sin(t * 0.9 + ph) * 14) % W + W) % W;
    const y = y0 + ((by + vy * sp * t) % (y1 - y0));
    ctx.globalAlpha = a * (0.35 + 0.65 * r());
    circle(x, y, sz); ctx.fill();
  }
  ctx.restore();
}
function fog(t, yTop, yBot, a, seed, col = '200,212,240', n = 9) {
  const r = rng(seed);
  for (let i = 0; i < n; i++) {
    const bx = r() * (W + 600) - 300, y = lerp(yTop, yBot, r()), rad = 190 + r() * 260, sp = (r() - 0.5) * 26, ph = r() * 6.28;
    const x = ((bx + sp * t + 300) % (W + 600) + (W + 600)) % (W + 600) - 300;
    const al = a * (0.45 + 0.55 * Math.sin(t * 0.25 + ph) ** 2);
    const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
    g.addColorStop(0, `rgba(${col},${al})`); g.addColorStop(1, `rgba(${col},0)`);
    ctx.fillStyle = g; ctx.save(); ctx.translate(x, y); ctx.scale(1.9, 0.62); ctx.translate(-x, -y);
    ctx.fillRect(x - rad, y - rad, rad * 2, rad * 2); ctx.restore();
  }
}
// side-view spruce
function spruce(x, base, h, col, snow) {
  const w = h * 0.42;
  ctx.fillStyle = col;
  for (let i = 0; i < 5; i++) {
    const y0 = base - h * (0.12 + i * 0.17), y1 = base - h * (0.12 + i * 0.17) - h * 0.3;
    const ww = w * (1 - i * 0.17);
    ctx.beginPath(); ctx.moveTo(x - ww, y0); ctx.lineTo(x, y1); ctx.lineTo(x + ww, y0); ctx.closePath(); ctx.fill();
    if (snow) {
      ctx.save(); ctx.fillStyle = snow; ctx.beginPath();
      ctx.moveTo(x - ww, y0); ctx.lineTo(x, y1); ctx.lineTo(x - ww * 0.15, y0); ctx.closePath(); ctx.fill(); ctx.restore();
      ctx.fillStyle = col;
    }
  }
  ctx.fillRect(x - h * 0.02, base - h * 0.14, h * 0.04, h * 0.14);
}
// top-down spruce crown
function crown(x, y, r, seed, c1, c2, snowCol) {
  const rr_ = rng(seed), n = 9 + Math.floor(rr_() * 4), rot = rr_() * 6.28;
  for (let k = 0; k < 3; k++) {
    const rad = r * (1 - k * 0.3);
    ctx.beginPath();
    for (let i = 0; i < n * 2; i++) {
      const a = rot + k * 0.4 + i * Math.PI / n, q = i % 2 ? rad * 0.66 : rad;
      ctx.lineTo(x + Math.cos(a) * q, y + Math.sin(a) * q);
    }
    ctx.closePath(); ctx.fillStyle = k === 0 ? c1 : k === 1 ? c2 : snowCol; ctx.fill();
  }
}

// ---------- HUD, captions, post ----------
function fmtClock(sec) {
  sec = Math.floor(sec);
  const p = n => String(n).padStart(2, '0');
  return `${p(Math.floor(sec / 3600) % 24)}:${p(Math.floor(sec / 60) % 60)}:${p(sec % 60)}`;
}
function drawHUD(a, b, clock, note) {
  ctx.save();
  ctx.fillStyle = vgrad(0, 150, [[0, 'rgba(4,6,14,0.8)'], [1, 'rgba(4,6,14,0)']]); ctx.fillRect(0, 0, W, 150);
  ctx.font = `500 19px ${MONO}`; try { ctx.letterSpacing = '3px'; } catch (e) {}
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#7f8ca6'; ctx.fillText(a, LM, 66);
  const wa = ctx.measureText(a + ' ').width;
  ctx.fillStyle = '#56607a'; ctx.fillText('·', LM + wa, 66);
  ctx.fillStyle = '#d99a3a'; ctx.fillText(b, LM + wa + 22, 66);
  ctx.font = `700 33px ${MONO}`; try { ctx.letterSpacing = '2px'; } catch (e) {}
  ctx.textAlign = 'right'; ctx.fillStyle = 'rgba(214,221,235,0.92)'; ctx.fillText(clock, W - LM, 74);
  if (note) { ctx.font = `500 13px ${MONO}`; ctx.fillStyle = '#6f7b96'; ctx.fillText(note, W - LM, 96); }
  ctx.restore();
}

function drawCaptions(t) {
  let card = null;
  for (const s of TL.scenes) for (const c of s.cards) if (t >= c.s - 0.04 && t < c.hold) card = c;
  if (!card) return;
  const size = 50, lh = 60;
  ctx.save();
  ctx.font = `700 ${size}px Oswald`; ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
  try { ctx.letterSpacing = '0.5px'; } catch (e) {}
  const gap = size * 0.27;
  const out = clamp((card.hold - t) / 0.1);
  let y = 670 - (card.lines.length - 1) * lh;     // bottom-centre, last line on a fixed baseline
  // newest spoken word in the card
  let newest = null;
  for (const l of card.lines) for (const w of l) if (t >= w.s) newest = w;
  for (const l of card.lines) {
    const ws = l.map(w => ctx.measureText(w.t).width);
    let x = FX - (ws.reduce((a, b) => a + b, 0) + gap * (l.length - 1)) / 2;
    l.forEach((w, i) => {
      const p = prog(t, w.s - 0.05, 0.14);
      const lead = prog(t, w.s - 0.45, 0.2);         // faint preview of the upcoming word
      const a = (p > 0 ? 1 : 0.3 * lead) * out;
      if (a > 0) {
        const col = p <= 0 ? '#9aa3b8' : w.hl ? ORANGE : (w === newest ? CREAM : '#ffffff');
        const dy = (1 - easeOut(p)) * 7 * (p > 0 ? 1 : 0);
        ctx.globalAlpha = a;
        ctx.lineJoin = 'round'; ctx.lineWidth = 9; ctx.strokeStyle = 'rgba(6,8,16,0.85)';
        ctx.shadowColor = 'rgba(0,0,0,0.95)'; ctx.shadowBlur = 16; ctx.shadowOffsetY = 3;
        ctx.strokeText(w.t, x, y + dy);
        ctx.shadowColor = p > 0 && (w.hl || w === newest) ? (w.hl ? 'rgba(255,120,20,0.55)' : 'rgba(255,225,150,0.45)') : 'rgba(0,0,0,0)';
        ctx.shadowBlur = 18; ctx.shadowOffsetY = 0;
        ctx.fillStyle = col; ctx.fillText(w.t, x, y + dy);
        ctx.shadowBlur = 0;
      }
      x += ws[i] + gap;
    });
    y += lh;
  }
  ctx.restore();
}

let grainTiles = null;
function makeGrain() {
  grainTiles = [];
  for (let k = 0; k < 4; k++) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 256;
    const g = c.getContext('2d'), im = g.createImageData(256, 256), r = rng(99 + k);
    for (let i = 0; i < im.data.length; i += 4) { const v = r() * 255; im.data[i] = im.data[i + 1] = im.data[i + 2] = v; im.data[i + 3] = 255; }
    g.putImageData(im, 0, 0); grainTiles.push(c);
  }
}
function post(t, bottomDark = 0.9) {
  // darken lower third so captions stay readable
  ctx.fillStyle = vgrad(450, H, [[0, 'rgba(5,7,16,0)'], [0.5, `rgba(5,7,16,${0.55 * bottomDark})`], [1, `rgba(4,5,12,${0.9 * bottomDark})`]]);
  ctx.fillRect(0, 450, W, H - 450);
  // vignette (elliptical, follows the wide frame)
  ctx.save(); ctx.translate(FX, 350); ctx.scale(1.75, 1);
  const g = ctx.createRadialGradient(0, 0, 170, 0, 20, 470);
  g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,0.88)');
  ctx.fillStyle = g; ctx.fillRect(-FX / 1.75 - 10, -360, W / 1.75 + 20, H + 20); ctx.restore();
  // film grain
  if (!grainTiles) makeGrain();
  ctx.save(); ctx.globalAlpha = 0.055; ctx.globalCompositeOperation = 'overlay';
  const tile = grainTiles[Math.floor(t * 12) % 4];
  ctx.fillStyle = ctx.createPattern(tile, 'repeat'); ctx.fillRect(0, 0, W, H); ctx.restore();
}
