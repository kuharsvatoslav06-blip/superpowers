"""Align script lines to a narration file using detected pauses + syllable counts (no ASR).
Writes <out>_words.json in the same shape as the ElevenLabs transcript."""
import json, re, subprocess, sys, wave, numpy as np
from pathlib import Path
H = Path(__file__).parent; wav, outp = sys.argv[1], sys.argv[2]
with wave.open(str(H / wav)) as wv: SR = wv.getframerate(); a = np.frombuffer(wv.readframes(wv.getnframes()), np.int16).astype(np.float32) / 32768
# energy envelope -> silences
hop = int(0.01 * SR); n = len(a) // hop
rms = np.sqrt((a[:n * hop].reshape(n, hop) ** 2).mean(1)); db = 20 * np.log10(rms + 1e-7)
thr = np.percentile(db, 95) - 38
sil = db < thr
runs = []; i = 0
while i < n:
    if sil[i]:
        j = i
        while j < n and sil[j]: j += 1
        if (j - i) >= 7: runs.append((i * 0.01, j * 0.01))
        i = j
    else: i += 1
t0 = runs[0][1] if runs and runs[0][0] < 0.05 else 0.0
t1 = runs[-1][0] if runs and runs[-1][1] > n * 0.01 - 0.05 else n * 0.01
cands = [(s, e) for s, e in runs if s > t0 + 0.05 and e < t1 - 0.05]
VOW = set('аеёиоуыэюя')
script = json.loads((H / 'script.json').read_text())
lines = [ln['tts'] for sc in script['scenes'] for ln in sc['lines']]
syl = lambda s: sum(ch in VOW for ch in s.lower())
W = [syl(l) + 0.3 * len(l.split()) for l in lines]
final = [bool(re.search(r'[.!?…]$', l.strip())) for l in lines]
L, C = len(lines), len(cands)
voiced_total = (t1 - t0) - sum(e - s for s, e in cands)
rate = voiced_total / sum(W)
# prefix sums of silence time
bounds = [(t0, t0)] + cands + [(t1, t1)]          # boundary j: speech resumes at bounds[j][1], stops at bounds[j][0]
def voiced(j0, j1):  # voiced time between boundary j0 and j1
    return (bounds[j1][0] - bounds[j0][1]) - sum(bounds[k][1] - bounds[k][0] for k in range(j0 + 1, j1))
INF = 1e18; NB = len(bounds)
cost = np.full((L + 1, NB), INF); back = {}
cost[0, 0] = 0
for i in range(1, L + 1):
    for j in range(1, NB):
        if i == L and j != NB - 1: continue
        if i < L and j == NB - 1: continue
        for k in range(max(0, i - 3), i):
            for j0 in range(max(0, j - 12), j):
                if cost[k, j0] >= INF: continue
                exp = sum(W[k:i]) * rate; act = voiced(j0, j)
                c = (act - exp) ** 2 / exp * 6
                # boundaries skipped inside the span (no pause found for them)
                c += sum(2.5 if final[m] else 0.5 for m in range(k, i - 1))
                # pauses left inside lines: long ones are unlikely to be mid-line
                c += sum(max(0, (bounds[m][1] - bounds[m][0]) - 0.15) * 6 for m in range(j0 + 1, j))
                # sentence ends like a real pause; a non-final break prefers a short one
                if j < NB - 1:
                    d = bounds[j][1] - bounds[j][0]
                    c += (max(0, 0.22 - d) * 8) if final[i - 1] else 0
                tot = cost[k, j0] + c
                if tot < cost[i, j]: cost[i, j] = tot; back[(i, j)] = (k, j0)
# backtrack
i, j = L, NB - 1; spans = []
while i > 0:
    k, j0 = back[(i, j)]; spans.append((k, i, j0, j)); i, j = k, j0
spans.reverse()
words = []; report = []
for k, i, j0, j in spans:
    s, e = bounds[j0][1], bounds[j][0]
    inner = [bounds[m] for m in range(j0 + 1, j)]
    # map "voiced time" to real time inside the span, skipping inner pauses
    def real(v):
        t = s
        for ps, pe in inner:
            if v <= ps - t: return t + v
            v -= ps - t; t = pe
        return min(e, t + v)
    vt = (e - s) - sum(pe - ps for ps, pe in inner); tw = sum(W[k:i]); acc = 0.0
    for m in range(k, i):
        toks = lines[m].split(); ws = [t for t in toks if re.search(r'\w', t)]
        wts = [syl(t) + 0.3 for t in ws]; ls = acc
        for t, w in zip(ws, wts):
            d = vt * w / tw * (W[m] / sum(wts)) if sum(wts) else 0
            words.append({'text': t, 'type': 'word', 'start': round(real(acc), 3), 'end': round(real(acc + d * 0.96), 3)}); acc += d
        report.append((m, round(real(ls), 2), round(real(acc), 2), lines[m][:34], 'joined' if i - k > 1 else ''))
json.dump({'words': words}, open(H / (outp + '_words.json'), 'w'), ensure_ascii=False)
print('pauses', C, 'rate', round(rate, 3), 'cost', round(float(cost[L, NB - 1]), 1), 'joined spans', sum(1 for s in spans if s[1] - s[0] > 1))
for r in report: print(r)
