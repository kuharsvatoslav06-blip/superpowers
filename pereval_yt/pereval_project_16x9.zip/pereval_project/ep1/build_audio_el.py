"""Re-time the ElevenLabs narration to the script: exact word timings from the transcript,
extra pauses inserted between lines so the visuals have room. Writes voice.wav + timeline.json."""
import json, re, wave, numpy as np
from pathlib import Path
H = Path(__file__).parent; SR = 44100
raw = json.loads((H / 'el_words.json').read_text())
words = raw['words'] if isinstance(raw, dict) else raw
words = [w for w in words if w.get('type', 'word') == 'word' and re.search(r'\w', w['text'])]
with wave.open(str(H / 'el_voice.wav')) as wv: src = np.frombuffer(wv.readframes(wv.getnframes()), np.int16).astype(np.float32) / 32768
norm = lambda s: re.sub(r'[^\w]', '', s.lower().replace('ё', 'е'))
def parse_cap(cap):
    cards, card, line = [], [], []
    for tok in cap.split():
        if tok == '|': card.append(line); cards.append(card); card, line = [], []
        elif tok == '/': card.append(line); line = []
        else:
            hl = tok.startswith('*'); tok = tok.lstrip('*'); text, _, say = tok.partition('=')
            line.append({'t': text, 'hl': hl, 'n': len((say or text).split('_'))})
    card.append(line); cards.append(card); return cards
script = json.loads((H / 'script.json').read_text())
# 1) assign transcript words to script lines
wi = 0; lines = []
for si, sc in enumerate(script['scenes']):
    for li, ln in enumerate(sc['lines']):
        toks = [x for x in (norm(t) for t in ln['tts'].split()) if x]
        seg = words[wi:wi + len(toks)]
        assert [norm(w['text']) for w in seg] == toks, (toks, [w['text'] for w in seg])
        wi += len(toks)
        lines.append({'scene': si, 'first': li == 0, 'lead': sc.get('lead', 0.3), 'gap': ln.get('gap', 0.3) * 0.85, 'cap': ln['cap'], 'w': seg})
assert wi == len(words)
# 2) decide how much silence to add before each line
out = []; shift = []; pos = 0.0; extra_total = 0.0
for i, L in enumerate(lines):
    s0 = L['w'][0]['start']
    if i == 0: extra = L['lead']; cut = 0.0
    else:
        P = lines[i - 1]; e0 = P['w'][-1]['end']; nat = s0 - e0; cut = (e0 + s0) / 2
        want = P['gap'] + (L['lead'] if L['first'] else 0)
        extra = max(0.0, want - nat) if nat >= 0.12 else 0.0
    nxt = (L['w'][-1]['end'] + lines[i + 1]['w'][0]['start']) / 2 if i + 1 < len(lines) else len(src) / SR
    chunk = src[int(cut * SR):int(nxt * SR)].copy()
    out.append(np.zeros(int(extra * SR), np.float32)); out.append(chunk)
    extra_total += int(extra * SR) / SR; shift.append(extra_total)
tail = lines[-1]['gap']
audio = np.concatenate(out + [np.zeros(int(tail * SR), np.float32)])
# 3) timeline in the format the renderer expects
scenes = []
for i, L in enumerate(lines):
    if L['first']:
        start = 0.0 if i == 0 else (lines[i - 1]['w'][-1]['end'] + shift[i - 1] + lines[i - 1]['gap'] * 0.6)
        scenes.append({'id': script['scenes'][L['scene']]['id'], 's': round(start, 3), 'cards': []})
    k = 0
    for c in parse_cap(L['cap']):
        cl = []
        for l in c:
            row = []
            for tk in l:
                row.append({'t': tk['t'], 'hl': tk['hl'], 's': round(L['w'][k]['start'] + shift[i], 3), 'e': round(L['w'][k + tk['n'] - 1]['end'] + shift[i], 3)}); k += tk['n']
            cl.append(row)
        ws = [w for l in cl for w in l]
        scenes[-1]['cards'].append({'s': ws[0]['s'], 'e': ws[-1]['e'], 'lines': [[{'t': w['t'], 'hl': w['hl'], 's': w['s']} for w in l] for l in cl]})
    assert k == len(L['w']), L['cap']
total = len(audio) / SR
for j, s in enumerate(scenes):
    s['e'] = scenes[j + 1]['s'] if j + 1 < len(scenes) else round(total, 3)
    for n, c in enumerate(s['cards']):
        nx = s['cards'][n + 1]['s'] if n + 1 < len(s['cards']) else s['e']
        c['hold'] = round(min(nx, c['e'] + 0.9), 3)
audio = audio / max(1e-6, np.abs(audio).max()) * 0.89
with wave.open(str(H / 'voice.wav'), 'wb') as wv: wv.setnchannels(1); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((audio * 32767).astype(np.int16).tobytes())
(H / 'timeline.json').write_text(json.dumps({'voice_end': round(total, 3), 'scenes': scenes}, ensure_ascii=False, indent=1))
(H / 'timeline.js').write_text('const TL = ' + json.dumps({'voice_end': round(total, 3), 'scenes': scenes}, ensure_ascii=False) + ';')
for s in scenes: print(f"{s['id']:8s} {s['s']:7.2f} – {s['e']:7.2f}")
print('total', round(total, 2))
