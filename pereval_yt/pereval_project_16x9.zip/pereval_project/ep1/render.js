// usage: node render.js stills t1 t2 ...   |   node render.js video <part> <parts> <outfile>
const { chromium } = require('playwright'); const path = require('path'); const { spawn } = require('child_process');
(async () => {
  const mode = process.argv[2];
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  page.on('pageerror', e => { console.error('PAGE ERROR', e.message); });
  page.on('console', m => { if (m.type() === 'error') console.error('CONSOLE', m.text()); });
  await page.goto('file://' + path.join(__dirname, 'index.html'));
  const dur = await page.evaluate(() => window.ready);
  if (mode === 'stills') {
    for (const a of process.argv.slice(3)) {
      const t = parseFloat(a);
      try { await page.evaluate(t => window.frame(t), t); } catch (e) { console.error('ERR at', t, e.message.split('\n')[0]); }
      await page.screenshot({ path: path.join(__dirname, 'stills', `t${a.padStart(6, '0')}.jpg`), type: 'jpeg', quality: 80 });
    }
    console.log('duration', dur);
  } else {
    const part = +process.argv[3], parts = +process.argv[4], out = process.argv[5], FPS = 30;
    const total = Math.ceil(dur * FPS), f0 = Math.floor(total * part / parts), f1 = Math.floor(total * (part + 1) / parts);
    const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', out], { stdio: ['pipe', 'inherit', 'inherit'] });
    for (let f = f0; f < f1; f++) {
      await page.evaluate(t => window.frame(t), f / FPS);
      const buf = await page.screenshot({ type: 'jpeg', quality: 95 });
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if ((f - f0) % 150 === 0) console.log(`part ${part}: ${f - f0}/${f1 - f0}`);
    }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
  }
  await browser.close();
})();
