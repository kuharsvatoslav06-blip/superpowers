#!/usr/bin/env bash
# One-time setup: caption font, Python TTS + numpy, local draft voice. Run from the project root.
set -euo pipefail
cd "$(dirname "$0")"
( cd ep1 && npm install --no-audit --no-fund )            # Oswald font (@fontsource/oswald)
pip install --quiet piper-tts numpy                        # draft voice + audio tools
mkdir -p tts
if [ ! -f tts/ru-irinia-medium.onnx ]; then
  curl -sSL -o tts/irinia.tar.gz https://github.com/rhasspy/piper/releases/download/v0.0.2/voice-ru-irinia-medium.tar.gz
  tar xzf tts/irinia.tar.gz -C tts && rm tts/irinia.tar.gz
fi
node -e "require('playwright'); console.log('playwright ok')"
command -v ffmpeg >/dev/null && echo "ffmpeg ok"
