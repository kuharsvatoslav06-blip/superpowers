#!/usr/bin/env bash
# Full 16:9 YouTube cut of season 1: intro + (title card + episode) x 6 -> final/pereval_season1_16x9.mp4
#   ./build_yt.sh            # renders episodes that have no mp4 yet, then the intro/titles/cover, then concatenates
#   ./build_yt.sh --rebuild  # re-renders every episode
set -euo pipefail
cd "$(dirname "$0")"
for e in 1 2 3 4 5 6; do
  if [ "${1:-}" = "--rebuild" ] || [ ! -f ep$e/pereval_seria$e.mp4 ]; then ./build.sh ep$e final; fi
done
cd yt && mkdir -p out stills
python3 sound_yt.py
node render_yt.js intro.html video out/intro_v.mp4
for n in 1 2 3 4 5 6; do node render_yt.js title$n.html video out/title${n}_v.mp4; done
node render_yt.js cover.html stills 0
cd ..; mkdir -p final
ffmpeg -v error -y -i yt/stills/cover_0.jpg -vf scale=1280:720 -q:v 2 final/pereval_cover_1280x720.jpg
args=(-i yt/out/intro_v.mp4 -i yt/intro.wav); fc="[0:v][1:a]"; n=2
for e in 1 2 3 4 5 6; do
  args+=(-i yt/out/title${e}_v.mp4 -i yt/title.wav -i ep$e/pereval_seria$e.mp4)
  fc+="[$n:v][$((n+1)):a][$((n+2)):v][$((n+2)):a]"; n=$((n+3))
done
fc+="concat=n=13:v=1:a=1[v][a0];[a0]aresample=44100[a]"
ffmpeg -nostdin -v error -y "${args[@]}" -filter_complex "$fc" -map "[v]" -map "[a]" -c:v libx264 -preset medium -crf 19 \
  -pix_fmt yuv420p -r 30 -c:a aac -b:a 192k -ar 44100 -movflags +faststart final/pereval_season1_16x9.mp4
# chapter times: intro 8 s, each title card 2.4 s, then the episode
python3 - <<'PY'
import subprocess
d = lambda f: max(float(x) for x in subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=duration','-of','csv=p=0',f]).split())
names = ['Седьмой','Второе правило','Ответ','Вернувшийся','Два Гоши','Седьмое место']
t = 8.0; print('0:00 Вступление')
for i, n in enumerate(names, 1):
    s = max(10, int(t)) if i == 1 else int(t)
    print(f'{s // 60}:{s % 60:02d} Серия {i} · {n}'); t += 2.4 + d(f'ep{i}/pereval_seria{i}.mp4')
PY
echo "done: final/pereval_season1_16x9.mp4"
