<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
@font-face{font-family:Oswald;font-weight:700;src:url(../ep1/node_modules/@fontsource/oswald/files/oswald-cyrillic-700-normal.woff2) format('woff2');unicode-range:U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116}
@font-face{font-family:Oswald;font-weight:700;src:url(../ep1/node_modules/@fontsource/oswald/files/oswald-latin-700-normal.woff2) format('woff2')}
html,body{margin:0;background:#000}canvas{display:block}
</style></head><body><canvas id="c" width="1920" height="1080"></canvas>
<script>const TL = { voice_end: 0, scenes: [] }; const MODE = '@MODE@', EP = @EP@;</script>
<script src="../ep1/lib.js"></script><script src="../ep1/scenes1.js"></script><script src="../ep1/scenes2.js"></script><script src="yt.js"></script>
<script>
ctx = document.getElementById('c').getContext('2d');
window.ready = Promise.all([document.fonts.load('700 58px Oswald','АБВ'), document.fonts.load('700 58px Oswald','ABC 123'), document.fonts.load('700 30px "JetBrains Mono"','АБВ 123')]).then(()=>{ makeGrain(); return DURATION; });
window.frame = t => { render(t); return true; };
</script></body></html>
