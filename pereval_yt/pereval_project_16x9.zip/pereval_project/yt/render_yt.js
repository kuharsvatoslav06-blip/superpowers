// node render_yt.js <page.html> stills t1 t2 ... | node render_yt.js <page.html> video <out.mp4>
const { chromium } = require('playwright'); const path = require('path'); const { spawn } = require('child_process');
(async () => {
  const [pageName, mode, ...rest] = process.argv.slice(2);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('PAGE ERROR', e.message));
  await page.goto('file://' + path.join(__dirname, pageName));
  const dur = await page.evaluate(() => window.ready);
  if (mode === 'stills') {
    for (const a of rest) { await page.evaluate(t => window.frame(t), parseFloat(a)); await page.screenshot({ path: path.join(__dirname, 'stills', pageName.replace('.html', '') + '_' + a + '.jpg'), type: 'jpeg', quality: 92 }); }
  } else {
    const FPS = 30, total = Math.round(dur * FPS);
    const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', rest[0]], { stdio: ['pipe', 'inherit', 'inherit'] });
    for (let f = 0; f < total; f++) { await page.evaluate(t => window.frame(t), f / FPS); const buf = await page.screenshot({ type: 'jpeg', quality: 95 }); if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r)); }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
  }
  await browser.close();
})();
