"""Sound for the intro and the episode title cards (same palette as the episodes: wind, drone, low hits)."""
import sys, wave, numpy as np
SR = 44100
def lpf(x, fc):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); X *= 1 / (1 + (f / fc) ** 4); return np.fft.irfft(X, len(x))
def hpf(x, fc): return x - lpf(x, fc)
def hit(rs, f=46, d=0.9):
    n = int(2.6 * SR); x = np.arange(n) / SR
    return np.sin(2 * np.pi * f * x * (1 + 0.6 * np.exp(-x * 9))) * np.exp(-x / d) + lpf(rs.randn(n), 300) * np.exp(-x / 0.12) * 0.6
def whoosh(rs, d=0.6):
    n = int(d * SR); x = np.arange(n) / n; return hpf(lpf(rs.randn(n), 2500), 300) * np.sin(np.pi * x) ** 2
def make(dur, seed, events):
    N = int(dur * SR); t = np.arange(N) / SR; rs = np.random.RandomState(seed); mix = np.zeros(N)
    def add(sig, at, g):
        i = int(at * SR); sig = sig[:max(0, N - i)]; mix[i:i + len(sig)] += sig * g
    w = hpf(lpf(rs.randn(N), 900), 120); mix += w / np.abs(w).max() * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * t)) * 0.10
    dr = np.sin(2 * np.pi * 49 * t) + 0.6 * np.sin(2 * np.pi * 73.6 * t) + 0.35 * np.sin(2 * np.pi * 98.3 * t)
    mix += dr * 0.05 * np.minimum(1, t / 1.5)
    events(add, rs, t)
    out = np.clip(np.tanh(mix * 1.15) / np.tanh(1.15) * 0.9, -0.98, 0.98)
    fi, fo = int(0.5 * SR), int(0.5 * SR); out[:fi] *= np.linspace(0, 1, fi); out[-fo:] *= np.linspace(1, 0, fo)
    return out
def save(name, out):
    st = np.stack([out, out], 1)
    with wave.open(name, 'wb') as wv: wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((st * 32767).astype(np.int16).tobytes())
def intro_events(add, rs, t):
    n = int(2.4 * SR); x = np.arange(n) / SR; rate = 26 * np.exp(-x * 0.9); ph = 2 * np.pi * np.cumsum(rate) / SR
    add(lpf((np.sign(np.sin(ph)) * 0.5 + np.sin(ph * 2)) * np.exp(-x * 1.1), 220), 0.5, 0.3)
    add(whoosh(rs, 0.9), 1.3, 0.2); add(hit(rs, 40, 1.6), 1.95, 0.6)
    add(hit(rs, 34, 2.0), 4.2, 0.35)
def title_events(add, rs, t):
    add(whoosh(rs, 0.5), 0.0, 0.16); add(hit(rs, 44, 1.0), 0.3, 0.42)
save('intro.wav', make(8.0, 3, intro_events))
save('title.wav', make(2.4, 5, title_events))
print('ok')
