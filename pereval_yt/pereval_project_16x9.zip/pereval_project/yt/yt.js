// Extra pieces for the YouTube cut: intro, per-episode title cards, cover.
// MODE is set by the html page: 'intro' | 'title' | 'cover'; EP = episode number for 'title'.
const TITLES = ['', 'СЕДЬМОЙ', 'ВТОРОЕ ПРАВИЛО', 'ОТВЕТ', 'ВЕРНУВШИЙСЯ', 'ДВА ГОШИ', 'СЕДЬМОЕ МЕСТО'];
const INTRO_D = 8.0, TITLE_D = 2.4;

function nightRoad(t, o = {}) {
  // side view of the pass at night, the stalled bus, fog; same world as episode 1, scene 1
  const lights = o.lights ?? 0.72;
  ctx.fillStyle = vgrad(0, 620, [[0, '#070b1a'], [0.6, '#131d3a'], [1, '#2a3962']]); ctx.fillRect(-400, -60, W + 800, 700);
  glow(770, 330, 190, 'rgba(190,205,240,0.22)'); circle(770, 330, 24); ctx.fillStyle = 'rgba(214,224,246,0.75)'; ctx.fill();
  const r = rng(11);
  for (let x = -300; x < 1300; x += 34) spruce(x + r() * 20, 566, 110 + r() * 110, '#17223f');
  fog(t, 430, 560, 0.16, 3);
  for (let x = -300; x < 1300; x += 62) spruce(x + r() * 34, 590, 200 + r() * 150, '#0b1227', 'rgba(110,134,190,0.35)');
  ctx.fillStyle = vgrad(575, 1300, [[0, '#3c5083'], [0.25, '#26355d'], [1, '#0d1326']]); ctx.fillRect(-400, 575, W + 800, 760);
  ctx.fillStyle = 'rgba(16,24,48,0.5)'; ctx.fillRect(-400, 648, W + 800, 5); ctx.fillRect(-400, 668, W + 800, 4);
  glow(o.busX - 30, 668, 210, `rgba(255,180,90,${0.22 * lights})`);
  busSide(o.busX, 668, lights);
  fog(t, 560, 700, 0.2, 5);
}

function introFrame(t) {
  const push = ease(prog(t, 0, INTRO_D));
  cam(lerp(300, 345, push), 470, lerp(1.0, 1.18, push), () => {
    nightRoad(t, { busX: 250, lights: t < 0.8 ? 1 : 0.45 + 0.5 * Math.abs(Math.sin(t * 31)) * (t < 1.6 ? 1 : 0) + (t >= 1.6 ? 0.27 : 0) });
    // the seventh, standing at the edge of the light
    ctx.save(); ctx.globalAlpha = 0.85 * ease(prog(t, 3.0, 1.4)); ctx.translate(690, 640); ctx.scale(0.13, 0.13); figure(0, t, 0); ctx.restore();
    spruce(-290, 1000, 620, '#050812'); spruce(1010, 1040, 680, '#050812');
    fog(t * 1.4, 600, 820, 0.13, 8);
  });
  snowfall(t, 150, 21, { vy: 60, vx: -30 });
  snowfall(t, 40, 22, { vy: 95, vx: -50, size: 3.6, a: 0.5 });
  post(t, 0.9);
  // title
  const a = ease(prog(t, 1.9, 0.9));
  ctx.save(); ctx.globalAlpha = a; ctx.textAlign = 'center';
  ctx.font = '700 150px Oswald'; ctx.shadowColor = 'rgba(160,190,255,0.55)'; ctx.shadowBlur = 34; ctx.fillStyle = '#f4f6fb';
  ctx.fillText('ПЕРЕВАЛ', FX, 250); ctx.shadowBlur = 0; ctx.restore();
  text('СЕЗОН 1 · ВСЕ 6 СЕРИЙ', FX, 300, `600 22px ${MONO}`, AMBER, 'center', ease(prog(t, 2.6, 0.6)));
  tag('ЧЁРНЫЙ БОР · −43° · ШЕСТЕРО В АВТОБУСЕ', FX, 600, { align: 'center', col: '#9fb2d6', a: ease(prog(t, 3.4, 0.6)), size: 15 });
  const lk = prog(t, 4.2, 0.5);
  if (lk > 0) { cam(lerp(300, 345, push), 470, lerp(1.0, 1.18, push), () => { const X = 690, Y = 640; ctx.save(); const s = 1; lock(X - 22, Y - 52, 44, 66, lk, '#6ee1ff'); ctx.restore(); tag('7', X, Y - 62, { align: 'center', col: '#6ee1ff', a: lk, size: 13 }); }); }
  // fade in / out
  const fin = 1 - prog(t, 0, 0.8), fout = prog(t, INTRO_D - 0.6, 0.6);
  const k = Math.max(fin, fout); if (k > 0) { ctx.fillStyle = `rgba(3,4,9,${k})`; ctx.fillRect(0, 0, W, H); }
}

function titleFrame(t) {
  ctx.fillStyle = '#04050a'; ctx.fillRect(0, 0, W, H);
  glow(FX, 330, 560, 'rgba(60,90,170,0.18)');
  snowfall(t + EP * 10, 70, 30 + EP, { vy: 24, vx: -12, size: 1.8, a: 0.4 });
  const a = ease(prog(t, 0.15, 0.45));
  text('СЕРИЯ ' + EP, FX, 278, `600 26px ${MONO}`, AMBER, 'center', a);
  ctx.save(); ctx.globalAlpha = ease(prog(t, 0.3, 0.5)); ctx.textAlign = 'center';
  ctx.font = '700 96px Oswald'; ctx.shadowColor = 'rgba(160,190,255,0.45)'; ctx.shadowBlur = 26; ctx.fillStyle = '#f4f6fb';
  ctx.fillText('«' + TITLES[EP] + '»', FX, 388); ctx.restore();
  // a thin line with 7 ticks, the 7th orange
  const lp = easeOut(prog(t, 0.4, 0.9));
  ctx.save(); ctx.globalAlpha = a; ctx.strokeStyle = 'rgba(214,221,235,0.35)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(FX - 180, 430); ctx.lineTo(FX - 180 + 360 * lp, 430); ctx.stroke();
  for (let i = 0; i < 7; i++) { if (i / 6 > lp) break; ctx.fillStyle = i === 6 ? ORANGE : 'rgba(214,221,235,0.7)'; ctx.fillRect(FX - 180 + i * 60 - 1, 424, 2, 12); }
  ctx.restore();
  post(t, 0);
  const fout = prog(t, TITLE_D - 0.35, 0.35), fin = 1 - prog(t, 0, 0.2);
  const k = Math.max(fin, fout); if (k > 0) { ctx.fillStyle = `rgba(4,5,10,${k})`; ctx.fillRect(0, 0, W, H); }
}

function coverFrame() {
  const t = 2.0;
  cam(200, 540, 1.15, () => {
    nightRoad(t, { busX: 300, lights: 0.85 });
    // the seventh, standing in the headlights: Timur's jacket, Timur's camera
    ctx.save(); ctx.globalAlpha = 0.95; ctx.translate(640, 640); ctx.scale(0.17, 0.17); figure(0.6, t, 1); ctx.restore();
    spruce(-260, 1000, 620, '#050812'); spruce(1080, 1040, 680, '#050812');
    fog(t * 1.4, 620, 820, 0.12, 8);
  });
  snowfall(t, 170, 21, { vy: 60, vx: -30 });
  snowfall(t, 50, 22, { vy: 95, vx: -50, size: 3.6, a: 0.5 });
  post(t, 0.4);
  // lock on the seventh
  const fx = FX + (640 - 200) * 1.15, fy = FY + (640 - 540) * 1.15;
  lock(fx - 36, fy - 66, 72, 112, 1, '#6ee1ff');
  tag('ОБЪЕКТ 7 · −60°', fx, fy - 80, { align: 'center', col: '#6ee1ff', size: 17 });
  // title block on the left
  ctx.save(); ctx.fillStyle = vgrad(0, H, [[0, 'rgba(4,6,14,0.0)'], [1, 'rgba(4,6,14,0.0)']]); ctx.restore();
  const g = ctx.createLinearGradient(0, 0, 640, 0); g.addColorStop(0, 'rgba(3,5,12,0.8)'); g.addColorStop(1, 'rgba(3,5,12,0)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, 700, H);
  ctx.save(); ctx.textAlign = 'left'; ctx.font = '700 150px Oswald'; ctx.shadowColor = 'rgba(160,190,255,0.55)'; ctx.shadowBlur = 34; ctx.fillStyle = '#f4f6fb';
  ctx.fillText('ПЕРЕВАЛ', 60, 300); ctx.restore();
  text('ВЕСЬ 1 СЕЗОН · 6 СЕРИЙ', 66, 350, `700 26px ${MONO}`, AMBER);
  ctx.save(); ctx.font = '700 64px Oswald'; ctx.fillStyle = ORANGE; ctx.shadowColor = 'rgba(255,120,20,0.5)'; ctx.shadowBlur = 20;
  ctx.fillText('НАС ТЕПЕРЬ СЕМЬ', 62, 600); ctx.restore();
  // HUD, like the series
  drawHUD('ВЕЧЕР 1', 'ЧЁРНЫЙ БОР', '18:04:00');
  tag('−43°', W - LM, 132, { align: 'right', col: '#9fc0ff', size: 22 });
}

function render(t) {
  ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  if (MODE === 'intro') introFrame(t);
  else if (MODE === 'title') titleFrame(t);
  else coverFrame();
}
const DURATION = MODE === 'intro' ? INTRO_D : MODE === 'title' ? TITLE_D : 0.04;
