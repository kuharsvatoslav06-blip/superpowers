// =====================================================================
// Episode 5 — «Два Гоши». Builds on helpers from episodes 1–4.
// =====================================================================

// Window seen from inside. o.kid: show the boy outside; o.knock; o.letters: [{str, p, y, size}] written backwards in the frost;
// o.breath: 0..1 fogged patch; o.hand: 0..1 wet handprint; o.inside: 0..1 the other Gosha + Marina's hand in the foreground
function windowView(t, o = {}) {
  const { x, y, w, h } = WIN2;
  window2Frame(false);
  ctx.save(); rr(x, y, w, h, 34); ctx.clip();
  ctx.fillStyle = vgrad(y, y + h, [[0, '#4a5274'], [0.6, '#9aa2c2'], [1, '#d4d8ea']]); ctx.fillRect(x, y, w, h);
  const r = rng(19); for (let k = 0; k < 14; k++) spruce(x + 20 + k * 58 + r() * 20, y + h * 0.66, 100 + r() * 100, '#3a4060');
  ctx.fillStyle = '#d8dcec'; ctx.fillRect(x, y + h * 0.66, w, h * 0.34);
  if (o.kid) kid2(726, y + h * 0.72, 2.0, { mitL: true, mitR: false, knock: o.knock || 0, a: o.kid });
  // frost layer
  const g = ctx.createRadialGradient(680, y + h * 0.55, 120, 680, y + h * 0.55, 540); g.addColorStop(0, 'rgba(205,218,245,0.25)'); g.addColorStop(1, 'rgba(205,218,245,0.9)');
  ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
  if (o.breath > 0) { ctx.save(); ctx.translate(560, y + 175); ctx.scale(1.8, 0.8); glow(0, 0, 170, `rgba(238,244,255,${0.75 * o.breath})`); ctx.restore(); }
  // letters cleared through the frost, mirrored because they were written from outside
  for (const L of o.letters || []) {
    if (L.p <= 0) continue;
    ctx.save(); ctx.translate(L.x ?? 530, L.y ?? (y + 175)); ctx.scale(-1, 1);
    ctx.font = `700 ${L.size || 84}px Oswald`; ctx.textAlign = 'center';
    const full = ctx.measureText(L.str).width;
    ctx.beginPath(); ctx.rect(-full / 2 - 10, -L.size - 20 || -110, (full + 20) * L.p, 200); ctx.clip();
    ctx.fillStyle = 'rgba(40,52,84,0.82)'; ctx.fillText(L.str, 0, 0);
    ctx.fillStyle = 'rgba(160,190,230,0.5)'; ctx.fillText(L.str, 1.5, -2);
    ctx.restore();
  }
  if (o.hand > 0) handprint(796, y + 260, 1.0, 0.55 * o.hand, 'rgba(70,90,130,0.9)');
  ctx.restore();
  if (o.inside > 0) {
    // the other Gosha from behind, holding Marina's hand
    ctx.save(); ctx.globalAlpha = o.inside; ctx.translate(-60, -400);
    ctx.fillStyle = '#7a2338'; ctx.beginPath(); ctx.ellipse(620, 1140, 200, 150, 0, 0, 6.28); ctx.fill();
    ctx.strokeStyle = '#7a2338'; ctx.lineWidth = 40; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(560, 1060); ctx.lineTo(380, 1000); ctx.stroke();
    ctx.fillStyle = '#3d6fb5'; ctx.beginPath(); ctx.ellipse(220, 1150, 160, 130, 0, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#b8322a'; circle(360, 1000, 26); ctx.fill();
    ctx.fillStyle = '#f2c230'; circle(220, 980, 96); ctx.fill();
    ctx.strokeStyle = '#d9a916'; ctx.lineWidth = 5; for (let i = -3; i <= 3; i++) { ctx.beginPath(); ctx.moveTo(220 + i * 24, 900 + Math.abs(i) * 9); ctx.lineTo(220 + i * 26, 1070); ctx.stroke(); }
    ctx.fillStyle = '#fff3c4'; circle(220, 874, 26); ctx.fill();
    ctx.restore();
  }
}

// ---------------------------------------------------------------------
// 1. two — one Gosha holds mum's hand, the other knocks on the glass
// ---------------------------------------------------------------------
function sceneTwo(t) {
  const id = 'two', s = SC[id];
  const cHand = cue(id, 'РУКУ'), cKn = cue(id, 'СТУЧИТ');
  const knock = t > cKn - 0.1 ? 0.5 + 0.5 * Math.abs(Math.sin((t - cKn) * 5.5)) : 0.15;
  cam(600, 330, 1 + 0.06 * prog(t, s.s, s.e - s.s), () => {
    windowView(t, { kid: 1, knock, inside: 1 });
    if (t > cKn) for (let k = 0; k < 3; k++) { const p = ((t - cKn) * 0.9 + k / 3) % 1; ctx.strokeStyle = `rgba(255,233,168,${0.6 * (1 - p)})`; ctx.lineWidth = 2; circle(768, WIN2.y + WIN2.h * 0.5, 14 + p * 60); ctx.stroke(); }
    lock(40, 450, 360, 260, prog(t, cHand, 0.4), '#6ee1ff');
    lock(666, WIN2.y + WIN2.h * 0.42, 120, 250, prog(t, cKn, 0.4), '#7fe08a');
  });
  tag('В САЛОНЕ · −47°', LM, TY, { col: '#6ee1ff', a: prog(t, cHand + 0.2, 0.3) });
  tag('ЗА СТЕКЛОМ · +36°', W - LM, TY, { col: '#7fe08a', a: prog(t, cKn + 0.2, 0.3), align: 'right' });
  const fl = 1 - prog(t, s.s, 0.5); if (fl > 0) { ctx.fillStyle = `rgba(3,4,9,${fl})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'УТРО 2', b: 'ОКНО', clock: fmtClock(6 * 3600 + 17 * 60 + 40 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 2. write — he breathes on the glass and writes backwards: МАМА НЕ ВЕРЬ
// ---------------------------------------------------------------------
function sceneWrite(t) {
  const id = 'write', s = SC[id];
  const cBr = cue(id, 'ДЫШИТ'), cFin = cue(id, 'ПАЛЬЦЕМ'), cBack = cue(id, 'ЗАДОМ'), cM = cue(id, '«МАМА'), cV = cue(id, 'ВЕРЬ»');
  const breath = ease(prog(t, cBr, 1.0));
  const p1 = prog(t, cFin - 0.1, cM + 0.3 - cFin), p2 = prog(t, cM + 0.3, cV + 0.4 - cM - 0.3);
  const y0 = WIN2.y;
  cam(620, 300, lerp(1.0, 1.2, ease(prog(t, s.s, s.e - s.s))), () => {
    windowView(t, { kid: 1, breath, letters: [{ str: 'МАМА', p: p1, y: y0 + 150, size: 72 }, { str: 'НЕ ВЕРЬ', p: p2, y: y0 + 236, size: 72 }] });
  });
  tag('ЗЕРКАЛЬНО', LM, TY, { col: '#cdd6e8', a: prog(t, cBack, 0.3) });
  const ra = prog(t, cV + 0.2, 0.3);
  if (ra > 0) { ctx.save(); ctx.globalAlpha = ra; ctx.fillStyle = 'rgba(8,10,20,0.85)'; rr(290, 470, 380, 64, 10); ctx.fill(); ctx.strokeStyle = ORANGE; ctx.lineWidth = 1.5; ctx.stroke(); ctx.font = '700 40px Oswald'; ctx.textAlign = 'center'; ctx.fillStyle = ORANGE; ctx.fillText('«МАМА, НЕ ВЕРЬ»', 480, 516); ctx.restore(); }
  return { a: 'УТРО 2', b: 'ОКНО', clock: fmtClock(6 * 3600 + 17 * 60 + 52 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 3. inside — the Gosha inside tugs at Marina: "he's lying, he was in the fog"
// ---------------------------------------------------------------------
function cabinWithOutsider(t, o = {}) {
  ctx.fillStyle = '#d0d6e8'; ctx.fillRect(-600, -400, 1600, 2200);
  const r = rng(5); for (let i = 0; i < 60; i++) glow(r() * 1300 - 300, r() * 1400 - 100, 120, 'rgba(150,165,205,0.25)');
  cabinShell(false);
  glow(495, 165, 80, 'rgba(220,230,255,0.6)');
  cabinProps(t);
  for (const p of PEOPLE) { if ((o.hide || []).includes(p.id)) continue; person(p, t); }
  if (o.marina) person(Object.assign({}, MARINA, o.marina), t);
  ctx.fillStyle = 'rgba(40,70,130,0.18)'; ctx.fillRect(-600, -300, 1600, 1900);
  // the boy outside, just beyond the right wall
  if (o.outside > 0) {
    ctx.save(); ctx.globalAlpha = o.outside;
    person({ id: 'X', x: 590, y: 812, coat: '#3d6fb5', head: '#f2c230', k: 0.66 }, t);
    ctx.restore();
  }
}
function sceneInside(t) {
  const id = 'inside', s = SC[id];
  const cTug = cue(id, 'ТЯНЕТ'), cLie = cue(id, 'ВРЁТ'), cFog = cue(id, 'ТУМАНЕ»');
  const tug = ease(prog(t, cTug, 0.5));
  const sc = 2.2 + 0.1 * prog(t, s.s, s.e - s.s);
  rcam(520, 800, sc, () => {
    cabinWithOutsider(t, { outside: 1 });
    if (tug > 0) { ctx.save(); ctx.strokeStyle = '#3d6fb5'; ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(GOSHA.x - 6, GOSHA.y); ctx.lineTo(lerp(GOSHA.x - 6, MARINA.x + 18, tug), lerp(GOSHA.y, MARINA.y + 2, tug)); ctx.stroke(); ctx.restore(); }
    lock(GOSHA.x - 24, GOSHA.y - 24, 48, 46, prog(t, s.s + 0.3, 0.4), '#6ee1ff');
    lock(566, 788, 48, 48, prog(t, cFog, 0.4), '#7fe08a');
  });
  const p = rscr(GOSHA.x, GOSHA.y, 520, 800, sc);
  bubble(p.x - 150, p.y - 150, 270, 74, '«ОН ВРЁТ»', prog(t, cLie - 0.1, 0.25) * (1 - prog(t, cFog - 0.3, 0.2)), 70, 80, '#6ee1ff');
  tag('ГОША В САЛОНЕ', LM, TY, { col: '#6ee1ff', a: prog(t, s.s + 0.5, 0.3) });
  tag('ГОША ЗА СТЕНОЙ', W - LM, TY, { col: '#7fe08a', a: prog(t, cFog, 0.3), align: 'right' });
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 18 * 60 + 10 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 4. test — Fomich: ask what only he knows. Marina: what's your bear called?
// ---------------------------------------------------------------------
function sceneTest(t) {
  const id = 'test', s = SC[id];
  const cOnly = cue(id, 'ТОЛЬКО'), cMar = cue(id, 'МАРИНА'), cBear = cue(id, 'МЕДВЕДЯ?»');
  const toM = ease(prog(t, cMar - 0.3, 0.9));
  const mx = lerp(MARINA.x, 512, ease(prog(t, cMar, 1.0)));
  const fx = lerp(FOMICH.x - 20, 520, toM), fy = lerp(FOMICH.y, 800, toM), sc = lerp(2.2, 2.4, toM);
  rcam(fx, fy, sc, () => {
    cabinWithOutsider(t, { outside: 1, hide: ['МАРИНА'], marina: { x: mx, y: MARINA.y } });
    lock(FOMICH.x - 38, FOMICH.y - 36, 76, 70, prog(t, s.s + 0.2, 0.4) * (1 - toM), '#ffe9a8');
  });
  tag('ВОПРОС-ПРОВЕРКА', LM, TY, { col: '#ffe9a8', a: prog(t, cOnly, 0.3) });
  const qa = prog(t, cBear, 0.3);
  if (qa > 0) { ctx.save(); ctx.globalAlpha = qa; ctx.fillStyle = 'rgba(8,10,20,0.85)'; rr(FX - 200, 108, 400, 110, 12); ctx.fill(); ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore(); text('КАК ЗОВУТ МЕДВЕДЯ?', FX, 154, `700 22px ${MONO}`, '#f1f4fb', 'center', qa); text('ЗНАЕТ ТОЛЬКО ГОША', FX, 192, `600 15px ${MONO}`, '#9aa6bf', 'center', qa); }
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 18 * 60 + 30 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 5. buba — both answer at once: split screen
// ---------------------------------------------------------------------
function sceneBuba(t) {
  const id = 'buba', s = SC[id];
  const c1 = cue(id, '«БУБА»', 0), c2 = cue(id, '«БУБА»', 1), cBoth = cue(id, 'ОБА');
  ctx.fillStyle = '#05070d'; ctx.fillRect(0, 0, W, H);
  // left: the window, the boy outside
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, 638, H); ctx.clip();
  cam(680, 320, 0.76, () => windowView(t, { kid: 1, letters: [{ str: 'БУБА', p: prog(t, c1 - 0.6, 0.9), y: WIN2.y + 200, size: 96 }] }), 320, 320);
  ctx.restore();
  // right: the cabin, the boy inside
  const BX = 960, BY = 330, GS = 2.3;
  ctx.save(); ctx.beginPath(); ctx.rect(642, 0, 638, H); ctx.clip();
  rcam(GOSHA.x - 40, GOSHA.y - 20, GS, () => cabinWithOutsider(t, { outside: 0 }), BX, BY);
  ctx.restore();
  ctx.fillStyle = '#f1f4fb'; ctx.fillRect(638, 0, 4, H);
  tag('ЗА ОКНОМ', LM, TY, { col: '#7fe08a' }); tag('В САЛОНЕ', 642 + LM, TY, { col: '#6ee1ff' });
  const p = rscr(GOSHA.x, GOSHA.y, GOSHA.x - 40, GOSHA.y - 20, GS, BX, BY);
  bubble(p.x - 130, p.y - 150, 220, 74, '«БУБА»', prog(t, c2 - 0.1, 0.25), 70, 80, '#6ee1ff');
  text(fmtClock(6 * 3600 + 18 * 60 + 47).slice(3), 600, TY + 2, `700 18px ${MONO}`, '#f1f4fb', 'right', prog(t, c1, 0.2));
  text(fmtClock(6 * 3600 + 18 * 60 + 47).slice(3), W - LM, TY + 40, `700 18px ${MONO}`, '#f1f4fb', 'right', prog(t, c2, 0.2));
  const b = prog(t, cBoth, 0.3);
  if (b > 0) { lock(130, 214, 200, 100, b, '#ffe9a8'); lock(p.x - 80, p.y - 80, 160, 160, b, '#ffe9a8'); tag('СОВПАДЕНИЕ · 100%', FX, TY + 64, { align: 'center', col: '#ffe9a8', a: b, size: 16 }); }
  return { a: 'УТРО 2', b: 'ПРОВЕРКА', clock: fmtClock(6 * 3600 + 18 * 60 + 44 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 6. door — Igor opens the door
// ---------------------------------------------------------------------
function doorOpening(t, open, snowRush) {
  const { x, y, w, h } = DOORF;
  ctx.fillStyle = '#121822'; ctx.fillRect(-900, -300, 2600, 1900);
  glow(120, 1040, 380, 'rgba(255,170,80,0.18)');
  doorWalls(x, y, w, h, false);
  rr(x - 26, y - 26, w + 52, h + 70, 18); ctx.fillStyle = '#1e2836'; ctx.fill();
  // what is behind the opening: bright fog
  ctx.save(); rr(x, y, w, h, 10); ctx.clip();
  ctx.save(); ctx.translate(x + w / 2, y + h / 2); ctx.scale(0.6, 0.6); ctx.translate(-360, -560); fogField(t, { seed: 41 }); ctx.restore();
  ctx.restore();
  // the two leaves fold away to the sides
  for (let k = 0; k < 2; k++) {
    const pw = (w / 2 - 6) * (1 - 0.82 * open), px = k ? x + w - pw : x;
    rr(px + 3, y, pw, h, 10); ctx.fillStyle = '#2a3a33'; ctx.fill();
    const gx = px + 18, gw = pw - 30;
    if (gw > 10) for (let j = 0; j < 2; j++) { rr(gx, y + 24 + j * (h / 2 - 6), gw, h / 2 - 48, 8); ctx.fillStyle = '#18243e'; ctx.fill(); }
  }
  ctx.fillStyle = '#0b0f15'; ctx.fillRect(x - 40, y + h + 26, w + 80, 70);
  if (snowRush > 0) {
    const r = rng(Math.floor(t * 30));
    ctx.fillStyle = `rgba(240,244,255,${0.8 * snowRush})`;
    for (let i = 0; i < 90; i++) { const a = r() * 6.28, d = 60 + r() * 600; circle(x + w / 2 + Math.cos(a) * d * snowRush, y + h / 2 + Math.sin(a) * d * 0.7 * snowRush + 100, 2 + r() * 3); ctx.fill(); }
  }
}
function sceneDoor5(t) {
  const id = 'door', s = SC[id];
  const cIn = cue(id, 'ВПУЩУ»'), cNo = cue(id, '«НЕЛЬЗЯ!»'), cOpen = cue(id, 'ОТКРЫТА');
  const open = ease(prog(t, cIn + 0.2, cOpen + 0.3 - cIn - 0.2));
  cam(360, 560, 0.78 * (1 + 0.08 * prog(t, s.s, s.e - s.s)), () => {
    doorOpening(t, open, 0);
    // Igor's arm on the lever
    ctx.fillStyle = '#20242d'; rr(lerp(-560, -180, ease(prog(t, s.s + 0.3, 0.8))), 600, 560, 54, 26); ctx.fill();
    ctx.fillStyle = '#2b2420'; circle(lerp(0, 380, ease(prog(t, s.s + 0.3, 0.8))), 627, 26); ctx.fill();
  });
  bubble(260, 250, 260, 74, '«НЕЛЬЗЯ!»', prog(t, cNo - 0.1, 0.2) * (1 - prog(t, cOpen, 0.3)), -60, 70, '#ff6a4a');
  tag('ИГОРЬ', LM, TY, { col: ORANGE, a: prog(t, s.s + 0.4, 0.3) });
  tag('ДВЕРЬ · ' + (open > 0.95 ? 'ОТКРЫТА' : open > 0.02 ? 'ОТКРЫВАЕТСЯ' : 'ЗАКРЫТА'), W - LM, TY, { col: open > 0.95 ? '#ff6a4a' : '#cdd6e8', align: 'right' });
  return { a: 'УТРО 2', b: 'ДВЕРЬ', clock: fmtClock(6 * 3600 + 19 * 60 + 2 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 7. empty — snow rushes in; nobody outside; only the writing and a wet handprint
// ---------------------------------------------------------------------
function sceneEmpty(t) {
  const id = 'empty', s = SC[id];
  const cNone = cue(id, 'НИКОГО'), cSign = cue(id, 'НАДПИСЬ'), cPalm = cue(id, 'ЛАДОНИ');
  const rush = 1 - prog(t, s.s + 0.8, 1.2);
  cam(640, 300, 1.05 + 0.1 * prog(t, s.s, s.e - s.s), () => {
    windowView(t, { kid: 0, letters: [{ str: 'МАМА', p: 1, y: WIN2.y + 150, size: 72 }, { str: 'НЕ ВЕРЬ', p: 1, y: WIN2.y + 236, size: 72 }], hand: prog(t, cPalm - 0.1, 0.5) });
    lock(380, WIN2.y + 76, 300, 186, prog(t, cSign, 0.4), ORANGE);
    lock(746, WIN2.y + 200, 100, 120, prog(t, cPalm, 0.4), '#6ee1ff');
  });
  if (rush > 0) { const r = rng(Math.floor(t * 30)); ctx.fillStyle = `rgba(240,244,255,${0.85 * rush})`; for (let i = 0; i < 160; i++) { circle(r() * W, r() * H, 2 + r() * 4); ctx.fill(); } ctx.fillStyle = `rgba(230,236,250,${0.35 * rush})`; ctx.fillRect(0, 0, W, H); }
  tag('ЗА ОКНОМ · ТЁПЛЫХ: 0', LM, TY, { col: '#ff6a4a', a: prog(t, cNone, 0.3) });
  tag('СЛЕД ЛАДОНИ · ДЕТСКИЙ', W - LM, TY, { align: 'right', col: '#6ee1ff', a: prog(t, cPalm + 0.3, 0.3), size: 14 });
  return { a: 'УТРО 2', b: 'ОКНО', clock: fmtClock(6 * 3600 + 19 * 60 + 14 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 8. seven — thermal: six people, seven on the screen; the seventh puts a hand on Igor's shoulder
// ---------------------------------------------------------------------
const SEVENTH = { x: 336, y: 746 };
function sceneSeven(t) {
  const id = 'seven', s = SC[id];
  const cSix = cue(id, 'ШЕСТЬ'), c7 = cue(id, 'СЕМЬ'), cBeh = cue(id, 'ИГОРЕМ'), cHand = cue(id, 'ПЛЕЧО');
  const on = ease(prog(t, s.s + 0.2, 0.5));
  const tf = Math.min(t, cHand + 0.5);
  const zi = ease(prog(tf, cBeh - 0.4, 0.9));
  rcam(lerp(360, 316, zi), lerp(540, 722, zi), lerp(1.08, 2.6, zi), () => {
    ctx.fillStyle = '#120a33'; ctx.fillRect(-600, -400, 1600, 2400);
    cabinShell(true);
    ctx.fillStyle = '#35268a';
    for (const y of ROWS) for (const x of [230, 292, 428, 490]) { rr(x - 28, y - 34, 56, 70, 10); ctx.fill(); }
    rr(204, 904, 312, 62, 12); ctx.fill();
    // five warm, one cold (Gosha)
    PEOPLE.forEach((p, i) => {
      if (p.id === 'ГОША') { ctx.fillStyle = '#020108'; circle(p.x, p.y, 13); ctx.fill(); ctx.strokeStyle = 'rgba(110,225,255,0.7)'; ctx.lineWidth = 1.4; circle(p.x, p.y, 17); ctx.stroke(); }
      else heat(p.x, p.y, p.k, on);
      const a = prog(tf, cSix - 0.1 + i * 0.1, 0.2);
      if (a > 0) { ctx.save(); ctx.globalAlpha = a * (1 - zi); circle(p.x, p.y - 44, 15); ctx.fillStyle = '#f1f4fb'; ctx.fill(); ctx.restore(); text(String(i + 1), p.x, p.y - 37, `800 18px ${MONO}`, '#10131f', 'center', a * (1 - zi)); }
    });
    // the seventh: a hole in the heat, behind Igor
    const a7 = prog(tf, c7 - 0.1, 0.5);
    if (a7 > 0) {
      ctx.save(); ctx.globalAlpha = a7;
      glow(SEVENTH.x, SEVENTH.y, 70, 'rgba(40,120,255,0.3)');
      ctx.fillStyle = '#020108'; ctx.beginPath(); ctx.ellipse(SEVENTH.x, SEVENTH.y, 26, 17, 0, 0, 6.28); ctx.fill(); circle(SEVENTH.x, SEVENTH.y - 2, 11); ctx.fill();
      ctx.strokeStyle = `rgba(110,225,255,${0.55 + 0.35 * Math.sin(tf * 5)})`; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(SEVENTH.x, SEVENTH.y, 30, 21, 0, 0, 6.28); ctx.stroke();
      ctx.restore();
      ctx.save(); ctx.globalAlpha = a7 * (1 - zi); circle(SEVENTH.x, SEVENTH.y - 46, 15); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore();
      text('7', SEVENTH.x, SEVENTH.y - 39, `800 18px ${MONO}`, '#fff', 'center', a7 * (1 - zi));
      lock(SEVENTH.x - 40, SEVENTH.y - 34, 80, 66, prog(tf, cBeh - 0.2, 0.4), '#6ee1ff');
    }
    // its hand on Igor's shoulder
    const hd = ease(prog(tf, cHand - 0.3, 0.6));
    if (hd > 0) {
      const tx = IGOR4.x + 16, ty = IGOR4.y + 8;
      ctx.save(); ctx.strokeStyle = '#020108'; ctx.lineWidth = 9; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(SEVENTH.x - 14, SEVENTH.y - 8); ctx.lineTo(lerp(SEVENTH.x - 14, tx, hd), lerp(SEVENTH.y - 8, ty, hd)); ctx.stroke();
      ctx.strokeStyle = 'rgba(110,225,255,0.8)'; ctx.lineWidth = 1.2; ctx.stroke(); ctx.restore();
      glow(lerp(SEVENTH.x - 14, tx, hd), lerp(SEVENTH.y - 8, ty, hd), 24, 'rgba(110,225,255,0.6)');
    }
  });
  const nShown = t > c7 ? 7 : Math.min(6, Math.floor(prog(t, cSix - 0.1, 0.7) * 6.99));
  tag('НА ЭКРАНЕ', LM, TY, { col: '#ffe9a8', a: on * (1 - zi) }); text(nShown + ' / 6', LM + 150, TY + 2, `700 22px ${MONO}`, t > c7 ? '#ff6a4a' : '#ffe9a8', 'left', on * (1 - zi));
  tag('ОБЪЕКТ 7 · −61°', 1040, 250, { align: 'center', col: '#6ee1ff', a: prog(t, cBeh, 0.3), size: 16 });
  imagerUI(t, on);
  if (t > cHand + 0.5) { const f = prog(t, cHand + 0.5, 0.25); ctx.fillStyle = `rgba(120,10,10,${0.2 * f})`; ctx.fillRect(0, 0, W, H); bracket(60, 100, 1160, 470, '#ff3b30', f, 40, 3); }
  return { a: 'УТРО 2', b: 'ТЕПЛОВИЗОР', clock: fmtClock(6 * 3600 + 19 * 60 + 40 + (tf - s.s)) };
}
