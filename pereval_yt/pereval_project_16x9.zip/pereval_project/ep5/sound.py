"""Sound design + final mix: wind, drone, footsteps, hits, heartbeat under the narration."""
import json, wave, numpy as np
from pathlib import Path
H = Path(__file__).parent; SR = 44100
tl = json.loads((H / 'timeline.json').read_text()); END = tl['voice_end']; DUR = END + 1.2
N = int(DUR * SR); t = np.arange(N) / SR; rs = np.random.RandomState(4)
sc = {s['id']: s for s in tl['scenes']}
def cue(sid, word):
    for c in sc[sid]['cards']:
        for l in c['lines']:
            for w in l:
                if w['t'].strip('«»,.:') == word: return w['s']
    raise KeyError(word)
def lp(x, fc):
    a = np.exp(-2 * np.pi * fc / SR); y = np.empty_like(x); z = 0.0
    for i in range(len(x)): z = a * z + (1 - a) * x[i]; y[i] = z
    return y
def lpf(x, fc):                      # fast FFT low-pass
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR); X *= 1 / (1 + (f / fc) ** 4); return np.fft.irfft(X, len(x))
def hpf(x, fc): return x - lpf(x, fc)
mix = np.zeros(N)
def add(sig, at, gain=1.0):
    i = int(at * SR)
    if i >= N or i < 0: return
    sig = sig[:N - i]; mix[i:i + len(sig)] += sig * gain
def env(n, a, d): x = np.arange(n) / SR; return np.minimum(1, x / a) * np.exp(-np.maximum(0, x - a) / d)

# wind: band-limited noise with slow gusts
w = hpf(lpf(rs.randn(N), 900), 120)
gust = 0.55 + 0.45 * np.sin(2 * np.pi * 0.07 * t + 1) * np.sin(2 * np.pi * 0.023 * t)
mix += w / np.abs(w).max() * gust * 0.10
# low drone that thickens towards the end
grow = 0.35 + 0.65 * np.clip((t - sc['empty']['s']) / (END - sc['empty']['s']), 0, 1)
dr = np.sin(2 * np.pi * 49 * t) + 0.6 * np.sin(2 * np.pi * 73.6 * t + np.sin(2 * np.pi * 0.11 * t)) + 0.35 * np.sin(2 * np.pi * 98.3 * t)
mix += dr * 0.045 * grow * np.minimum(1, t / 3)
# engine sputters and dies
n = int(2.4 * SR); x = np.arange(n) / SR
rate = 26 * np.exp(-x * 0.9); ph = 2 * np.pi * np.cumsum(rate) / SR
eng = (np.sign(np.sin(ph)) * 0.5 + np.sin(ph * 2)) * np.exp(-x * 1.1)

def hit(f=46, d=0.9, g=1.0):
    n = int(2.2 * SR); x = np.arange(n) / SR
    return (np.sin(2 * np.pi * f * x * (1 + 0.6 * np.exp(-x * 9))) * np.exp(-x / d) + lpf(rs.randn(n), 300) * np.exp(-x / 0.12) * 0.6) * g
def whoosh(d=0.45):
    n = int(d * SR); x = np.arange(n) / n; return hpf(lpf(rs.randn(n), 2500), 300) * np.sin(np.pi * x) ** 2
def crunch():
    n = int(0.16 * SR); return hpf(lpf(rs.randn(n), 3200), 700) * env(n, 0.012, 0.05)
def beep(f=1760, d=0.09):
    n = int(d * SR); x = np.arange(n) / SR; return np.sin(2 * np.pi * f * x) * env(n, 0.004, 0.05)
def tick(): n = int(0.03 * SR); return hpf(rs.randn(n), 3000) * env(n, 0.001, 0.008)
for s_ in tl['scenes'][1:]:
    add(whoosh(), s_['s'] - 0.22, 0.16); add(hit(52, 0.5), s_['s'], 0.16)
def cue_n(sid, word, n):
    k = 0
    for c in sc[sid]['cards']:
        for l in c['lines']:
            for w in l:
                if w['t'].strip('«»,.:') == word:
                    if k == n: return w['s']
                    k += 1
    raise KeyError(word)
def tap(g=0.25):
    n = int(0.25 * SR); x = np.arange(n) / SR
    return (np.sin(2 * np.pi * 420 * x) * 0.4 + hpf(rs.randn(n), 1500) * 0.6) * np.exp(-x / 0.025) * g
for k in range(8): add(tap(), cue('two', 'СТУЧИТ') - 0.1 + k * 0.57, 1.0)
add(hit(40, 1.2), cue('two', 'РУКУ'), 0.35)
n = int(1.2 * SR); add(lpf(rs.randn(n), 700) * np.sin(np.pi * np.arange(n) / n) ** 2, cue('write', 'ДЫШИТ'), 0.2)
a_ = cue('write', 'ПАЛЬЦЕМ'); b_ = cue('write', 'ВЕРЬ') + 0.4
for i in range(10):
    n = int(0.3 * SR); x = np.arange(n) / SR
    add(np.sin(2 * np.pi * (2300 + 500 * x) * x) * np.sin(np.pi * x / 0.3) ** 2, a_ + (b_ - a_) * i / 10, 0.03)
add(hit(36, 1.8), cue('write', 'ВЕРЬ'), 0.5)
add(hit(44, 1.0), cue('inside', 'ВРЁТ'), 0.35)
add(beep(660, 0.3), cue('test', 'МЕДВЕДЯ?'), 0.08)
add(hit(40, 1.2), cue_n('buba', 'БУБА', 0), 0.4); add(hit(34, 2.0), cue_n('buba', 'БУБА', 1), 0.55)
add(beep(1760, 0.1), cue('buba', 'ОБА'), 0.1)
add(hit(38, 1.4), cue('door', 'НЕЛЬЗЯ!'), 0.45)
n = int(2.5 * SR); wi = hpf(lpf(rs.randn(n), 1800), 200) * np.minimum(1, np.arange(n) / (0.3 * SR)) * np.exp(-np.arange(n) / (1.4 * SR))
add(wi, cue('door', 'ОТКРЫТА') - 0.2, 0.5); add(hit(36, 1.6), cue('door', 'ОТКРЫТА'), 0.5)
add(hit(40, 1.4), cue('empty', 'НИКОГО'), 0.45); add(hit(36, 1.6), cue('empty', 'ЛАДОНИ'), 0.4)
add(beep(880, 0.25), sc['seven']['s'] + 0.2, 0.08); add(beep(1760, 0.08), sc['seven']['s'] + 0.6, 0.07)
for i in range(6): add(beep(1500, 0.05), cue('seven', 'ШЕСТЬ') - 0.1 + i * 0.1, 0.06)
add(hit(34, 2.0), cue('seven', 'СЕМЬ'), 0.6)
hb, period = cue('seven', 'СЕМЬ'), 0.8
while hb < cue('seven', 'ПЛЕЧО') + 0.4:
    for off, g in ((0, 1.0), (0.16, 0.7)):
        n = int(0.3 * SR); x = np.arange(n) / SR
        add(np.sin(2 * np.pi * 52 * x * (1 + 0.5 * np.exp(-x * 30))) * np.exp(-x / 0.07), hb + off, 0.55 * g)
    hb += period; period = max(0.42, period * 0.92)
add(hit(30, 2.6), cue('seven', 'ПЛЕЧО') + 0.5, 0.85)
mix[int((cue('seven', 'ПЛЕЧО') + 0.55) * SR):int(END * SR)] *= 0.25
# glitch, then a final impact and silence
n = int(0.75 * SR); g = rs.randn(n) * (rs.rand(n) > 0.4) * np.repeat(rs.rand(n // 441 + 1) > 0.5, 441)[:n] * np.linspace(0.2, 1, n)
add(hit(30, 2.6), END, 0.9)
mix[int(END * SR):] *= np.linspace(1, 0.55, N - int(END * SR))

# narration on top, ambience ducked slightly under it
with wave.open(str(H / 'voice.wav')) as wv: v = np.frombuffer(wv.readframes(wv.getnframes()), np.int16).astype(np.float64) / 32768
voice = np.zeros(N); voice[:len(v)] = v[:N]
level = lpf(np.abs(voice), 4)
duck = 1 - 0.35 * np.clip(level / 0.12, 0, 1)
out = voice * 0.95 + mix * duck
out = np.clip(np.tanh(out * 1.15) / np.tanh(1.15) * 0.9, -0.98, 0.98)
fade = int(0.4 * SR); out[-fade:] *= np.linspace(1, 0, fade)
st = np.stack([out, out], 1)
with wave.open(str(H / 'mix.wav'), 'wb') as wv:
    wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((st * 32767).astype(np.int16).tobytes())
print('mix', round(DUR, 2), 'peak', round(float(np.abs(out).max()), 3))
