// =====================================================================
// Episode 2 — «Второе правило». Reuses world/cabin/thermal helpers from episode 1.
// =====================================================================
const scr = (x, y, fx, fy, s) => ({ x: (x - fx) * s + FX, y: (y - fy) * s + FY });
const T_REC0 = 6 * 3600 + 12 * 60;

function glitch(t, amt, seedRate = 24) {
  if (amt <= 0) return;
  const r = rng(Math.floor(t * seedRate));
  for (let i = 0; i < 9; i++) {
    const y = r() * 640 * SCALE, h = (8 + r() * 46) * SCALE, dx = (r() - 0.5) * 140 * amt * SCALE;
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(ctx.canvas, 0, y, W * SCALE, h, dx, y, W * SCALE, h); ctx.restore();
  }
  if (r() > 0.6) { ctx.fillStyle = `rgba(255,255,255,${0.07 * amt})`; ctx.fillRect(0, 0, W, H); }
}
// camcorder overlay used while the recording plays
function recOverlay(t, clock, a = 1) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = 'rgba(70,110,90,0.10)'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(0,0,0,0.13)'; for (let y = 0; y < H; y += 3) ctx.fillRect(0, y, W, 1);
  ctx.restore();
  bracket(40, 104, 1200, 506, 'rgba(235,240,250,0.85)', a, 34, 2.5);
  if (Math.sin(t * 6) > -0.2) { ctx.save(); ctx.globalAlpha = a; circle(80, 140, 8); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore(); }
  text('REC', 96, 148, `700 22px ${MONO}`, '#f1f4fb', 'left', a);
  text('15.01  ' + fmtClock(clock), 1200, 148, `600 20px ${MONO}`, '#f1f4fb', 'right', a);
  text('REC_0044', 80, 592, `600 16px ${MONO}`, 'rgba(241,244,251,0.85)', 'left', a);
  ctx.save(); ctx.globalAlpha = a; ctx.strokeStyle = 'rgba(241,244,251,0.85)'; ctx.lineWidth = 2; ctx.strokeRect(1146, 576, 44, 20);
  ctx.fillStyle = 'rgba(241,244,251,0.85)'; ctx.fillRect(1149, 579, 10, 14); ctx.fillRect(1190, 582, 4, 8); ctx.restore();
}
function waveform(t, x, y, w, h, amp, col = '#ffe9a8') {
  if (amp <= 0) return;
  const n = 32, bw = w / n, r = rng(Math.floor(t * 18));
  ctx.save(); ctx.fillStyle = col; ctx.globalAlpha = amp;
  for (let i = 0; i < n; i++) {
    const env = Math.sin(Math.PI * (i + 0.5) / n), v = (0.15 + 0.85 * r()) * env;
    rr(x + i * bw + 1, y - v * h / 2, bw - 3, Math.max(2, v * h), 2); ctx.fill();
  }
  ctx.restore();
}
function cameraScreen(fx, fy, z, drawScreen) {
  cam(fx, fy, z, () => {
    // same camera as the file list in episode 1 (screen 264..1016 × 102..506)
    ctx.fillStyle = '#06080e'; ctx.fillRect(-600, -300, 2400, 1400);
    glow(640, 300, 640, 'rgba(70,110,200,0.22)');
    rr(230, 66, 820, 474, 34); ctx.fillStyle = '#161a22'; ctx.fill(); ctx.lineWidth = 3; ctx.strokeStyle = '#2b3240'; ctx.stroke();
    rr(264, 102, 752, 404, 10); ctx.fillStyle = '#080d1c'; ctx.fill();
    ctx.save(); rr(264, 102, 752, 404, 10); ctx.clip(); drawScreen();
    ctx.fillStyle = 'rgba(0,0,0,0.14)'; for (let y = 102; y < 506; y += 3) ctx.fillRect(264, y, 752, 1);
    ctx.restore();
    ctx.fillStyle = '#0c0e14'; ctx.beginPath(); ctx.ellipse(196, 470, 70, 130, 0.25, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(1084, 470, 70, 130, -0.25, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#b85a12'; ctx.beginPath(); ctx.ellipse(166, 670, 80, 110, 0.3, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(1114, 670, 80, 110, -0.3, 0, 6.28); ctx.fill();
  });
}

// ---------------------------------------------------------------------
// 1. play — REC_0044 is 1:37 long and dated tomorrow
// ---------------------------------------------------------------------
function scenePlay(t) {
  const id = 'play', s = SC[id];
  const cLen = cue(id, '1:37'), cTom = cue(id, 'ЗАВТРА'), cTime = cue(id, '06:12'), cPlay = cue(id, '«ПУСК»');
  const go = ease(prog(t, cPlay + 0.15, s.e - cPlay - 0.15));
  const z = 1 + 0.04 * prog(t, s.s, cPlay - s.s) + 3.2 * go * go;
  cameraScreen(640, 304, z, () => {
    glow(640, 300, 480, 'rgba(60,96,190,0.25)');
    const listA = 1 - prog(t, cPlay, 0.25);
    if (listA > 0) {
      ctx.save(); ctx.globalAlpha = listA;
      text('ФАЙЛЫ', 300, 148, `700 19px ${MONO}`, '#cdd6e8');
      text('СЕГОДНЯ: 14.01', 984, 148, `700 19px ${MONO}`, '#8a96b0', 'right');
      ctx.fillStyle = 'rgba(140,160,210,0.25)'; ctx.fillRect(300, 164, 684, 2);
      ctx.fillStyle = 'rgba(255,255,255,0.12)'; rr(286, 186, 712, 50, 6); ctx.fill();
      const hi = (c, col) => t > c ? col : '#ffffff';
      text('REC_0044', 300, 220, `800 22px ${MONO}`, '#ffffff');
      text('15.01', 560, 220, `800 22px ${MONO}`, hi(cTom, ORANGE));
      text('06:12', 700, 220, `800 22px ${MONO}`, hi(cTime, ORANGE));
      text('01:37', 984, 220, `800 22px ${MONO}`, hi(cLen, ORANGE), 'right');
      [['REC_0043', '14.01', '19:33', '00:52'], ['REC_0042', '14.01', '18:03', '00:48'], ['REC_0041', '14.01', '17:52', '02:14']].forEach((r, i) => {
        const y = 284 + i * 64;
        text(r[0], 300, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[1], 560, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[2], 700, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[3], 984, y, `600 22px ${MONO}`, '#7f8ca6', 'right');
      });
      ctx.restore();
      lock(910, 194, 82, 34, prog(t, cLen, 0.35), ORANGE);
      lock(552, 194, 78, 34, prog(t, cTom, 0.35), ORANGE);
      lock(692, 194, 78, 34, prog(t, cTime, 0.35), ORANGE);
    }
    const pa = prog(t, cPlay - 0.05, 0.2);
    if (pa > 0) {
      const k = 1 + 0.15 * pulse(t, cPlay, 0.3);
      ctx.save(); ctx.globalAlpha = pa; ctx.translate(640, 304); ctx.scale(k, k);
      circle(0, 0, 58); ctx.fillStyle = 'rgba(255,255,255,0.12)'; ctx.fill(); ctx.strokeStyle = '#f1f4fb'; ctx.lineWidth = 3; ctx.stroke();
      ctx.fillStyle = '#f1f4fb'; ctx.beginPath(); ctx.moveTo(-16, -26); ctx.lineTo(30, 0); ctx.lineTo(-16, 26); ctx.closePath(); ctx.fill();
      ctx.restore();
      const p = prog(t, cPlay + 0.2, s.e - cPlay);
      ctx.fillStyle = 'rgba(241,244,251,0.25)'; ctx.fillRect(300, 470, 680, 4);
      ctx.fillStyle = ORANGE; ctx.fillRect(300, 470, 680 * p * 0.04, 4);
      text('00:0' + Math.floor(p * 4) + ' / 01:37', 980, 455, `600 16px ${MONO}`, '#cdd6e8', 'right', pa);
    }
  });
  if (go > 0) { ctx.fillStyle = `rgba(200,215,240,${0.55 * go * go})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'ВЕЧЕР 1', b: 'КАМЕРА ТИМУРА', clock: fmtClock(19 * 3600 + 35 * 60 + 40 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 2. recbus — the recording: the bus at dawn, snowed in, door open
// ---------------------------------------------------------------------
function sceneRecBus(t) {
  const id = 'recbus', s = SC[id];
  const cSnow = cue(id, 'СНЕГ'), cWalk = cue(id, 'ПОДХОДИТ'), cOpen = cue(id, 'ОТКРЫТА');
  const walk = ease(prog(t, cWalk - 0.2, cOpen + 0.5 - cWalk));
  const hx = Math.sin(t * 1.7) * 5 + Math.sin(t * 3.3) * 2, hy = Math.sin(t * 2.3) * 4 + Math.abs(Math.sin(t * 3.6)) * 4 * walk;
  const fx = lerp(330, 486, walk) + hx, fy = lerp(535, 590, walk) + hy, sc = lerp(1.05, 2.3, walk);
  cam(fx, fy, sc, () => {
    ctx.fillStyle = vgrad(0, 600, [[0, '#141a36'], [0.55, '#4b4467'], [0.85, '#a8728a'], [1, '#e2a07c']]); ctx.fillRect(-900, -300, 2600, 920);
    glow(40, 575, 320, 'rgba(255,190,140,0.35)');
    const r = rng(41);
    for (let x = -420; x < 1150; x += 36) spruce(x + r() * 20, 586, 90 + r() * 120, '#2a2c4a');
    for (let x = -440; x < 1170; x += 64) spruce(x + r() * 30, 604, 170 + r() * 140, '#171a33', 'rgba(220,200,230,0.3)');
    ctx.fillStyle = vgrad(590, 1300, [[0, '#b9b9d6'], [0.3, '#8d93b8'], [1, '#3a4166']]); ctx.fillRect(-900, 590, 2600, 800);
    busSide(330, 668, 0);
    // drift up to the windows, untouched snow (no footprints)
    ctx.fillStyle = '#c9cbe0'; ctx.beginPath(); ctx.moveTo(60, 700); ctx.bezierCurveTo(120, 600, 200, 586, 300, 584); ctx.bezierCurveTo(380, 582, 430, 600, 455, 606);
    ctx.lineTo(455, 700); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(514, 610); ctx.bezierCurveTo(560, 600, 640, 640, 700, 700); ctx.lineTo(514, 700); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#e4e4f2'; rr(150, 494, 360, 18, 9); ctx.fill();
    // the open door: a black gap, a few flakes blowing in
    ctx.fillStyle = '#04050a'; ctx.fillRect(460, 524, 52, 120);
    ctx.fillStyle = '#26382f'; ctx.fillRect(452, 524, 8, 120);
    ctx.fillStyle = '#c9cbe0'; ctx.beginPath(); ctx.moveTo(460, 644); ctx.lineTo(512, 644); ctx.lineTo(512, 626); ctx.bezierCurveTo(495, 618, 475, 630, 460, 640); ctx.fill();
    fog(t, 520, 700, 0.12, 9, '230,210,230', 6);
  });
  snowfall(t, 70, 61, { vy: 34, vx: -40, size: 2, a: 0.6 });
  const d = scr(486, 584, fx, fy, sc);
  lock(d.x - 34 * sc, d.y - 64 * sc, 68 * sc, 128 * sc, prog(t, cOpen, 0.4), ORANGE);
  tag('ДВЕРЬ · ОТКРЫТА', d.x, d.y - 74 * sc, { align: 'center', col: ORANGE, a: prog(t, cOpen + 0.2, 0.3), size: 15 });
  tag('СУГРОБ ≈ 1,2 М', 80, 204, { a: prog(t, cSnow + 0.3, 0.3) * (1 - walk), col: '#f1f4fb' });
  tag('СЛЕДОВ НЕТ', 80, 238, { a: prog(t, cSnow + 0.8, 0.3) * (1 - walk), col: '#ff6a4a' });
  const clk = T_REC0 + 3 + (t - s.s);
  recOverlay(t, clk, prog(t, s.s, 0.2));
  const fl = 1 - prog(t, s.s, 0.5);
  if (fl > 0) { ctx.fillStyle = `rgba(200,215,240,${0.55 * fl})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'ЗАПИСЬ', b: '15.01 · УТРО', clock: fmtClock(clk) };
}

// ---------------------------------------------------------------------
// 3. reccabin — five asleep; Igor's seat is empty, his phone is lit
// ---------------------------------------------------------------------
const IGOR = PEOPLE.find(p => p.id === 'ИГОРЬ');
function sceneRecCabin(t) {
  const id = 'reccabin', s = SC[id];
  const cWalk = cue(id, 'ИДЁТ'), cFive = cue(id, 'ПЯТЕРО'), cIg = cue(id, 'ИГОРЯ'), cPhone = cue(id, 'ТЕЛЕФОН'), c47 = cue(id, '47'), cCut = cue(id, 'ОБРЫВАЕТСЯ');
  const nm = { 'ЛЕНА': cue(id, 'ЛЕНА'), 'ФОМИЧ': cue(id, 'ФОМИЧ'), 'МАРИНА': cue(id, 'МАРИНА'), 'ГОША': cue(id, 'ГОША'), 'ТИМУР': cue(id, 'ТИМУР') };
  let fy = 170, sc = 1.75, fx = 420;
  fy = lerp(fy, 262, ease(prog(t, cWalk, 0.8))); fx = lerp(fx, 380, ease(prog(t, cWalk, 0.8)));
  fy = lerp(fy, 592, ease(prog(t, nm['ФОМИЧ'] - 0.3, 0.45)));
  fy = lerp(fy, 812, ease(prog(t, nm['МАРИНА'] - 0.3, 0.45)));
  fy = lerp(fy, 372, ease(prog(t, nm['ТИМУР'] - 0.35, 0.5)));
  const ov = ease(prog(t, cFive - 0.3, 0.6)); fy = lerp(fy, 540, ov); fx = lerp(fx, 360, ov); sc = lerp(sc, 1.08, ov);
  const zi = ease(prog(t, cIg - 0.25, 0.6)); fy = lerp(fy, 700, zi); fx = lerp(fx, 300, zi); sc = lerp(sc, 2.2, zi);
  const hx = Math.sin(t * 1.9) * 3, hy = Math.sin(t * 2.7) * 3;
  rcam(fx + hy / sc, fy - hx / sc, sc, () => {
    ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
    cabinShell(false);
    // snow blown in through the open door
    glow(495, 165, 70, 'rgba(220,230,255,0.6)');
    ctx.fillStyle = '#d8deef'; ctx.beginPath(); ctx.ellipse(490, 175, 30, 18, 0.3, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#04050a'; ctx.fillRect(520, 128, 22, 70);
    // props, but the phone gets its own treatment
    rr(472, 244, 36, 30, 5); ctx.fillStyle = '#e8ecf2'; ctx.fill(); ctx.fillStyle = '#d0342c'; ctx.fillRect(487, 250, 6, 18); ctx.fillRect(481, 256, 18, 6);
    for (const p of PEOPLE) {
      if (p.id === 'ИГОРЬ') continue;
      person(p.id === 'ТИМУР' ? Object.assign({}, p, { coat: '#59606f' }) : p, t);
    }
    // Igor's empty seat + lit phone
    const ph = 0.55 + 0.45 * Math.abs(Math.sin(t * 3.2)) * (t > cPhone ? 1 : 0.4);
    glow(292, 700, 46, `rgba(120,170,255,${0.65 * ph})`);
    rr(282, 688, 20, 30, 3); ctx.fillStyle = `rgba(157,192,255,${0.5 + 0.5 * ph})`; ctx.fill();
    for (const [n, c] of Object.entries(nm)) {
      const p = PEOPLE.find(q => q.id === n), pp = prog(t, c - 0.05, 0.35) * (1 - ease(prog(t, cIg - 0.3, 0.4))), r = 34 * p.k;
      lock(p.x - r, p.y - r + 2, r * 2, r * 2 - 6, pp, '#ffe9a8');
      const q = rlabel(p, r, sc);
      if (pp > 0) tag(n === 'ТИМУР' ? 'ТИМУР · СПИТ' : n, q.x, q.y, { a: pp, align: q.align, size: 12, col: '#ffe9a8' });
    }
    const pi = prog(t, cIg, 0.4);
    lock(IGOR.x - 36, IGOR.y - 34, 72, 66, pi, ORANGE);
    const qi = rlabel(IGOR, 36, sc);
    tag('ИГОРЬ — НЕТ', qi.x, qi.y, { a: pi, col: ORANGE, size: 12, align: qi.align });
    const p47 = prog(t, c47 - 0.05, 0.25);
    if (p47 > 0) {
      // notification badge, kept upright, in the aisle next to the seat
      ctx.save(); upright(IGOR.x + 68, IGOR.y + 4);
      ctx.globalAlpha = p47; ctx.fillStyle = 'rgba(8,10,20,0.9)'; rr(-64, -22, 128, 44, 6); ctx.fill(); ctx.strokeStyle = '#ff3b30'; ctx.lineWidth = 1.5; ctx.stroke();
      circle(-44, 0, 11); ctx.fillStyle = '#ff3b30'; ctx.fill();
      text('47', -44, 5, `800 12px ${MONO}`, '#fff', 'center');
      text('ПРОПУЩЕННЫХ', -26, 4, `700 10px ${MONO}`, '#f1f4fb', 'left');
      ctx.restore();
    }
  });
  // occupant counter
  const n = Object.values(nm).filter(c => t >= c).length;
  tag('В САЛОНЕ', 80, 204, { col: '#cdd6e8', a: prog(t, nm['ЛЕНА'], 0.2) });
  for (let i = 0; i < 6; i++) { rr(80 + i * 26, 218, 20, 20, 4); ctx.fillStyle = i < n ? '#ffe9a8' : i === 5 && t > cFive ? '#ff3b30' : 'rgba(120,134,160,0.3)'; ctx.globalAlpha = prog(t, nm['ЛЕНА'], 0.2); ctx.fill(); ctx.globalAlpha = 1; }
  if (t > nm['ЛЕНА']) text(n + ' / 6', 248, 235, `700 20px ${MONO}`, t > cFive ? '#ff6a4a' : '#e6ebf5');
  const clk = T_REC0 + 9 + (t - s.s);
  recOverlay(t, clk);
  // the recording cuts out
  const g = prog(t, cCut + 0.15, 0.6);
  glitch(t, g);
  const off = prog(t, cCut + 0.7, 0.1);
  if (off > 0) {
    ctx.fillStyle = `rgba(3,4,8,${off})`; ctx.fillRect(0, 0, W, H);
    text('КОНЕЦ ЗАПИСИ', FX, 320, `700 26px ${MONO}`, '#cdd6e8', 'center', off);
    text('01:37 / 01:37', FX, 356, `600 18px ${MONO}`, '#7f8ca6', 'center', off);
  }
  return { a: 'ЗАПИСЬ', b: 'САЛОН', clock: fmtClock(clk) };
}

// ---------------------------------------------------------------------
// 4. igor — real time: everyone looks at Igor; he laughs it off
// ---------------------------------------------------------------------
function sceneIgor(t) {
  const id = 'igor', s = SC[id];
  const cLook = cue(id, 'СМОТРЯТ'), cLaugh = cue(id, 'СМЕЁТСЯ'), cFom = cue(id, 'ФОМИЧ');
  const toF = ease(prog(t, cFom - 0.2, 0.7));
  const fx = lerp(330, 450, toF), fy = lerp(690, 600, toF), sc = lerp(1.15, 1.75, ease(prog(t, s.s, 1.4))) * (1 + 0.05 * toF);
  rcam(fx, fy, sc, () => {
    ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
    cabinShell(false); cabinProps(t);
    for (const p of PEOPLE) {
      if (p.id === 'ИГОРЬ') {
        const lx = t > cLaugh ? Math.sin(t * 28) * 2.5 * (1 - prog(t, cLaugh + 0.9, 0.4)) : 0;
        person(Object.assign({}, p, { x: p.x + lx }), t);
      } else person(p, t);
    }
    // every look lands on Igor
    const la = prog(t, cLook, 0.4) * (1 - toF * 0.7);
    if (la > 0) {
      ctx.save(); ctx.strokeStyle = `rgba(255,233,168,${0.7 * la})`; ctx.lineWidth = 1.6; ctx.setLineDash([5, 5]);
      for (const p of PEOPLE) {
        if (p.id === 'ИГОРЬ') continue;
        const e = easeOut(prog(t, cLook + 0.05 * PEOPLE.indexOf(p), 0.4));
        ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(lerp(p.x, IGOR.x, e * 0.86), lerp(p.y, IGOR.y, e * 0.86)); ctx.stroke();
      }
      ctx.restore();
    }
    lock(IGOR.x - 36, IGOR.y - 34, 72, 66, prog(t, cLook + 0.2, 0.4), ORANGE);
    const qi = rlabel(IGOR, 36, sc);
    tag('ИГОРЬ · НА МЕСТЕ', qi.x, qi.y, { a: prog(t, cLook + 0.4, 0.3) * (1 - toF), col: ORANGE, size: 12, align: qi.align });
    const F = PEOPLE.find(p => p.id === 'ФОМИЧ');
    lock(F.x - 38, F.y - 36, 76, 70, prog(t, cFom, 0.4), '#ffe9a8');
    const qf = rlabel(F, 38, sc);
    tag('ФОМИЧ', qf.x, qf.y, { a: prog(t, cFom + 0.1, 0.3), align: qf.align, size: 12, col: '#ffe9a8' });
  });
  return { a: 'ВЕЧЕР 1', b: 'САЛОН', clock: fmtClock(19 * 3600 + 37 * 60 + 2 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 5. rule — the second rule of the taiga: never answer your name at night
// ---------------------------------------------------------------------
function bubble(x, y, w, h, str, a, tailDx, tailDy, col = '#f1f4fb', bg = 'rgba(8,10,20,0.88)') {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a;
  ctx.fillStyle = bg; rr(x - w / 2, y - h / 2, w, h, 14); ctx.fill();
  ctx.beginPath(); ctx.moveTo(x + Math.sign(tailDx) * w * 0.25 - 10, y + Math.sign(tailDy) * h / 2); ctx.lineTo(x + tailDx, y + tailDy); ctx.lineTo(x + Math.sign(tailDx) * w * 0.25 + 10, y + Math.sign(tailDy) * h / 2); ctx.fill();
  ctx.strokeStyle = col; ctx.lineWidth = 1.5; rr(x - w / 2, y - h / 2, w, h, 14); ctx.stroke();
  ctx.font = '700 40px Oswald'; ctx.textAlign = 'center'; ctx.fillStyle = col; ctx.fillText(str, x, y + 14);
  ctx.restore();
}
function sceneRule(t) {
  const id = 'rule', s = SC[id];
  const cRule = cue(id, 'ВТОРОЕ'), cName = cue(id, 'ИМЕНИ'), cNo = cue(id, 'НЕ'), cAns = cue(id, 'ОТВЕЧАЙ'), cNever = cue(id, 'НИКОГДА');
  const z = ease(prog(t, s.s, s.e - s.s));
  cam(BUS.x + 80, BUS.y - 160, lerp(0.85, 0.62, z), () => drawWorld(t, { steps: 20, fogA: 0.28, lights: 0.4 }));
  ctx.fillStyle = 'rgba(3,5,14,0.5)'; ctx.fillRect(0, 0, W, H);
  snowfall(t, 60, 71, { vy: 26, vx: -16, size: 1.8, a: 0.45 });
  tag('ПРАВИЛО ТАЙГИ · № 2', FX, 140, { align: 'center', a: prog(t, cRule - 0.1, 0.25), size: 18 });
  const wh = 0.75 + 0.25 * Math.sin(t * 5);
  bubble(880, 250, 250, 74, '«ИГОРЬ…»', prog(t, cName - 0.2, 0.3) * wh, 80, -70, '#bfd4ff', 'rgba(10,16,34,0.85)');
  tag('ИЗ ЛЕСА', 970, 180, { a: prog(t, cName, 0.3), col: '#9fc0ff', size: 13 });
  const ra = prog(t, cNo - 0.2, 0.3);
  bubble(420, 410, 250, 74, '«Я ЗДЕСЬ»', ra, -70, 70, '#f1f4fb');
  const st = ease(prog(t, cAns - 0.1, 0.35));
  if (st > 0) {
    ctx.save(); ctx.strokeStyle = '#ff3b30'; ctx.lineWidth = 7; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(298, 380); ctx.lineTo(298 + 244 * st, 380 + 60 * st); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(542, 380); ctx.lineTo(542 - 244 * st, 380 + 60 * st); ctx.stroke(); ctx.restore();
  }
  const nv = prog(t, cNever, 0.25);
  if (nv > 0) {
    ctx.save(); ctx.globalAlpha = 0.5 * nv * (0.6 + 0.4 * Math.sin((t - cNever) * 6));
    const g = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820); g.addColorStop(0, 'rgba(255,40,30,0)'); g.addColorStop(1, 'rgba(255,40,30,0.5)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  return { a: 'ВЕЧЕР 1', b: 'ТАЙГА', clock: fmtClock(19 * 3600 + 38 * 60 + 10 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 6. cold — 23:40, the heater is dead, −9 inside
// ---------------------------------------------------------------------
function sceneCold(t) {
  const id = 'cold', s = SC[id], lt = t - s.s;
  const cDead = cue(id, 'ОСТЫЛА'), cMinus = cue(id, 'МИНУС');
  blueprint();
  const hx = 150, hy = 170, hw = 330, hh = 190;
  rr(hx, hy, hw, hh, 14); ctx.fillStyle = '#121a2e'; ctx.fill(); ctx.lineWidth = 2.5; ctx.strokeStyle = '#8496bb'; ctx.stroke();
  const ember = 1 - prog(t, cDead - 0.3, 0.8);
  for (let i = 0; i < 10; i++) { rr(hx + 24 + i * 29.5, hy + 22, 17, hh - 44, 6); ctx.fillStyle = `rgb(${Math.round(lerp(42, 120, ember))},${Math.round(lerp(30, 44, ember))},${Math.round(lerp(40, 30, ember))})`; ctx.fill(); }
  tag('ПЕЧКА САЛОНА · РАЗРЕЗ', hx, hy + hh + 30, { col: '#9fb2d6', plate: false, size: 13 });
  tag('НЕ РАБОТАЕТ', hx + hw / 2, hy - 18, { align: 'center', col: '#ff6a4a', a: prog(t, cDead, 0.3) });
  const tx = 590, ty = 136, th = 290, v = lerp(4, -9, ease(prog(t, s.s + 0.3, cMinus + 0.6 - s.s))), lvl = lerp(0.42, 0.18, (4 - v) / 13);
  rr(tx, ty, 22, th, 11); ctx.fillStyle = '#121a2e'; ctx.fill(); ctx.strokeStyle = '#8496bb'; ctx.lineWidth = 2; ctx.stroke();
  rr(tx + 5, ty + th * (1 - lvl), 12, th * lvl - 5, 6); ctx.fillStyle = '#7fb2ff'; ctx.fill();
  for (let i = 0; i <= 6; i++) { ctx.fillStyle = '#8496bb'; ctx.fillRect(tx - 12, ty + 10 + i * 45, 8, 2); }
  bigNum((v >= 0 ? '+' : '−') + Math.abs(Math.round(v)) + '°', tx + 12, ty - 20, 30, '#cfe2ff');
  tag('В САЛОНЕ', tx + 12, ty + th + 30, { align: 'center', col: '#9fb2d6', plate: false, size: 13 });
  const am = prog(t, cMinus - 0.1, 0.25);
  bigNum('−' + Math.abs(Math.round(v)) + '°', 950, 360, 150, '#cfe2ff', am);
  // breath in the cold air
  for (let i = 0; i < 4; i++) {
    const b = ((lt * 0.35 + i / 4) % 1);
    glow(220 + i * 280, 600 - b * 200, 40 + b * 60, `rgba(220,232,255,${0.18 * Math.sin(b * Math.PI)})`);
  }
  ctx.save(); ctx.globalAlpha = 0.45 * prog(t, cMinus, 1.2);
  const g = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820); g.addColorStop(0, 'rgba(170,205,255,0)'); g.addColorStop(1, 'rgba(190,215,255,0.6)');
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  return { a: 'НОЧЬ 1', b: 'ПЕЧКА', clock: fmtClock(23 * 3600 + 40 * 60 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 7–8. The bus door seen from inside (normal and thermal)
// ---------------------------------------------------------------------
const DOORF = { x: 170, y: 220, w: 380, h: 640 };
function doorFront(t, th, shake, frost) {
  const { x, y, w, h } = DOORF;
  ctx.save(); ctx.translate(shake, 0);
  ctx.fillStyle = th ? '#140a36' : '#121822'; ctx.fillRect(-900, -300, 2600, 1900);
  if (!th) glow(120, 1040, 380, 'rgba(255,170,80,0.22)');
  doorWalls(x, y, w, h, th);
  rr(x - 26, y - 26, w + 52, h + 70, 18); ctx.fillStyle = th ? '#251560' : '#1e2836'; ctx.fill();
  for (let k = 0; k < 2; k++) {
    const px = x + k * (w / 2), pw = w / 2 - 6;
    rr(px + 3, y, pw, h, 10); ctx.fillStyle = th ? '#2c1a72' : '#2a3a33'; ctx.fill();
    for (let j = 0; j < 2; j++) {
      const gx = px + 22, gy = y + 24 + j * (h / 2 - 6), gw = pw - 38, gh = h / 2 - 48;
      rr(gx, gy, gw, gh, 8);
      if (th) ctx.fillStyle = '#07031a';
      else ctx.fillStyle = vgrad(gy, gy + gh, [[0, '#0b1124'], [1, '#18243e']]);
      ctx.fill();
      if (!th) {
        ctx.save(); rr(gx, gy, gw, gh, 8); ctx.clip();
        glow(gx + gw * 0.6, gy + gh * 0.5, 160, 'rgba(150,170,220,0.18)');
        ctx.globalAlpha = frost; ctx.strokeStyle = 'rgba(225,238,255,0.55)'; ctx.lineWidth = 1.2;
        const r = rng(300 + k * 10 + j);
        for (let c = 0; c < 26; c++) {
          const cx = gx + (r() < 0.5 ? r() * 40 : gw - r() * 40), cy = gy + r() * gh, L = 10 + r() * 30, rot = r() * 6.28;
          for (let q = 0; q < 6; q++) { const a = rot + q * 1.047; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * L, cy + Math.sin(a) * L); ctx.stroke(); }
        }
        ctx.restore();
      }
    }
    // rubber seal and handle
    ctx.fillStyle = th ? '#1d1050' : '#141c18'; ctx.fillRect(px + (k ? 0 : pw - 2), y + 4, 8, h - 8);
  }
  ctx.fillStyle = th ? '#3a2490' : '#8b95a8'; rr(x + w / 2 - 50, y + h * 0.48, 16, 120, 8); ctx.fill(); rr(x + w / 2 + 34, y + h * 0.48, 16, 120, 8); ctx.fill();
  // step
  ctx.fillStyle = th ? '#1a0e4a' : '#0b0f15'; ctx.fillRect(x - 40, y + h + 26, w + 80, 70);
  ctx.restore();
}
// the cabin wall either side of the door: handrails, a frosted side window, the first seats
function doorWalls(x, y, w, h, th) {
  for (const sx of [-1, 1]) {
    const cx = x + w / 2 + sx * (w / 2 + 150);
    ctx.fillStyle = th ? '#1a0f48' : '#19212d'; rr(cx - 110, y - 10, 220, 380, 14); ctx.fill();
    if (!th) { ctx.save(); rr(cx - 92, y + 8, 184, 340, 10); ctx.clip(); ctx.fillStyle = vgrad(y, y + 350, [[0, '#0b1124'], [1, '#18243e']]); ctx.fillRect(cx - 92, y + 8, 184, 340); glow(cx, y + 200, 160, 'rgba(150,170,220,0.15)'); ctx.restore(); }
    ctx.fillStyle = th ? '#2a1a70' : '#8b95a8'; rr(cx - sx * 140 - 6, y - 20, 12, h + 60, 6); ctx.fill();
    ctx.fillStyle = th ? '#241560' : '#3a2c22'; rr(cx - 120, y + h - 210, 240, 150, 18); ctx.fill();
    ctx.fillStyle = th ? '#1d1050' : '#2c2119'; rr(cx - 120, y + h - 90, 240, 40, 12); ctx.fill();
  }
}
function handprint(x, y, s, a, col = '#6ee1ff') {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha = a; ctx.translate(x, y); ctx.scale(s, s);
  glow(0, 0, 90, 'rgba(60,170,255,0.35)');
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(0, 18, 32, 38, 0, 0, 6.28); ctx.fill();
  [[-30, -18, -0.5, 30], [-14, -40, -0.15, 42], [3, -46, 0, 46], [19, -40, 0.15, 40], [34, -6, 0.7, 30]].forEach(([fx, fy, r, L]) => {
    ctx.save(); ctx.translate(fx, fy); ctx.rotate(r); rr(-7, -L / 2, 14, L, 7); ctx.fill(); ctx.restore();
  });
  ctx.restore();
}
function sceneKnock(t) {
  const id = 'knock', s = SC[id];
  const cK = cue(id, 'СТУК'), cVoice = cue(id, 'ВОДИТЕЛЯ:'), cQ0 = cue(id, '«ИГОРЬ'), cQ1 = cue(id, 'Я»'), cKnew = cue(id, 'ЗНАЛ'), cAsk = cue(id, 'СПРАШИВАЛ');
  const knocks = [cK - 0.05, cK + 0.38, cK + 0.8];
  let shake = 0; knocks.forEach(k => { if (t > k) shake += Math.sin((t - k) * 70) * 7 * Math.exp(-(t - k) * 9); });
  const z = 0.78 * (1 + 0.06 * prog(t, s.s, s.e - s.s));
  cam(360, 560, z, () => {
    doorFront(t, false, shake, 1);
    knocks.forEach((k, i) => {
      const p = prog(t, k, 0.7);
      if (p > 0 && p < 1) { ctx.strokeStyle = `rgba(255,233,168,${0.8 * (1 - p)})`; ctx.lineWidth = 3; circle(372, 470, 20 + p * 160); ctx.stroke(); }
    });
    // snow shaken from the frame
    knocks.forEach((k, i) => {
      const p = prog(t, k, 1.1); if (p <= 0 || p >= 1) return;
      const r = rng(50 + i);
      for (let q = 0; q < 14; q++) { ctx.fillStyle = `rgba(230,236,250,${0.8 * (1 - p)})`; circle(180 + r() * 360, 210 + p * p * 260 * (0.5 + r()), 2 + r() * 2); ctx.fill(); }
    });
  });
  const nK = knocks.filter(k => t > k).length;
  if (nK > 0) tag('УДАР ' + nK + ' / 3', 250, 200, { align: 'center', col: ORANGE, a: 1 - prog(t, cVoice - 0.3, 0.3), size: 17 });
  const va = prog(t, cVoice, 0.25) * (1 - prog(t, cQ1 + 0.6, 0.3));
  if (va > 0) {
    tag('ГОЛОС ЗА ДВЕРЬЮ', 250, 200, { align: 'center', col: '#ffe9a8', a: va, size: 16 });
    waveform(t, 100, 256, 300, 60, va * (t > cQ0 - 0.1 && t < cQ1 + 0.4 ? 1 : 0.25));
    tag('СОВПАДЕНИЕ: ВОДИТЕЛЬ', 250, 326, { align: 'center', col: '#cdd6e8', a: va * prog(t, cQ0, 0.3), size: 13 });
  }
  const rows = [['ВОДИТЕЛЬ СПРАШИВАЛ ИМЕНА', 'НЕТ', cKnew], ['ИМЕНА НА БИЛЕТАХ', 'НЕТ', cAsk], ['ОТКУДА «ИГОРЬ»?', '?', cAsk + 0.7]];
  rows.forEach(([l, v, c], i) => {
    const a = prog(t, c, 0.25);
    tag(l, 850, 200 + i * 40, { a, col: '#cdd6e8', size: 15 });
    tag(v, 1224, 200 + i * 40, { a, col: '#ff6a4a', align: 'right', size: 15 });
  });
  return { a: 'НОЧЬ 1', b: 'ДВЕРЬ', clock: fmtClock(23 * 3600 + 41 * 60 + 5 + (t - s.s)) };
}
function sceneThermDoor(t) {
  const id = 'thermdoor', s = SC[id];
  const cNone = cue(id, 'НИКОГО'), cWarm = cue(id, 'ТЁПЛОГО'), cGlass = cue(id, 'СТЕКЛА:'), cQ0 = cue(id, '«ИГОРЬ'), cQ1 = cue(id, 'УЗНАЛ»');
  const on = ease(prog(t, s.s + 0.2, 0.5));
  const toHand = ease(prog(t, cGlass - 0.1, 0.9));
  cam(lerp(360, 452, toHand), lerp(560, 460, toHand), lerp(0.78, 1.5, toHand), () => {
    doorFront(t, true, 0, 0);
    // two warm people at the bottom edge (Igor and Lena behind the camera)
    glow(30, 1010, 170, 'rgba(255,112,20,0.85)'); glow(30, 1010, 72, 'rgba(255,236,170,0.9)');
    glow(700, 1030, 160, 'rgba(255,112,20,0.75)'); glow(700, 1030, 62, 'rgba(255,236,170,0.8)');
    // scanning beam across the glass
    const sp = prog(t, s.s + 0.6, cNone - s.s - 0.4);
    if (sp > 0 && sp < 1) { ctx.fillStyle = 'rgba(160,140,255,0.35)'; ctx.fillRect(DOORF.x + 20, DOORF.y + sp * DOORF.h, DOORF.w - 40, 3); }
    // the cold hand on the glass
    const ha = prog(t, cGlass - 0.1, 0.5) * (0.85 + 0.15 * Math.sin(t * 4));
    handprint(452, 448, 1.1, ha);
    if (t > cQ0) { const pr = ((t - cQ0) * 0.9) % 1; ctx.strokeStyle = `rgba(110,225,255,${0.6 * (1 - pr)})`; ctx.lineWidth = 2; circle(452, 448, 60 + pr * 120); ctx.stroke(); }
  });
  tag('ЗА ДВЕРЬЮ · ТЁПЛЫХ ОБЪЕКТОВ', LM, TY + 40, { col: '#cdd6e8', a: prog(t, cNone - 0.1, 0.25) * (1 - toHand) });
  bigNum('0', 400, TY + 56, 46, '#ff6a4a', prog(t, cNone, 0.25) * (1 - toHand), 'left');
  tag('МИН. ТЕМПЕРАТУРА ЗА ДВЕРЬЮ: −43°', LM, TY + 84, { col: '#9f8cf0', a: prog(t, cWarm, 0.25) * (1 - toHand), size: 13 });
  const ha = prog(t, cGlass + 0.3, 0.3);
  if (ha > 0) {
    lock(550, 222, 180, 220, ha, '#6ee1ff');
    tag('ЛАДОНЬ · −61°', FX, 208, { align: 'center', col: '#6ee1ff', a: ha, size: 16 });
    tag('С ТОЙ СТОРОНЫ', FX, 476, { align: 'center', col: '#cdd6e8', a: ha, size: 13 });
  }
  const va = prog(t, cQ0 - 0.1, 0.2) * (1 - prog(t, cQ1 + 0.5, 0.3));
  waveform(t, 860, 330, 300, 60, va, '#6ee1ff');
  // imager UI
  ctx.fillStyle = Math.sin(t * 5) > 0 ? '#ff3b30' : '#7a1a15'; circle(FX - 62, 61, 5); ctx.fill();
  text('ТЕПЛОВИЗОР', FX - 48, 67, `600 16px ${MONO}`, '#cdd6e8');
  const g = ctx.createLinearGradient(0, 150, 0, 490);
  [[0, '#fff3c0'], [0.25, '#ff8a1f'], [0.5, '#be28aa'], [0.75, '#3b2a86'], [1, '#02010a']].forEach(([p, c]) => g.addColorStop(p, c));
  ctx.fillStyle = g; rr(1240, 150, 8, 340, 4); ctx.fill();
  ctx.fillStyle = 'rgba(10,6,30,0.16)'; for (let y = 0; y < H; y += 4) ctx.fillRect(0, y, W, 1);
  if (on < 1) { ctx.fillStyle = `rgba(3,2,10,${1 - on})`; ctx.fillRect(0, 0, W, H); ctx.fillStyle = `rgba(190,160,255,${0.6 * (1 - on)})`; ctx.fillRect(0, H * on * 0.7, W, 3); }
  return { a: 'НОЧЬ 1', b: 'ТЕПЛОВИЗОР', clock: fmtClock(23 * 3600 + 41 * 60 + 40 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 9. final — Igor gets up, Lena grabs his arm, he opens his mouth to answer
// ---------------------------------------------------------------------
function sceneFinal(t) {
  const id = 'final', s = SC[id];
  const cUp = cue(id, 'ВСТАЁТ'), cHand = cue(id, 'РУКУ'), cDoor = cue(id, 'ДВЕРЬ'), cMouth = cue(id, 'ОТКРЫВАЕТ'), cAns = cue(id, 'ОТВЕТИТЬ');
  const tf = Math.min(t, cAns + 0.25);                     // everything freezes on the last word
  const p1 = ease(prog(tf, cUp - 0.1, 0.6)), p2 = ease(prog(tf, cUp + 0.5, cHand - cUp - 0.3));
  let ix = lerp(IGOR.x, 360, p1), iy = lerp(IGOR.y, 690, p1);
  iy = lerp(iy, 318, p2);
  const pull = ease(prog(tf, cHand + 0.05, 0.3));            // Lena's grip stops him
  const L = PEOPLE.find(p => p.id === 'ЛЕНА');
  let fx = lerp(360, ix, ease(prog(tf, cUp, 0.8))), fy = lerp(540, iy, ease(prog(tf, cUp, 0.8))), sc = lerp(1.1, 1.5, ease(prog(tf, cUp, 0.8)));
  const d = ease(prog(tf, cDoor - 0.2, 0.7)); fx = lerp(fx, 440, d); fy = lerp(fy, 220, d); sc = lerp(sc, 1.9, d);
  const m = ease(prog(tf, cMouth - 0.1, cAns - cMouth + 0.3)); fx = lerp(fx, ix, m); fy = lerp(fy, iy - 6, m); sc = lerp(sc, 4.2, m);
  const shake = t > cAns ? 0 : Math.sin(tf * 37) * 1.2 * m;
  rcam(fx + shake, fy, sc, () => {
    ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
    cabinShell(false); cabinProps(tf);
    for (const p of PEOPLE) if (p.id !== 'ИГОРЬ') person(p, tf);
    // the door well: cold light through the glass
    glow(495, 165, 80, `rgba(110,200,255,${0.25 + 0.2 * Math.sin(tf * 3)})`);
    lock(468, 118, 56, 92, prog(tf, cDoor, 0.4), '#6ee1ff');
    tag('ДВЕРЬ', 496, 108, { align: 'center', col: '#6ee1ff', a: prog(tf, cDoor + 0.1, 0.3), size: 11 });
    // Lena's arm
    if (pull > 0) {
      ctx.save(); ctx.strokeStyle = L.coat; ctx.lineCap = 'round'; ctx.lineWidth = 11;
      ctx.beginPath(); ctx.moveTo(L.x - 18, L.y + 4); ctx.lineTo(lerp(L.x - 18, ix + 14, pull), lerp(L.y + 4, iy + 6, pull)); ctx.stroke();
      ctx.fillStyle = '#e0b48c'; circle(lerp(L.x - 18, ix + 14, pull), lerp(L.y + 4, iy + 6, pull), 6.5); ctx.fill(); ctx.restore();
    }
    // Igor standing (slightly bigger: he is upright), turning towards the door
    person(Object.assign({}, IGOR, { x: ix, y: iy, k: 1.05 + 0.15 * p1 }), tf);
    lock(ix - 40, iy - 38, 80, 74, prog(tf, cUp, 0.4) * (1 - m), ORANGE);
    if (m > 0.4) {
      // the mouth, opening
      const o = ease(prog(tf, cMouth + 0.3, cAns - cMouth));
      ctx.fillStyle = '#05060a'; ctx.beginPath(); ctx.ellipse(ix, iy - 14, 4.2, 0.6 + 3.2 * o, 0, 0, 6.28); ctx.fill();
    }
  });
  if (t > cAns) {
    // freeze-frame: desaturate, red pulse, frozen clock
    const f = prog(t, cAns, 0.25);
    ctx.fillStyle = `rgba(120,10,10,${0.18 * f})`; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = `rgba(0,0,0,${0.25 * f})`; ctx.fillRect(0, 0, W, H);
    bracket(60, 100, 1160, 470, '#ff3b30', f, 40, 3);
  }
  return { a: 'НОЧЬ 1', b: 'ДВЕРЬ', clock: fmtClock(23 * 3600 + 42 * 60 + 10 + (tf - s.s)) };
}
