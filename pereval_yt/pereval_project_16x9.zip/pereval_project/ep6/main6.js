// Season finale card (the only full end card in the YouTube cut)
function endCard(t) {
  const lt = t - TL.voice_end;
  ctx.fillStyle = '#04050a'; ctx.fillRect(0, 0, W, H);
  if (lt < 0.5) return;
  const a = ease(prog(lt, 0.5, 0.7));
  glow(FX, 300, 520, `rgba(60,90,170,${0.22 * a})`);
  snowfall(t, 60, 7, { vy: 22, vx: -10, size: 1.6, a: 0.35 * a });
  ctx.save(); ctx.globalAlpha = a; ctx.textAlign = 'center';
  ctx.font = '700 140px Oswald'; ctx.shadowColor = 'rgba(160,190,255,0.5)'; ctx.shadowBlur = 30; ctx.fillStyle = '#f4f6fb'; ctx.fillText('ПЕРЕВАЛ', FX, 300);
  ctx.shadowBlur = 0; ctx.restore();
  text('КОНЕЦ ПЕРВОГО СЕЗОНА', FX, 356, `600 24px ${MONO}`, AMBER, 'center', a);
  const b = ease(prog(lt, 1.9, 0.6));
  ctx.save(); ctx.globalAlpha = b; ctx.textAlign = 'center'; ctx.font = '700 58px Oswald'; ctx.fillStyle = ORANGE; ctx.shadowColor = 'rgba(255,120,20,0.45)'; ctx.shadowBlur = 20; ctx.fillText('ЧЕРЕЗ ПЯТЬ ЛЕТ…', FX, 478); ctx.restore();
  const c = ease(prog(lt, 2.8, 0.5));
  if (c > 0) {
    if (Math.sin(lt * 6) > -0.2) { ctx.save(); ctx.globalAlpha = c; circle(FX - 128, 515, 6); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore(); }
    text('REC_0047 · 15.01.31', FX + 8, 522, `600 18px ${MONO}`, '#8a96b0', 'center', c);
  }
  const out = prog(lt, END_CARD - 0.8, 0.8);
  if (out > 0) { ctx.fillStyle = `rgba(4,5,10,${out})`; ctx.fillRect(0, 0, W, H); }
}

const SCENES = { hand: sceneHand, confess: sceneConfess, spring: sceneSpring, understand: sceneUnderstand, leave: sceneLeave, engine: sceneEngine, last: sceneLast };
const END_CARD = 6.5;
const DURATION = TL.voice_end + END_CARD;
function render(t) {
  ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
  ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
  if (t >= TL.voice_end) { endCard(t); post(t, 0); return; }
  const s = TL.scenes.find(x => t < x.e) || TL.scenes[TL.scenes.length - 1];
  ctx.save();
  const hud = SCENES[s.id](t);
  ctx.restore();
  post(t, 1);
  drawHUD(hud.a, hud.b, hud.clock, hud.note);
  drawCaptions(t);
  const cut = 1 - prog(t, s.s, s.id === 'hand' ? 0.6 : 0.12);
  if (cut > 0) { ctx.fillStyle = `rgba(3,4,9,${cut})`; ctx.fillRect(0, 0, W, H); }
}
