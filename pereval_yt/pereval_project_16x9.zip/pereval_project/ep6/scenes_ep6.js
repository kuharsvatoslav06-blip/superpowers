// =====================================================================
// Episode 6 — «Седьмое место». Builds on helpers from episodes 1–5.
// =====================================================================
function sepia(a = 0.65) {
  ctx.save(); ctx.globalCompositeOperation = 'color'; ctx.globalAlpha = a; ctx.fillStyle = '#a07850'; ctx.fillRect(0, 0, W, H); ctx.restore();
  ctx.save(); ctx.fillStyle = 'rgba(40,24,10,0.18)'; ctx.fillRect(0, 0, W, H); ctx.restore();
}
function vhs(t, label) {
  ctx.fillStyle = 'rgba(0,0,0,0.16)'; for (let y = 0; y < H; y += 3) ctx.fillRect(0, y, W, 1);
  const r = rng(Math.floor(t * 8)); const y = (t * 140) % H;
  ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.fillRect(0, y, W, 6 + r() * 10);
  text('▶ PLAY', 80, 146, `700 22px ${MONO}`, '#f1f4fb');
  text(label, 1200, 146, `600 18px ${MONO}`, '#f1f4fb', 'right');
}

// ---------------------------------------------------------------------
// 1. hand — Igor can't see it, but feels the cold on his shoulder and hears the driver
// ---------------------------------------------------------------------
function sceneHand(t) {
  const id = 'hand', s = SC[id];
  const cCold = cue(id, 'ХОЛОД'), cW = cue(id, 'ШЁПОТ'), cQ = cue(id, '«ТЫ'), cQ1 = cue(id, 'ИГОРЬ»', 1);
  const z = 2.4 + 0.5 * ease(prog(t, s.s, s.e - s.s));
  rcam(IGOR4.x + 10, IGOR4.y, z, () => {
    cabinView(t, { dawn: true });
    // a shimmer where the thermal camera saw the seventh
    const sh = 0.12 + 0.06 * Math.sin(t * 7);
    glow(SEVENTH.x, SEVENTH.y, 60, `rgba(150,220,255,${sh})`);
    // frost creeping over his shoulder
    const fr = ease(prog(t, cCold - 0.2, 1.6));
    if (fr > 0) {
      ctx.save(); ctx.strokeStyle = 'rgba(235,245,255,0.9)'; ctx.lineWidth = 0.8; const r = rng(12);
      for (let i = 0; i < 26; i++) {
        const a0 = r() * 6.28, cx = IGOR4.x + 14 + Math.cos(a0) * 10 * fr, cy = IGOR4.y + 6 + Math.sin(a0) * 7 * fr, L = (3 + r() * 8) * fr;
        for (let q = 0; q < 6; q++) { const a = q * 1.047 + r(); ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * L, cy + Math.sin(a) * L); ctx.stroke(); }
      }
      ctx.restore();
      glow(IGOR4.x + 14, IGOR4.y + 6, 22 * fr, 'rgba(180,230,255,0.5)');
    }
  });
  tag('ПЛЕЧО · −12°', 1040, 250, { align: 'center', col: '#6ee1ff', a: prog(t, cCold + 0.3, 0.3), size: 16 });
  const wa = prog(t, cW - 0.1, 0.2) * (1 - prog(t, cQ1 + 0.6, 0.3));
  if (wa > 0) { tag('ШЁПОТ · ГОЛОС ВОДИТЕЛЯ', 250, 200, { align: 'center', col: '#bfd4ff', a: wa, size: 15 }); waveform(t, 100, 256, 300, 46, wa * (t > cQ - 0.1 && t < cQ1 + 0.4 ? 1 : 0.3), '#bfd4ff'); }
  const fl = 1 - prog(t, s.s, 0.5); if (fl > 0) { ctx.fillStyle = `rgba(3,4,9,${fl})`; ctx.fillRect(0, 0, W, H); }
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 19 * 60 + 52 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 2. confess — five years ago: his bus, this pass, six passengers, he walked away
// ---------------------------------------------------------------------
function sceneConfess(t) {
  const id = 'confess', s = SC[id];
  const c5 = cue(id, '5'), cStall = cue(id, 'ЗАГЛОХ'), cLeft = cue(id, 'УШЁЛ'), cNot = cue(id, 'НЕ'), c6 = cue(id, 'ШЕСТЕРО');
  const flash = ease(prog(t, c5 - 0.2, 0.4));
  if (flash < 1) {
    // present: Igor lowering his head
    rcam(IGOR4.x + 10, IGOR4.y, 2.9, () => cabinView(t, { dawn: true }));
  }
  if (flash > 0) {
    ctx.save(); ctx.globalAlpha = flash;
    const lights = t < cStall ? 1 : lerp(1, 0.25, prog(t, cStall, 0.8));
    cam(360, 520, 1.2, () => {
      ctx.fillStyle = vgrad(0, 620, [[0, '#070b1a'], [0.6, '#131d3a'], [1, '#2a3962']]); ctx.fillRect(-400, -60, W + 800, 700);
      const r = rng(11);
      for (let x = -300; x < 1100; x += 34) spruce(x + r() * 20, 566, 110 + r() * 110, '#17223f');
      for (let x = -300; x < 1100; x += 62) spruce(x + r() * 34, 590, 200 + r() * 150, '#0b1227', 'rgba(110,134,190,0.35)');
      ctx.fillStyle = vgrad(575, 1300, [[0, '#3c5083'], [0.25, '#26355d'], [1, '#0d1326']]); ctx.fillRect(-400, 575, W + 800, 760);
      busSide(300, 668, lights);
      // the driver walks away into the dark
      const wk = ease(prog(t, cLeft - 0.2, cNot + 0.6 - cLeft));
      if (t > cLeft - 0.3) { const x = lerp(520, 860, wk); glow(x + 12, 610, 60, `rgba(255,200,120,${0.5 * (1 - wk)})`); shadowMan(x, 668, 1.0, 1 - prog(t, cNot + 0.3, 0.6)); }
      // the six passengers, counted
      [[-150, 0], [-84, 3], [-30, -2], [34, 2], [88, 0], [98, 12]].forEach(([dx, dy], i) => {
        const a = prog(t, c6 + i * 0.12, 0.15); if (a <= 0) return;
        ctx.save(); ctx.globalAlpha = a; circle(300 + dx, 668 - 160, 11); ctx.fillStyle = '#f1f4fb'; ctx.fill(); ctx.restore();
        text(String(i + 1), 300 + dx, 668 - 155, `800 13px ${MONO}`, '#10131f', 'center', a);
      });
      fog(t, 560, 700, 0.18, 5);
    });
    snowfall(t, 120, 21, { vy: 60, vx: -30 });
    sepia();
    vhs(t, '5 ЛЕТ НАЗАД');
    tag('ВОДИТЕЛЬ · ИГОРЬ', FX, 210, { align: 'center', col: ORANGE, a: prog(t, c5 + 0.4, 0.3) * (1 - prog(t, cLeft, 0.3)), size: 16 });
    tag('УШЁЛ ЗА ПОМОЩЬЮ', W - LM, 210, { align: 'right', col: '#f1f4fb', a: prog(t, cLeft + 0.2, 0.3) * (1 - prog(t, c6, 0.3)), size: 15 });
    tag('НЕ ВЕРНУЛСЯ', W - LM, 246, { align: 'right', col: '#ff6a4a', a: prog(t, cNot, 0.3) * (1 - prog(t, c6, 0.3)), size: 15 });
    ctx.restore();
  }
  const wf = pulse(t, c5 - 0.2, 0.4); if (wf > 0) { ctx.fillStyle = `rgba(240,230,210,${0.7 * wf})`; ctx.fillRect(0, 0, W, H); }
  return { a: flash > 0.5 ? '5 ЛЕТ НАЗАД' : 'УТРО 2', b: flash > 0.5 ? 'ПЕРЕВАЛ' : 'САЛОН', clock: fmtClock(flash > 0.5 ? 18 * 3600 + 2 * 60 + (t - s.s) * 30 : 6 * 3600 + 20 * 60 + 10 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 3. spring — found in spring: six in their seats; the seventh seat, the driver's, empty
// ---------------------------------------------------------------------
const OLD6 = [[230, 262], [428, 372], [292, 482], [490, 592], [230, 702], [428, 812]];
function sceneSpring(t) {
  const id = 'spring', s = SC[id];
  const cSpr = cue(id, 'ВЕСНОЙ'), cSeats = cue(id, 'СВОИХ'), c7 = cue(id, 'СЕДЬМОЕ'), cDrv = cue(id, 'ВОДИТЕЛЯ');
  const zi = ease(prog(t, c7 - 0.3, 0.9));
  rcam(lerp(360, 250, zi), lerp(540, 200, zi), lerp(1.08, 2.2, zi), () => {
    ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
    cabinShell(false);
    glow(360, 500, 600, 'rgba(255,230,180,0.12)');
    OLD6.forEach(([x, y], i) => {
      person({ id: 'O' + i, x, y, coat: ['#6a6a6a', '#5b5f66', '#77706a', '#626a70', '#6e6660', '#585858'][i], head: '#4a4542', k: 0.95 }, 0);
      const a = prog(t, cSeats - 0.1 + i * 0.12, 0.2);
      if (a > 0) { ctx.save(); ctx.globalAlpha = a * (1 - zi); circle(x, y - 44, 15); ctx.fillStyle = '#f1f4fb'; ctx.fill(); ctx.restore(); text(String(i + 1), x, y - 37, `800 18px ${MONO}`, '#10131f', 'center', a * (1 - zi)); }
    });
    const a7 = prog(t, c7, 0.3);
    lock(212, 152, 76, 84, a7, '#ff3b30');
    if (a7 > 0) { ctx.save(); ctx.globalAlpha = a7; circle(250, 120, 15); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore(); text('7', 250, 127, `800 18px ${MONO}`, '#fff', 'center', a7); }
  });
  sepia(0.55);
  vhs(t, 'АРХИВ · АПРЕЛЬ');
  tag('НАЙДЕНЫ ВЕСНОЙ', FX, 192, { align: 'center', col: '#f1f4fb', a: prog(t, cSpr, 0.3) * (1 - zi), size: 16 });
  tag('МЕСТО ВОДИТЕЛЯ · ПУСТО', FX, 192, { align: 'center', col: '#ff6a4a', a: prog(t, cDrv, 0.3), size: 16 });
  return { a: 'АРХИВ', b: 'АПРЕЛЬ', clock: fmtClock(12 * 3600 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 4. understand — the forest wasn't waiting for them. It was waiting for him.
// ---------------------------------------------------------------------
function sceneUnderstand(t) {
  const id = 'understand', s = SC[id];
  const cNot = cue(id, 'ИХ'), cHim = cue(id, 'ЕГО');
  cam(420, 620, 0.7 + 0.07 * prog(t, s.s, s.e - s.s), () => {
    drawWorld(t, { steps: 0, fogA: 0.35, lights: 0.3 });
    ctx.fillStyle = 'rgba(3,5,14,0.4)'; ctx.fillRect(-900, -1100, 2600, 3600);
    // six pale marks: the old passengers
    const g6 = prog(t, s.s + 0.6, 0.6) * (1 - 0.6 * prog(t, cNot + 0.2, 0.4));
    [[220, 700], [280, 740], [220, 800], [280, 850], [220, 900], [280, 950]].forEach(([x, y]) => { ctx.strokeStyle = `rgba(220,225,240,${0.7 * g6})`; ctx.lineWidth = 2; circle(x, y, 13); ctx.stroke(); });
    // the empty seventh place out in the fog
    ctx.save(); ctx.setLineDash([6, 6]); ctx.strokeStyle = `rgba(255,59,48,${0.5 + 0.4 * Math.sin(t * 4)})`; ctx.lineWidth = 3; circle(END.x, END.y, 26); ctx.stroke(); ctx.restore();
    text('7', END.x, END.y + 9, `800 24px ${MONO}`, '#ff6a4a', 'center', 0.9);
    const hm = prog(t, cHim - 0.1, 0.3);
    if (hm > 0) {
      const ix = 290, iy = 700; glow(ix, iy, 40, `rgba(255,138,31,${0.6 * hm})`); circle(ix, iy, 13); ctx.fillStyle = ORANGE; ctx.globalAlpha = hm; ctx.fill(); ctx.globalAlpha = 1;
      const p = ease(prog(t, cHim + 0.2, 1.2));
      ctx.save(); ctx.setLineDash([10, 8]); ctx.lineDashOffset = -t * 30; ctx.strokeStyle = `rgba(255,138,31,${hm})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(ix, iy); ctx.lineTo(lerp(ix, END.x, p), lerp(iy, END.y, p)); ctx.stroke(); ctx.restore();
    }
  });
  tag('ШЕСТЕРО · ТЕ, КТО ОСТАЛСЯ', LM, TY, { col: '#cdd6e8', a: prog(t, s.s + 0.6, 0.3) * (1 - prog(t, cHim, 0.3)), size: 15 });
  tag('МЕСТО № 7 · ИГОРЬ', LM, TY, { col: ORANGE, a: prog(t, cHim + 0.2, 0.3), size: 15 });
  return { a: 'УТРО 2', b: 'ТАЙГА', clock: fmtClock(6 * 3600 + 21 * 60 + 5 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 5. leave — Igor removes Lena's hand, opens the door and walks into the fog. Twenty steps.
// ---------------------------------------------------------------------
function sceneLeave(t) {
  const id = 'leave', s = SC[id];
  const cHand = cue(id, 'СНИМАЕТ'), cDoor = cue(id, 'ДВЕРЬ'), cSelf = cue(id, 'САМ'), c20 = cue(id, '20');
  if (t < cDoor - 0.1) {
    const arm = 1 - ease(prog(t, cHand + 0.2, 0.8));
    rcam(380, 320, 2.6, () => cabinView(t, { dawn: true, igor: { x: 360, y: 318, k: 1.2 }, arm }));
    tag('ИГОРЬ · ВСТАЛ', LM, TY, { col: ORANGE, a: prog(t, s.s + 0.3, 0.3) });
    return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 22 * 60 + 2 + (t - s.s)) };
  }
  const wp = prog(t, cDoor + 0.2, c20 + 0.6 - cDoor - 0.2);
  const q = pathAt(ease(wp));
  const fx = lerp(DOOR.x + 40, q.x, ease(prog(t, cDoor, 0.8))), fy = lerp(DOOR.y, q.y, ease(prog(t, cDoor, 0.8)));
  cam(fx, fy, 1.7, () => {
    drawWorld(t, { steps: 0, fogA: 0.3, lights: 0, door: 1 });
    for (let i = 0; i < Math.min(20, Math.floor(wp * 20.5)); i++) footprint(STEPS[i], 1, '#18233f');
    driverTop(q, 1 - prog(wp, 0.85, 0.15), 0);
  });
  fog(t, 80, 520, 0.05 + 0.12 * wp, 13);
  snowfall(t, 60, 41, { vy: 30, vx: -22, size: 2, a: 0.5 });
  const n = Math.min(20, Math.floor(wp * 20.5));
  bigNum(String(n), 250, 300, 104, n >= 20 ? ORANGE : '#f1f4fb');
  tag('ШАГОВ', 250, 342, { align: 'center' });
  tag('САМ', W - 120, 300, { align: 'right', col: ORANGE, a: prog(t, cSelf, 0.3), size: 18 });
  return { a: 'УТРО 2', b: 'ИГОРЬ', clock: fmtClock(6 * 3600 + 22 * 60 + 20 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 6. engine — the engine starts by itself, the fog lifts, Gosha is warm again
// ---------------------------------------------------------------------
function sceneEngine(t) {
  const id = 'engine', s = SC[id];
  const cStart = cue(id, 'ЗАВОДИТСЯ'), cFog = cue(id, 'УХОДИТ'), cRoad = cue(id, 'ДОРОГА'), cG = cue(id, 'ГОША'), cWarm = cue(id, 'ТЁПЛЫЙ'), c36 = cue(id, '+36,6°');
  if (t < cG - 0.15) {
    const lights = lerp(0.2, 1, ease(prog(t, cStart, 0.6))) * (t > cStart && t < cStart + 0.7 ? (Math.sin(t * 40) > -0.3 ? 1 : 0.4) : 1);
    const sh = t > cStart && t < cStart + 1.2 ? Math.sin(t * 60) * 2 : 0;
    const clear = ease(prog(t, cFog - 0.2, 1.6));
    cam(345, 530, 1.15, () => {
      ctx.fillStyle = vgrad(0, 620, [[0, '#1a2346'], [0.6, lerp(0, 1, clear) > 0.5 ? '#6a6a96' : '#3a4670'], [1, '#e2a07c']]); ctx.fillRect(-400, -60, W + 800, 700);
      glow(-20, 575, 360, `rgba(255,190,140,${0.25 + 0.3 * clear})`);
      const r = rng(11);
      for (let x = -300; x < 1100; x += 34) spruce(x + r() * 20, 566, 110 + r() * 110, '#2a2c4a');
      ctx.fillStyle = vgrad(575, 1300, [[0, '#b9b9d6'], [0.3, '#8d93b8'], [1, '#3a4166']]); ctx.fillRect(-400, 575, W + 800, 760);
      busSide(300 + sh, 668, lights);
      fog(t, 480, 720, 0.35 * (1 - clear), 5, '220,224,240', 9);
    });
    const ra = prog(t, cRoad - 0.1, 0.3);
    if (ra > 0) {
      const p = easeOut(prog(t, cRoad, 0.9));
      ctx.save(); ctx.globalAlpha = ra; ctx.strokeStyle = 'rgba(241,244,251,0.85)'; ctx.lineWidth = 2; ctx.setLineDash([9, 8]);
      ctx.beginPath(); ctx.moveTo(300, 214); ctx.lineTo(300 + 680 * p, 214); ctx.stroke(); ctx.setLineDash([]);
      circle(300, 214, 7); ctx.fillStyle = ORANGE; ctx.fill(); ctx.restore();
      tag('АВТОБУС', 300, 258, { align: 'center', a: ra, col: ORANGE }); tag('ПЕРЕВАЛ · 9 КМ', 980, 258, { align: 'center', a: ra * prog(p, 0.9, 0.1), col: '#f1f4fb' });
    }
    tag('ДВИГАТЕЛЬ · ' + (t > cStart ? 'ЗАПУЩЕН' : 'СТОП'), FX, 150, { align: 'center', col: t > cStart ? '#7fe08a' : '#ff6a4a', size: 16 });
    return { a: 'УТРО 2', b: 'ТРАССА', clock: fmtClock(6 * 3600 + 31 * 60 + (t - s.s)) };
  }
  // thermal close-up: Marina and Gosha, both warm
  const on = ease(prog(t, cG - 0.15, 0.4));
  rcam(460, 806, 2.6, () => {
    ctx.fillStyle = '#120a33'; ctx.fillRect(-600, -400, 1600, 2400);
    cabinShell(true);
    ctx.fillStyle = '#35268a'; for (const y of ROWS) for (const x of [230, 292, 428, 490]) { rr(x - 28, y - 34, 56, 70, 10); ctx.fill(); }
    heat(MARINA.x, MARINA.y, MARINA.k, on);
    const gw = prog(t, cWarm - 0.2, 0.8);
    if (gw < 1) { ctx.fillStyle = `rgba(2,1,8,${1 - gw})`; circle(GOSHA.x, GOSHA.y, 13); ctx.fill(); }
    heat(GOSHA.x, GOSHA.y, GOSHA.k, gw);
    lock(GOSHA.x - 26, GOSHA.y - 26, 52, 52, prog(t, cWarm, 0.4), '#7fe08a');
  });
  imagerUI(t, on);
  const a = prog(t, c36 - 0.1, 0.25);
  if (a > 0) { bigNum('+36,6°', 1040, 250, 92, '#ffe9a8', a); tag('ГОША', 1040, 284, { align: 'center', col: '#7fe08a', a, size: 16 }); }
  return { a: 'УТРО 2', b: 'ТЕПЛОВИЗОР', clock: fmtClock(6 * 3600 + 34 * 60 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 7. last — a new file, dated five years ahead: this pass, this bus, Timur at the wheel
// ---------------------------------------------------------------------
function sceneLast(t) {
  const id = 'last', s = SC[id];
  const cNew = cue(id, 'НОВЫЙ'), c5 = cue(id, '5'), cPass = cue(id, 'ПЕРЕВАЛ'), cBus = cue(id, 'АВТОБУС'), cT = cue(id, 'ТИМУР', 1);
  const tf = Math.min(t, cT + 0.6);
  const play = ease(prog(tf, cPass - 0.2, 0.4));
  const zT = ease(prog(tf, cT - 0.3, 0.9));
  const z = 1 + 0.04 * prog(tf, s.s, cPass - s.s) + 0.6 * play + 2.6 * zT;
  const fx = lerp(640, 730, zT), fy = lerp(304, 326, zT);
  cameraScreen(fx, fy, z, () => {
    glow(640, 300, 480, 'rgba(60,96,190,0.25)');
    const la = 1 - play;
    if (la > 0) {
      ctx.save(); ctx.globalAlpha = la;
      text('ФАЙЛЫ', 300, 148, `700 19px ${MONO}`, '#cdd6e8');
      text('СЕГОДНЯ: 15.01', 984, 148, `700 19px ${MONO}`, '#8a96b0', 'right');
      ctx.fillStyle = 'rgba(140,160,210,0.25)'; ctx.fillRect(300, 164, 684, 2);
      const ins = easeOut(prog(tf, cNew - 0.05, 0.35));
      [['REC_0046', '15.01', '06:20', '03:11'], ['REC_0045', '15.01', '04:40', '58:02'], ['REC_0044', '15.01', '06:12', '01:37']].forEach((r, i) => {
        const y = 220 + i * 64 + 64 * ins;
        text(r[0], 300, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[1], 540, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[2], 700, y, `600 22px ${MONO}`, '#7f8ca6'); text(r[3], 984, y, `600 22px ${MONO}`, '#7f8ca6', 'right');
      });
      if (ins > 0) {
        ctx.globalAlpha = la * ins; ctx.fillStyle = 'rgba(255,255,255,0.14)'; rr(286, 186, 712, 50, 6); ctx.fill();
        text('REC_0047', 300, 220, `800 22px ${MONO}`, '#ffffff');
        text('15.01.31', 540, 220, `800 22px ${MONO}`, t > c5 ? ORANGE : '#ffffff');
        text('06:12', 700, 220, `800 22px ${MONO}`, '#ffffff'); text('00:20', 984, 220, `800 22px ${MONO}`, '#ffffff', 'right');
      }
      ctx.restore();
      lock(532, 194, 126, 34, prog(tf, c5, 0.35) * la, ORANGE);
      tag('+5 ЛЕТ', 595, 188, { align: 'center', col: ORANGE, a: prog(tf, c5 + 0.2, 0.3) * la, size: 15 });
    }
    if (play > 0) {
      // the recording: the same bus at night on the same pass, headlights on
      ctx.save(); ctx.globalAlpha = play;
      ctx.fillStyle = vgrad(102, 506, [[0, '#070b1a'], [0.6, '#131d3a'], [1, '#2a3962']]); ctx.fillRect(264, 102, 752, 404);
      const r = rng(11);
      for (let x = 264; x < 1030; x += 30) spruce(x + r() * 16, 377, 70 + r() * 70, '#0b1227');
      ctx.fillStyle = '#3c5083'; ctx.fillRect(264, 377, 752, 130);
      ctx.save(); ctx.translate(602, 416); ctx.scale(0.8, 0.8); busSide(0, 0, 1);
      // the driver: an orange jacket at the wheel
      ctx.fillStyle = '#e8731a'; rr(140, -100, 40, 26, 8); ctx.fill(); ctx.fillStyle = '#15171c'; circle(160, -112, 11); ctx.fill();
      ctx.restore();
      ctx.restore();
      if (Math.sin(t * 6) > -0.2) { ctx.save(); ctx.globalAlpha = 1 - zT; circle(294, 128, 7); ctx.fillStyle = '#ff3b30'; ctx.fill(); ctx.restore(); }
      text('REC_0047 · 15.01.31', 308, 134, `700 15px ${MONO}`, '#f1f4fb', 'left', 1 - zT);
    }
  });
  tag('ЗА РУЛЁМ · ТИМУР', FX, TY + 16, { align: 'center', col: ORANGE, a: prog(tf, cT + 0.1, 0.3), size: 18 });
  if (t > cT + 0.6) { const f = prog(t, cT + 0.6, 0.25); ctx.fillStyle = `rgba(120,10,10,${0.2 * f})`; ctx.fillRect(0, 0, W, H); bracket(60, 100, 1160, 470, '#ff3b30', f, 40, 3); }
  return { a: 'УТРО 2', b: 'КАМЕРА ТИМУРА', clock: fmtClock(6 * 3600 + 40 * 60 + (tf - s.s)) };
}
