// =====================================================================
// Episode 3 — «Ответ». Builds on helpers from episodes 1 and 2.
// =====================================================================
const GOSHA = PEOPLE.find(p => p.id === 'ГОША');
const MARINA = PEOPLE.find(p => p.id === 'МАРИНА');
const LENA = PEOPLE.find(p => p.id === 'ЛЕНА');
const FOMICH = PEOPLE.find(p => p.id === 'ФОМИЧ');
const TIMUR = PEOPLE.find(p => p.id === 'ТИМУР');

// cabin from above; o.hide = ids to skip, o.igor = {x,y,k} override, o.arm = 0..1 Lena's grip, o.dawn = cold morning light
function cabinView(t, o = {}) {
  ctx.fillStyle = '#0a0e18'; ctx.fillRect(-600, -300, 1600, 1900);
  cabinShell(false);
  if (o.dawn) {
    glow(495, 165, 80, 'rgba(220,230,255,0.6)');
    ctx.fillStyle = '#d8deef'; ctx.beginPath(); ctx.ellipse(490, 175, 30, 18, 0.3, 0, 6.28); ctx.fill();
    ctx.fillStyle = '#04050a'; ctx.fillRect(520, 128, 22, 70);
  }
  if (!o.noProps) cabinProps(t);
  for (const p of PEOPLE) {
    if ((o.hide || []).includes(p.id)) continue;
    if (p.id === 'ИГОРЬ' && o.igor) continue;
    person(p, t);
  }
  if (o.igor) {
    if (o.arm > 0) {
      const hx = lerp(LENA.x - 18, o.igor.x + 14, o.arm), hy = lerp(LENA.y + 4, o.igor.y + 6, o.arm);
      ctx.save(); ctx.strokeStyle = LENA.coat; ctx.lineCap = 'round'; ctx.lineWidth = 11;
      ctx.beginPath(); ctx.moveTo(LENA.x - 18, LENA.y + 4); ctx.lineTo(hx, hy); ctx.stroke();
      ctx.fillStyle = '#e0b48c'; circle(hx, hy, 6.5); ctx.fill(); ctx.restore();
    }
    person(Object.assign({}, IGOR, o.igor), t);
  }
  if (o.dawn) { ctx.fillStyle = 'rgba(40,70,130,0.22)'; ctx.fillRect(-600, -300, 1600, 1900); }
}
function imagerUI(t, on) {
  ctx.fillStyle = Math.sin(t * 5) > 0 ? '#ff3b30' : '#7a1a15'; circle(FX - 62, 61, 5); ctx.fill();
  text('ТЕПЛОВИЗОР', FX - 48, 67, `600 16px ${MONO}`, '#cdd6e8');
  const g = ctx.createLinearGradient(0, 150, 0, 490);
  [[0, '#fff3c0'], [0.25, '#ff8a1f'], [0.5, '#be28aa'], [0.75, '#3b2a86'], [1, '#02010a']].forEach(([p, c]) => g.addColorStop(p, c));
  ctx.fillStyle = g; rr(1240, 150, 8, 340, 4); ctx.fill();
  ctx.fillStyle = 'rgba(10,6,30,0.16)'; for (let y = 0; y < H; y += 4) ctx.fillRect(0, y, W, 1);
  if (on < 1) { ctx.fillStyle = `rgba(3,2,10,${1 - on})`; ctx.fillRect(0, 0, W, H); }
}
function redMitten(x, y, s, a = 1) {
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(x, y); ctx.scale(s, s); ctx.rotate(-0.4);
  ctx.fillStyle = '#b8322a'; rr(-10, -14, 20, 26, [10, 10, 5, 5]); ctx.fill();
  ctx.beginPath(); ctx.ellipse(-11, -2, 4, 7, 0.5, 0, 6.28); ctx.fill();
  ctx.fillStyle = '#e9e2d4'; rr(-10, 8, 20, 6, 2); ctx.fill();
  ctx.restore();
}

// ---------------------------------------------------------------------
// 1. answer — Igor didn't get to answer. Gosha did.
// ---------------------------------------------------------------------
function sceneAnswer(t) {
  const id = 'answer', s = SC[id];
  const cG = cue(id, 'ГОША'), cQuiet = cue(id, 'ТИХО'), cHere = cue(id, 'ЗДЕСЬ');
  const toG = ease(prog(t, cG - 0.3, 0.9));
  const fx = lerp(360, GOSHA.x - 20, toG), fy = lerp(312, GOSHA.y - 10, toG), sc = lerp(3.4, 2.4, toG) * (1 + 0.04 * prog(t, cQuiet, s.e - cQuiet));
  const sh = t > cHere ? Math.sin(t * 40) * 2 * (1 - prog(t, cHere, 0.6)) : 0;
  rcam(fx + sh, fy, sc, () => {
    cabinView(t, { igor: { x: 360, y: 318, k: 1.2 }, arm: 1 });
    // Marina's jacket half over Gosha
    ctx.fillStyle = 'rgba(122,35,56,0.85)'; ctx.beginPath(); ctx.ellipse(GOSHA.x - 6, GOSHA.y + 10, 24, 15, -0.3, 0, 6.28); ctx.fill();
    lock(GOSHA.x - 26, GOSHA.y - 26, 52, 50, prog(t, cG, 0.4), '#ff3b30');
  });
  const ha = prog(t, cHere - 0.1, 0.25);
  if (ha > 0) {
    const p = rscr(GOSHA.x, GOSHA.y, fx, fy, sc);
    bubble(p.x - 150, p.y - 150, 250, 74, '«Я ЗДЕСЬ»', ha, 70, 80, '#ff6a4a');
    ctx.save(); ctx.globalAlpha = 0.45 * ha * (0.6 + 0.4 * Math.sin((t - cHere) * 7));
    const g = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820); g.addColorStop(0, 'rgba(255,40,30,0)'); g.addColorStop(1, 'rgba(255,40,30,0.55)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  tag('ИГОРЬ · МОЛЧИТ', LM, TY, { a: prog(t, s.s + 0.4, 0.3) * (1 - toG), col: '#cdd6e8' });
  tag('ОТОЗВАЛСЯ: ГОША', LM, TY, { a: prog(t, cG + 0.2, 0.3), col: '#ff6a4a' });
  return { a: 'НОЧЬ 1', b: 'САЛОН', clock: fmtClock(23 * 3600 + 42 * 60 + 19 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 2. silence — the knocking stops, the cold hand melts off the glass
// ---------------------------------------------------------------------
function sceneSilence(t) {
  const id = 'silence', s = SC[id];
  const cStop = cue(id, 'ПРЕКРАТИЛСЯ'), cMelt = cue(id, 'РАСТАЯЛА'), cGone = cue(id, 'БЫЛО');
  const melt = ease(prog(t, cMelt - 0.2, 1.6));
  cam(400, 480, 1.3 + 0.08 * prog(t, s.s, s.e - s.s), () => {
    doorFront(t, true, 0, 0);
    glow(30, 1010, 170, 'rgba(255,112,20,0.85)'); glow(700, 1030, 160, 'rgba(255,112,20,0.75)');
    handprint(452, 448 + melt * 30, 1.1 - 0.15 * melt, (1 - melt) * (0.85 + 0.15 * Math.sin(t * 4)));
    // melt water running down
    if (melt > 0 && melt < 1) for (let i = 0; i < 4; i++) { ctx.fillStyle = `rgba(110,225,255,${0.6 * (1 - melt)})`; rr(424 + i * 18, 470, 4, 40 + 140 * melt * (0.6 + 0.2 * i), 2); ctx.fill(); }
  });
  tag('СТУК', 880, 210, { a: prog(t, cStop, 0.25), col: '#cdd6e8' }); tag('НЕТ', 1200, 210, { a: prog(t, cStop, 0.25), col: '#ff6a4a', align: 'right' });
  tag('ЛАДОНЬ', 880, 250, { a: prog(t, cMelt, 0.25), col: '#cdd6e8' }); tag(melt < 1 ? ('−' + Math.round(lerp(61, 43, melt)) + '°') : 'НЕТ', 1200, 250, { a: prog(t, cMelt, 0.25), col: melt < 1 ? '#6ee1ff' : '#ff6a4a', align: 'right' });
  tag('ГОЛОС', 880, 290, { a: prog(t, cGone, 0.25), col: '#cdd6e8' }); tag('НЕТ', 1200, 290, { a: prog(t, cGone, 0.25), col: '#ff6a4a', align: 'right' });
  imagerUI(t, 1);
  return { a: 'НОЧЬ 1', b: 'ТЕПЛОВИЗОР', clock: fmtClock(23 * 3600 + 42 * 60 + 40 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 3. fomich — "now it knows who answered"
// ---------------------------------------------------------------------
function sceneFomich(t) {
  const id = 'fomich', s = SC[id];
  const cWho = cue(id, 'ОТОЗВАЛСЯ»');
  const toG = ease(prog(t, cWho - 0.4, 0.9));
  const fx = lerp(FOMICH.x - 30, GOSHA.x - 30, toG), fy = lerp(FOMICH.y, GOSHA.y - 20, toG), sc = lerp(2.3, 2.0, toG);
  rcam(fx, fy, sc, () => {
    cabinView(t);
    lock(FOMICH.x - 38, FOMICH.y - 36, 76, 70, prog(t, s.s + 0.2, 0.4) * (1 - toG), '#ffe9a8');
    lock(GOSHA.x - 26, GOSHA.y - 26, 52, 50, prog(t, cWho, 0.4), '#ff3b30');
  });
  tag('ФОМИЧ', LM, TY, { a: prog(t, s.s + 0.3, 0.3) * (1 - toG), col: '#ffe9a8' });
  tag('ОТОЗВАВШИЙСЯ · ГОША', LM, TY, { a: prog(t, cWho + 0.2, 0.3), col: '#ff6a4a' });
  return { a: 'НОЧЬ 1', b: 'САЛОН', clock: fmtClock(23 * 3600 + 43 * 60 + 8 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 4. watch — the night shifts, time-lapse; Igor's missed calls grow
// ---------------------------------------------------------------------
function sceneWatch(t) {
  const id = 'watch', s = SC[id];
  const cShift = cue(id, 'ДЕЖУРИТЬ'), cRec = cue(id, 'СНИМАЕТ'), cPhone = cue(id, 'ТЕЛЕФОН'), cNet = cue(id, 'НЕТ'), c12 = cue(id, '12');
  const c312 = cue(id, '03:12'), c440 = cue(id, '04:40');
  const T0 = 23 * 3600 + 50 * 60, T312 = 27 * 3600 + 12 * 60, T440 = 28 * 3600 + 40 * 60;
  let clk;
  if (t < c312 - 1.2) clk = lerp(T0, T312 - 1800, prog(t, s.s, c312 - 1.2 - s.s));
  else if (t < c312) clk = lerp(T312 - 1800, T312, ease(prog(t, c312 - 1.2, 1.2)));
  else if (t < c440 - 0.8) clk = T312 + lerp(0, 4400, prog(t, c312 + 0.6, c440 - 0.8 - c312 - 0.6));
  else clk = lerp(T312 + 4400, T440, ease(prog(t, c440 - 0.8, 0.8))) + Math.max(0, t - c440);
  blueprint();
  // big clock
  const ff = t < c312 - 0.1 || (t > c312 + 0.6 && t < c440 - 0.1);
  bigNum(fmtClock(clk).slice(0, 5), 340, 220, 118, ff ? '#cdd6e8' : '#f1f4fb');
  tag(ff ? '▶▶ УСКОРЕНО' : 'ТИШИНА', 340, 266, { align: 'center', col: ff ? '#7f8ca6' : ORANGE, size: 15 });
  // shift table
  const rows = [['00:00–02:00', 'ЛЕНА', 24 * 3600, 26 * 3600], ['02:00–04:00', 'ФОМИЧ', 26 * 3600, 28 * 3600], ['04:00–06:00', 'ТИМУР', 28 * 3600, 30 * 3600]];
  const ta = prog(t, cShift, 0.3);
  if (ta > 0) {
    tag('ДЕЖУРСТВО', 90, 328, { a: ta, col: '#9fb2d6', size: 14 });
    rows.forEach(([h, n, a, b], i) => {
      const on = clk >= a && clk < b, y = 370 + i * 40;
      ctx.save(); ctx.globalAlpha = ta * prog(t, cShift + i * 0.15, 0.2);
      ctx.fillStyle = on ? 'rgba(255,138,31,0.16)' : 'rgba(8,10,20,0.6)'; rr(84, y - 24, 512, 34, 5); ctx.fill();
      if (on) { ctx.strokeStyle = ORANGE; ctx.lineWidth = 1.5; ctx.stroke(); }
      ctx.restore();
      text(h, 100, y, `600 18px ${MONO}`, on ? ORANGE : '#aeb9d0', 'left', ta);
      text(n, 580, y, `700 18px ${MONO}`, on ? ORANGE : '#e6ebf5', 'right', ta);
    });
  }
  // Timur's camera recording all night
  const ra = prog(t, cRec, 0.25);
  if (ra > 0) { if (Math.sin(t * 6) > -0.2) { circle(100, 512, 8); ctx.fillStyle = `rgba(255,59,48,${ra})`; ctx.fill(); } text('REC · КАМЕРА ТИМУРА', 118, 519, `700 17px ${MONO}`, '#f1f4fb', 'left', ra); }
  // Igor's phone
  const pa = prog(t, cPhone - 0.1, 0.3) * (1 - prog(t, c312 - 0.6, 0.3));
  if (pa > 0) {
    ctx.save(); ctx.globalAlpha = pa;
    ctx.translate(965, 290); ctx.scale(1.45, 1.45); ctx.translate(-540, -696);
    rr(480, 596, 120, 200, 16); ctx.fillStyle = '#0d1120'; ctx.fill(); ctx.strokeStyle = '#3a4560'; ctx.lineWidth = 3; ctx.stroke();
    rr(488, 612, 104, 168, 9); ctx.fillStyle = '#16233f'; ctx.fill();
    ctx.globalAlpha = 1;
    text(t > cNet ? 'НЕТ СЕТИ' : '…', 540, 640, `700 13px ${MONO}`, t > cNet ? '#ff6a4a' : '#9fb2d6', 'center', pa);
    const n = t > c12 ? Math.min(12, Math.floor(1 + (t - c12) * 14)) : 0;
    if (n > 0) {
      circle(540, 700, 28); ctx.fillStyle = `rgba(255,59,48,${pa})`; ctx.fill();
      text(String(n), 540, 711, `800 28px ${MONO}`, '#fff', 'center', pa);
      text('ПРОПУЩЕННЫХ', 540, 756, `700 10px ${MONO}`, '#f1f4fb', 'center', pa);
    }
    ctx.restore();
  }
  return { a: 'НОЧЬ 1', b: 'ДЕЖУРСТВО', clock: fmtClock(clk), note: ff ? 'УСКОРЕНО' : '' };
}

// ---------------------------------------------------------------------
// 5. wake — Timur wakes at 06:12; snow up to the windows, door open: like the recording
// ---------------------------------------------------------------------
function sceneWake(t) {
  const id = 'wake', s = SC[id];
  const cSnow = cue(id, 'СНЕГ'), cOpen = cue(id, 'ОТКРЫТА'), cRec = cue(id, 'КАК');
  const toDoor = ease(prog(t, cSnow - 0.2, 1.0));
  const fx = lerp(TIMUR.x + 10, 470, toDoor), fy = lerp(TIMUR.y, 190, toDoor), sc = lerp(2.4, 2.0, toDoor);
  rcam(fx, fy, sc, () => {
    cabinView(t, { dawn: true, hide: ['ГОША'] });
    lock(468, 118, 70, 92, prog(t, cOpen, 0.4), ORANGE);
  });
  const dq = rscr(503, 164, fx, fy, sc);
  tag('ДВЕРЬ · ОТКРЫТА', dq.x, dq.y - 35 * sc - 14, { align: 'center', col: ORANGE, a: prog(t, cOpen + 0.2, 0.3) });
  // "like on the recording": the camcorder overlay flickers in
  const ra = prog(t, cRec, 0.2);
  if (ra > 0) { const fl = (Math.sin((t - cRec) * 23) > 0.2 ? 1 : 0.35) * (1 - prog(t, cRec + 1.6, 0.4)); recOverlay(t, T_REC0 + (t - cRec), ra * fl); glitch(t, 0.35 * ra * fl); }
  // eyelids
  const open = ease(prog(t, s.s + 0.1, 1.1));
  if (open < 1) {
    const hgt = (1 - open) * H / 2;
    ctx.fillStyle = '#020306'; ctx.fillRect(0, 0, W, hgt); ctx.fillRect(0, H - hgt, W, hgt);
  }
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 12 * 60 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 6. count — Igor is here. Gosha's seat is empty: a red mitten.
// ---------------------------------------------------------------------
function sceneCount(t) {
  const id = 'count', s = SC[id];
  const nm = { 'ЛЕНА': cue(id, 'ЛЕНА'), 'ФОМИЧ': cue(id, 'ФОМИЧ'), 'МАРИНА': cue(id, 'МАРИНА'), 'ИГОРЬ': cue(id, 'ИГОРЬ') };
  const cG = cue(id, 'ГОШИ'), cM = cue(id, 'ВАРЕЖКА');
  let fx = 360, fy = 540, sc = 1.08;
  const zi = ease(prog(t, cG - 0.3, 0.8)); fx = lerp(fx, GOSHA.x - 30, zi); fy = lerp(fy, GOSHA.y - 20, zi); sc = lerp(sc, 2.4, zi);
  rcam(fx, fy, sc, () => {
    cabinView(t, { dawn: true, hide: ['ГОША'] });
    for (const [n, c] of Object.entries(nm)) {
      const p = PEOPLE.find(q => q.id === n), pp = prog(t, c - 0.05, 0.35), r = 34 * p.k;
      lock(p.x - r, p.y - r + 2, r * 2, r * 2 - 6, pp, n === 'ИГОРЬ' ? ORANGE : '#ffe9a8');
      const q = rlabel(p, r, sc);
      if (pp > 0) tag(n === 'ИГОРЬ' ? 'ИГОРЬ · НА МЕСТЕ' : n, q.x, q.y, { a: pp, align: q.align, size: 12, col: n === 'ИГОРЬ' ? ORANGE : '#ffe9a8' });
    }
    redMitten(GOSHA.x + 4, GOSHA.y + 4, 1, 1);
    lock(GOSHA.x - 28, GOSHA.y - 30, 56, 62, prog(t, cG, 0.4), '#ff3b30');
    const qg = rlabel(GOSHA, 30, sc);
    tag('ГОША — НЕТ', qg.x, qg.y, { align: qg.align, col: '#ff6a4a', a: prog(t, cG + 0.2, 0.3), size: 11 });
  });
  // the recording predicted the wrong person
  const ca = prog(t, cM + 0.3, 0.3);
  tag('НА ЗАПИСИ ПРОПАЛ', LM, TY + 4, { a: ca, col: '#cdd6e8', size: 15 }); tag('ИГОРЬ', LM + 440, TY + 4, { a: ca, col: '#cdd6e8', align: 'right', size: 15 });
  tag('ПРОПАЛ НА САМОМ ДЕЛЕ', LM, TY + 42, { a: prog(t, cM + 0.7, 0.3), col: '#cdd6e8', size: 15 }); tag('ГОША', LM + 440, TY + 42, { a: prog(t, cM + 0.7, 0.3), col: '#ff6a4a', align: 'right', size: 15 });
  return { a: 'УТРО 2', b: 'САЛОН', clock: fmtClock(6 * 3600 + 12 * 60 + 21 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 7. steps — small footprints, twenty steps, ending where the driver's did
// ---------------------------------------------------------------------
const KSTEPS = [];
for (let i = 0; i < 20; i++) {
  const q = pathAt((i + 1) / 20), side = i % 2 ? 1 : -1, nx = Math.cos(STEP_DIR + Math.PI / 2), ny = Math.sin(STEP_DIR + Math.PI / 2);
  KSTEPS.push({ x: q.x + nx * (16 + 4 * side), y: q.y + ny * (16 + 4 * side) });
}
function kidPrint(q, a, col = '#18233f') {
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(q.x, q.y); ctx.rotate(STEP_DIR);
  ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(1, 0, 4.6, 2.7, 0, 0, 6.28); ctx.fill(); ctx.beginPath(); ctx.ellipse(-5, 0, 2.3, 2.2, 0, 0, 6.28); ctx.fill();
  ctx.restore();
}
function sceneSteps(t) {
  const id = 'steps', s = SC[id];
  const cSmall = cue(id, 'МАЛЕНЬКИЕ'), c20 = cue(id, '20'), cEnd = cue(id, 'ОБРЫВАЮТСЯ'), cDrv = cue(id, 'ВОДИТЕЛЯ');
  const n = 20 * prog(t, s.s + 0.3, c20 + 0.3 - s.s - 0.3);
  const q = KSTEPS[Math.max(0, Math.min(19, Math.floor(n)))];
  let fx = lerp(DOOR.x + 30, q.x, ease(prog(t, s.s + 0.3, 0.8))), fy = lerp(DOOR.y, q.y, ease(prog(t, s.s + 0.3, 0.8))), sc = 1.9;
  const zl = ease(prog(t, cEnd - 0.3, 0.7)); fx = lerp(fx, END.x + 8, zl); fy = lerp(fy, END.y, zl); sc = lerp(sc, 2.8, zl);
  const zo = ease(prog(t, cDrv - 0.3, 0.8)); sc = lerp(sc, 2.2, zo);
  cam(fx, fy, sc, () => {
    drawWorld(t, { steps: 0, fogA: 0.3, lights: 0, door: 1 });
    // the driver's old trail, nearly snowed over
    const da = 0.22 + 0.6 * prog(t, cDrv, 0.4);
    for (let i = 0; i < 20; i++) footprint(STEPS[i], da, t > cDrv ? ORANGE : '#18233f');
    for (let i = 0; i < Math.min(20, Math.floor(n)); i++) kidPrint(KSTEPS[i], 1, t > cDrv ? '#ffe9a8' : '#121a33');
    const last = KSTEPS[19];
    lock(last.x - 12, last.y - 10, 24, 20, prog(t, cEnd, 0.4), '#ff3b30');
  });
  ctx.fillStyle = 'rgba(255,170,190,0.07)'; ctx.fillRect(0, 0, W, H);
  snowfall(t, 50, 91, { vy: 24, vx: -18, size: 1.8, a: 0.5 });
  const ca = prog(t, cSmall - 0.2, 0.3) * (1 - zl);
  if (ca > 0) { bigNum(String(Math.min(20, Math.floor(n))), 250, 300, 104, Math.floor(n) >= 20 ? ORANGE : '#f1f4fb', ca); tag('ДЕТСКИХ ШАГОВ', 250, 342, { align: 'center', a: ca }); tag('РАЗМЕР ≈ 28', 250, 374, { align: 'center', a: ca, col: '#cdd6e8' }); }
  tag('ШАГ № 21 — НЕТ', FX, FY + 150, { align: 'center', col: '#ff6a4a', a: prog(t, cEnd + 0.3, 0.3) * (1 - zo) });
  tag('ТА ЖЕ ТОЧКА · СЛЕД ВОДИТЕЛЯ № 20', FX, FY + 150, { align: 'center', col: ORANGE, a: prog(t, cDrv + 0.2, 0.3), size: 14 });
  return { a: 'УТРО 2', b: 'СЛЕДЫ', clock: fmtClock(6 * 3600 + 13 * 60 + 2 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 8. call — Marina screams his name into the fog from the open door
// ---------------------------------------------------------------------
function fogField(t, o = {}) {
  ctx.fillStyle = vgrad(-200, 640, [[0, '#2b3150'], [0.6, '#7e86a8'], [1, '#c9cce0']]); ctx.fillRect(-900, -500, 2900, 1160);
  ctx.fillStyle = vgrad(600, 1500, [[0, '#cfd3e6'], [1, '#7c84a6']]); ctx.fillRect(-900, 600, 2900, 1200);
  const r = rng(o.seed || 23);
  ctx.save(); ctx.globalAlpha = 0.5;
  for (let x = -520; x < 1260; x += 46) spruce(x + r() * 26, 612, 150 + r() * 170, '#4a5070');
  ctx.restore();
  glow(360, 560, 380, 'rgba(235,238,250,0.45)');
}
function openDoorFrame(t) {
  // interior seen from behind Marina: dark frame around a bright doorway
  ctx.fillStyle = '#0b0f17';
  ctx.fillRect(-900, -600, 2600, 770); ctx.fillRect(-900, -600, 1050, 2200); ctx.fillRect(570, -600, 1100, 2200); ctx.fillRect(-900, 900, 2600, 700);
  // inside the bus either side of the doorway: warm dim light, handrails, the first seats
  glow(-120, 720, 420, 'rgba(255,170,80,0.13)'); glow(840, 720, 420, 'rgba(255,170,80,0.13)');
  ctx.fillStyle = '#3a2c22'; rr(-300, 640, 300, 170, 22); ctx.fill(); rr(720, 640, 300, 170, 22); ctx.fill();
  ctx.fillStyle = '#2c2119'; rr(-300, 780, 300, 44, 14); ctx.fill(); rr(720, 780, 300, 44, 14); ctx.fill();
  ctx.fillStyle = '#8b95a8'; rr(60, 140, 12, 780, 6); ctx.fill(); rr(648, 140, 12, 780, 6); ctx.fill();
  ctx.fillStyle = '#19212d'; rr(-330, 230, 280, 330, 16); ctx.fill(); rr(770, 230, 280, 330, 16); ctx.fill();
  ctx.fillStyle = 'rgba(150,170,220,0.10)'; rr(-312, 248, 244, 294, 10); ctx.fill(); rr(788, 248, 244, 294, 10); ctx.fill();
  ctx.fillStyle = '#26382f'; ctx.fillRect(150, 170, 14, 730); ctx.fillRect(556, 170, 14, 730);
  ctx.fillStyle = '#1e2836'; ctx.fillRect(120, 890, 480, 26);
  ctx.fillStyle = '#d4d8ea'; ctx.beginPath(); ctx.moveTo(164, 900); ctx.bezierCurveTo(260, 850, 420, 860, 556, 890); ctx.lineTo(556, 900); ctx.fill();
}
function marinaBack(x, y, s, shout) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
  ctx.fillStyle = '#5c1a2b'; rr(-70, -40, 140, 300, [40, 40, 10, 10]); ctx.fill();
  ctx.fillStyle = '#7a2338'; rr(-64, -34, 128, 290, [38, 38, 10, 10]); ctx.fill();
  ctx.fillStyle = '#c9a45c'; circle(0, -86 - shout * 6, 46); ctx.fill();
  ctx.fillStyle = '#a8853f'; ctx.beginPath(); ctx.ellipse(0, -60 - shout * 6, 44, 30, 0, 0, Math.PI); ctx.fill();
  // arms forward (cupped hands to mouth when shouting)
  ctx.fillStyle = '#7a2338'; rr(-96, -20, 34, 160 - shout * 40, 16); ctx.fill(); rr(62, -20, 34, 160 - shout * 40, 16); ctx.fill();
  ctx.restore();
}
function sceneCall(t) {
  const id = 'call', s = SC[id];
  const cName = cue(id, '«ГОША!»'), cGrab = cue(id, 'ХВАТАЕТ'), cNo = cue(id, '«НЕ'), cLate = cue(id, 'ПОЗДНО');
  const shout = pulse(t, cName - 0.1, 1.0);
  cam(360, 560, 0.74 * (1 + 0.06 * prog(t, s.s, s.e - s.s)), () => {
    fogField(t);
    openDoorFrame(t);
    marinaBack(360, 740, 1.0, shout);
    // Fomich's hand on her shoulder
    const g = ease(prog(t, cGrab, 0.4));
    if (g > 0) { ctx.save(); ctx.fillStyle = '#59603a'; rr(lerp(1000, 450, g), 650, 520, 46, 22); ctx.fill(); ctx.fillStyle = '#8b6a50'; circle(lerp(1000, 450, g), 673, 26); ctx.fill(); ctx.restore(); }
  });
  // the name rolls out into the fog
  const pr = prog(t, cName, 1.6);
  if (pr > 0 && pr < 1) for (let k = 0; k < 3; k++) { const q = clamp(pr * 1.4 - k * 0.2); if (q <= 0 || q >= 1) continue; ctx.strokeStyle = `rgba(255,233,168,${0.7 * (1 - q)})`; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(FX, 290, 50 + q * 240, 16 + q * 80, 0, Math.PI, 0); ctx.stroke(); }
  tag('ПРАВИЛО № 2', LM, TY, { a: prog(t, cNo, 0.3), col: '#ff6a4a' });
  tag('НАРУШЕНО', LM, TY + 36, { a: prog(t, cLate, 0.3), col: '#ff6a4a' });
  const la = prog(t, cLate, 0.3);
  if (la > 0) { ctx.save(); ctx.globalAlpha = 0.4 * la * (0.6 + 0.4 * Math.sin((t - cLate) * 6)); const gg = ctx.createRadialGradient(FX, 360, 380, FX, 360, 820); gg.addColorStop(0, 'rgba(255,40,30,0)'); gg.addColorStop(1, 'rgba(255,40,30,0.5)'); ctx.fillStyle = gg; ctx.fillRect(0, 0, W, H); ctx.restore(); }
  return { a: 'УТРО 2', b: 'ДВЕРЬ', clock: fmtClock(6 * 3600 + 14 * 60 + 6 + (t - s.s)) };
}

// ---------------------------------------------------------------------
// 9. reply — a child's voice answers; behind him six more; Marina steps out
// ---------------------------------------------------------------------
function kid(x, y, s, wave, a = 1) {
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(x, y); ctx.scale(s, s);
  ctx.fillStyle = '#1c2236'; rr(-12, 30, 10, 36, 4); ctx.fill(); rr(2, 30, 10, 36, 4); ctx.fill();
  ctx.fillStyle = '#3d6fb5'; rr(-20, -24, 40, 60, 12); ctx.fill();
  ctx.save(); ctx.translate(16, -16); ctx.rotate(-2.2 + Math.sin(wave) * 0.45); rr(-5, 0, 10, 34, 5); ctx.fill(); ctx.restore();
  rr(-24, -16, 10, 34, 5); ctx.fill();
  ctx.fillStyle = '#e0b48c'; circle(0, -36, 13); ctx.fill();
  ctx.fillStyle = '#f2c230'; ctx.beginPath(); ctx.ellipse(0, -42, 15, 11, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = '#fff3c4'; circle(0, -56, 5); ctx.fill();
  // only one mitten: the other is on the seat
  ctx.restore();
}
function shadowMan(x, y, s, a) {
  if (a <= 0) return;
  ctx.save(); ctx.globalAlpha *= a; ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = '#0d1020';
  circle(0, -96, 11); ctx.fill(); rr(-17, -86, 34, 52, 9); ctx.fill(); ctx.fillRect(-12, -40, 10, 42); ctx.fillRect(2, -40, 10, 42);
  ctx.restore();
}
function sceneReply(t) {
  const id = 'reply', s = SC[id];
  const cKid = cue(id, 'ДЕТСКИЙ'), cMama = cue(id, 'МАМА»'), cSeven = cue(id, 'СЕМЬ»'), cStep = cue(id, 'ШАГ');
  const tf = Math.min(t, cStep + 0.5);
  const z = 1 + 0.5 * ease(prog(tf, cKid, cSeven - cKid)) - 0.25 * ease(prog(tf, cSeven, 0.8));
  const ka = prog(tf, cKid - 0.2, 1.2);
  cam(360, 575, z, () => {
    fogField(tf, { seed: 31 });
    // six figures appear behind him, one after another
    const pos = [[250, 590, 1.25], [470, 596, 1.2], [180, 610, 1.1], [540, 606, 1.15], [310, 576, 1.0], [420, 572, 1.05]];
    pos.forEach(([x, y, k], i) => shadowMan(x, y, k, prog(tf, cSeven + 0.15 + i * 0.22, 0.4) * 0.85));
    kid(360, 640, 1.2, tf * 6, ka);
    fog(tf, 520, 700, 0.18, 33, '220,224,240', 6);
  });
  snowfall(t, 60, 95, { vy: 30, vx: -20, a: 0.55 });
  waveform(tf, 90, 240, 300, 54, prog(tf, cKid + 0.6, 0.2) * (1 - prog(tf, cStep - 0.4, 0.3)), '#bfd4ff');
  tag('ДЕТСКИЙ ГОЛОС · 20 ШАГОВ', FX, 132, { align: 'center', col: '#bfd4ff', a: prog(tf, cKid + 0.3, 0.3) });
  const sev = Math.min(7, 1 + Math.floor(Math.max(0, tf - cSeven - 0.15) / 0.22 + (tf > cSeven ? 1 : 0)));
  if (tf > cSeven) { bigNum(String(sev), 1060, 290, 96, sev >= 7 ? '#ff3b30' : '#f1f4fb'); tag('В ТУМАНЕ', 1060, 322, { align: 'center', col: '#cdd6e8', size: 13 }); }
  // Marina's boot enters the frame from below and sinks into the snow
  const st = ease(prog(t, cStep - 0.1, 0.6));
  if (st > 0) {
    ctx.save(); ctx.translate(430, lerp(1110, 750, st));
    ctx.fillStyle = '#1a1214'; rr(-60, -360, 120, 380, 30); ctx.fill();
    ctx.fillStyle = '#2a1c1a'; rr(-80, -10, 180, 60, 24); ctx.fill();
    ctx.restore();
    if (st > 0.95) { ctx.fillStyle = 'rgba(230,234,248,0.9)'; for (let i = 0; i < 12; i++) { const r = rng(400 + i); circle(350 + r() * 180, 740 - r() * 40, 3 + r() * 4); ctx.fill(); } }
  }
  if (t > cStep + 0.5) {
    const f = prog(t, cStep + 0.5, 0.25);
    ctx.fillStyle = `rgba(120,10,10,${0.2 * f})`; ctx.fillRect(0, 0, W, H);
    bracket(60, 100, 1160, 470, '#ff3b30', f, 40, 3);
  }
  return { a: 'УТРО 2', b: 'ТУМАН', clock: fmtClock(6 * 3600 + 14 * 60 + 22 + (tf - s.s)) };
}
